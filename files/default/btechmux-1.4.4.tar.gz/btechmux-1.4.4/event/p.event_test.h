
/*
   p.event_test.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Sat Jun  6 17:24:32 EEST 1998 from event_test.c */

#ifndef _P_EVENT_TEST_H
#define _P_EVENT_TEST_H

void main(void);

#endif				/* _P_EVENT_TEST_H */
