
/*
 * Standalone db.c 
 */

/*
 * $Id: sa-db.c 1.1 02/01/03 00:59:31-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "db.c"
