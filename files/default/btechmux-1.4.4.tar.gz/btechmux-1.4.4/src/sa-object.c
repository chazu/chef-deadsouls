
/*
 * Standalone object.c 
 */

/*
 * $Id: sa-object.c 1.1 02/01/03 01:00:23-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "object.c"
