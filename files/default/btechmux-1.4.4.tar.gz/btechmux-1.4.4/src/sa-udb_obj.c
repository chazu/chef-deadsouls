
/* Standalone udb_obj.c */

/* $Id: sa-udb_obj.c 1.1 02/01/03 00:59:54-00:00 twouters@ $ */
#define STANDALONE
#include "udb_obj.c"
