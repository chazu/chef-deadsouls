
/*
 * Standalone vattr.c 
 */

/*
 * $Id: sa-vattr.c 1.1 02/01/03 01:00:08-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "vattr.c"
