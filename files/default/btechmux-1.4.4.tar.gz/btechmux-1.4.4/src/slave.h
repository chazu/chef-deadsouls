
/* slave.h */

/* $Id: slave.h 1.1 02/01/03 00:59:53-00:00 twouters@ $ */

enum {
    SLAVE_IDENTQ = 'i',
    SLAVE_IPTONAME = 'h'
};
