
/*
   p.sa-player_c.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:44:03 CET 1999 from sa-player_c.c */

#ifndef _P_SA_PLAYER_C_H
#define _P_SA_PLAYER_C_H

/* sa-player_c.c */
int Pennies(dbref obj);
void s_Pennies(dbref obj, int howfew);

#endif				/* _P_SA_PLAYER_C_H */
