
/*
 * Standalone flags.c 
 */

/*
 * $Id: sa-flags.c 1.1 02/01/03 00:59:54-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "flags.c"
