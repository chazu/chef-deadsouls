
/*
 * Standalone player_c.c 
 */

/*
 * $Id: sa-player_c.c 1.1 02/01/03 01:00:04-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "player_c.c"
