
/*
 * $Id: history.h 1.2 02/01/09 13:05:32-00:00 twouters@ $
 *
 * Author: Markus Stenberg <fingon@iki.fi>
 *
 *  Copyright (c) 1998 Markus Stenberg
 *       All rights reserved
 *
 * Created: Thu Jun  4 22:10:50 1998 fingon
 * Last modified: Thu Jun  4 22:11:05 1998 fingon
 *
 */

#ifndef HISTORY_H
#define HISTORY_H

#define HINFO_LOGIN  0
#define HINFO_LOGOFF 1

#endif				/* HISTORY_H */
