
/*
 * $Id: history.c 1.2 02/01/09 13:05:32-00:00 twouters@ $
 *
 * Author: Markus Stenberg <fingon@iki.fi>
 *
 *  Copyright (c) 1998 Markus Stenberg
 *       All rights reserved
 *
 * Created: Thu Jun  4 22:08:09 1998 fingon
 * Last modified: Thu Dec 10 22:09:14 1998 fingon
 *
 */

#include "strhandler.h"
#include "history.h"
#include "attrs.h"
#include "externs.h"
#include "interface.h"
#include "coolmenu.h"
#include "mycool.h"
#include "event.h"
#include "create.h"
#include "powers.h"
