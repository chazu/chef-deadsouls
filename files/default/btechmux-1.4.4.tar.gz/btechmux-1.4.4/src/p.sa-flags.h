
/*
   p.sa-flags.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:44:01 CET 1999 from sa-flags.c */

#ifndef _P_SA_FLAGS_H
#define _P_SA_FLAGS_H

/* sa-flags.c */

#endif				/* _P_SA_FLAGS_H */
