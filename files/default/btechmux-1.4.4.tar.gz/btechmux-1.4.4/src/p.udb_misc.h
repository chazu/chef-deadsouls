
/*
   p.udb_misc.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:44:11 CET 1999 from udb_misc.c */

#ifndef _P_UDB_MISC_H
#define _P_UDB_MISC_H

/* udb_misc.c */
void log_db_err(int obj, int attr, const char *txt);
void logf(char *p, ...);
void fatal(char *p, ...);

#endif				/* _P_UDB_MISC_H */
