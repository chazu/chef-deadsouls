
/*
 * Standalone htab.c 
 */

/*
 * $Id: sa-htab.c 1.1 02/01/03 01:00:14-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "htab.c"
