
/*
 * Standalone db_rw.c 
 */

/*
 * $Id: sa-db_rw.c 1.1 02/01/03 01:00:23-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "db_rw.c"
