
/*
   p.sa-unparse.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:44:07 CET 1999 from sa-unparse.c */

#ifndef _P_SA_UNPARSE_H
#define _P_SA_UNPARSE_H

/* sa-unparse.c */
char *unparse_boolexp_quiet(dbref player, BOOLEXP * b);

#endif				/* _P_SA_UNPARSE_H */
