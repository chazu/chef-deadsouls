
/*
   p.dspace.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:43:45 CET 1999 from dspace.c */

#ifndef _P_DSPACE_H
#define _P_DSPACE_H

/* dspace.c */

#endif				/* _P_DSPACE_H */
