
/*
   p.mcheck.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:43:53 CET 1999 from mcheck.c */

#ifndef _P_MCHECK_H
#define _P_MCHECK_H

/* mcheck.c */
int mcheck(void);
enum mcheck_status mprobe(void *ptr);

#endif				/* _P_MCHECK_H */
