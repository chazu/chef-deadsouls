
/* Standalone udb_ocache.c */

/* $Id: sa-udb_ocache.c 1.1 02/01/03 01:00:19-00:00 twouters@ $ */
#define STANDALONE
#include "udb_ocache.c"
