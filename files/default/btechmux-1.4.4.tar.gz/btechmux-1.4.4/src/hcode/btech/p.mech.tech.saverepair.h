
/*
   p.mech.tech.saverepair.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Fri Jan 15 15:33:01 CET 1999 from mech.tech.saverepair.c */

#ifndef _P_MECH_TECH_SAVEREPAIR_H
#define _P_MECH_TECH_SAVEREPAIR_H

/* mech.tech.saverepair.c */
void saverepairs(FILE * f);
void loadrepairs(FILE * f);

#endif				/* _P_MECH_TECH_SAVEREPAIR_H */
