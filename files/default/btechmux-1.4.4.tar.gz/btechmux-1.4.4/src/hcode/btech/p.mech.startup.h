
/*
   p.mech.startup.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Fri Jan 15 15:32:56 CET 1999 from mech.startup.c */

#ifndef _P_MECH_STARTUP_H
#define _P_MECH_STARTUP_H

/* mech.startup.c */
void mech_startup(dbref player, void *data, char *buffer);
void mech_shutdown(dbref player, void *data, char *buffer);

#endif				/* _P_MECH_STARTUP_H */
