
/*
   p.mech.tech.events.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Fri Jan 15 15:33:00 CET 1999 from mech.tech.events.c */

#ifndef _P_MECH_TECH_EVENTS_H
#define _P_MECH_TECH_EVENTS_H

/* mech.tech.events.c */
void event_mech_removesection(EVENT * e);
void event_mech_removegun(EVENT * e);
void event_mech_removepart(EVENT * e);
void event_mech_repairarmor(EVENT * e);
void event_mech_repairinternal(EVENT * e);
void event_mech_reattach(EVENT * e);
void event_mech_replacesuit(EVENT * e);
void event_mech_replacegun(EVENT * e);
void event_mech_repairgun(EVENT * e);
void event_mech_repairenhcrit(EVENT * e);
void event_mech_repairpart(EVENT * e);
void event_mech_reload(EVENT * e);
void event_mech_mountbomb(EVENT * e);
void event_mech_umountbomb(EVENT * e);
void event_mech_replacesuit(EVENT * e);

#endif				/* _P_MECH_TECH_EVENTS_H */
