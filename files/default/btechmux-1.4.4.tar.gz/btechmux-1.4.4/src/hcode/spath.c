
/*
 * $Id: spath.c 1.1 02/01/03 01:00:27-00:00 twouters@ $
 *
 * Last modified: Fri Dec 11 00:54:43 1998 fingon
 *
 */
