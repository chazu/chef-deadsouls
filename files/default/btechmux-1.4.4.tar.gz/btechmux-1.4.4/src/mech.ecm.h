
/* mech.ecm.c */
