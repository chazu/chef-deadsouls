
/* Standalone udb_misc.c */

/* $Id: sa-udb_misc.c 1.1 02/01/03 00:59:28-00:00 twouters@ $ */
#define STANDALONE
#include "udb_misc.c"
