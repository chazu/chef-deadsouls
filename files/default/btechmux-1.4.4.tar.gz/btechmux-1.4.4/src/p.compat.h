
/*
   p.compat.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:43:41 CET 1999 from compat.c */

#ifndef _P_COMPAT_H
#define _P_COMPAT_H

/* compat.c */

#endif				/* _P_COMPAT_H */
