
/*
 * Standalone predicates.c 
 */

/*
 * $Id: sa-pred.c 1.1 02/01/03 01:00:18-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "predicates.c"
