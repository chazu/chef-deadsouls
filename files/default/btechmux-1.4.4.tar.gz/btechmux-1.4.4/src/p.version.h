
/*
   p.version.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:44:14 CET 1999 from version.c */

#ifndef _P_VERSION_H
#define _P_VERSION_H

/* version.c */
void do_version(dbref player, dbref cause, int extra);
void init_version(void);

#endif				/* _P_VERSION_H */
