
/*
   p.portconc.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:43:58 CET 1999 from portconc.c */

#ifndef _P_PORTCONC_H
#define _P_PORTCONC_H

/* portconc.c */

#endif				/* _P_PORTCONC_H */
