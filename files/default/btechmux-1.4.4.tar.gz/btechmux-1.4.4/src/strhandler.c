
/*
 * $Id: strhandler.c 1.1 02/01/03 00:59:53-00:00 twouters@ $
 *
 * Author: Markus Stenberg <fingon@iki.fi>
 *
 *  Copyright (c) 1998 Markus Stenberg
 *       All rights reserved
 *
 * Created: Thu Jun  4 21:41:16 1998 fingon
 * Last modified: Thu Dec 10 22:09:46 1998 fingon
 *
 */
