
/*
 * Standalone boolexp.c 
 */

/*
 * $Id: sa-boolexp.c 1.1 02/01/03 00:59:31-00:00 twouters@ $ 
 */
#undef MEMORY_BASED
#define STANDALONE
#include "boolexp.c"
