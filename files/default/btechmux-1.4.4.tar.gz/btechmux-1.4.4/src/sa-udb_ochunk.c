
/* Standalone udb_ochunk.c */

/* $Id: sa-udb_ochunk.c 1.2 02/01/09 23:30:06-00:00 twouters@ $ */
#undef MEMORY_BASED
#define STANDALONE
#include "udb_ochunk.c"
