
/*
   p.sa-boolexp.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Thu Mar 11 17:43:59 CET 1999 from sa-boolexp.c */

#ifndef _P_SA_BOOLEXP_H
#define _P_SA_BOOLEXP_H

/* sa-boolexp.c */
BOOLEXP *parse_boolexp(dbref player, const char *buf, int internal);

#endif				/* _P_SA_BOOLEXP_H */
