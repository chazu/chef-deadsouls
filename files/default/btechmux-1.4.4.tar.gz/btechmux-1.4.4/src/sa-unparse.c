
/*
 * Standalone unparse.c 
 */

/*
 * $Id: sa-unparse.c 1.1 02/01/03 00:59:55-00:00 twouters@ $ 
 */

#undef MEMORY_BASED
#define STANDALONE
#include "unparse.c"
