
/*
   p.mux_tree.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Mon Jun 22 07:18:18 EEST 1998 from mux_tree.c */

#ifndef _P_MUX_TREE_H
#define _P_MUX_TREE_H


#endif				/* _P_MUX_TREE_H */
