#!/usr/bin/env python

"""This is an empty module object. The number you tried to reach is not in
service."""
