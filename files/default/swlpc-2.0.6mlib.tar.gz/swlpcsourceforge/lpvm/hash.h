

/*
** $Id: hash.h,v 1.1.1.1 2001/09/11 04:12:12 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/hash.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:12 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/


#ifndef _HASH_H
#define _HASH_H

int  hashstr(char *s, int maxn, int hashs);
    /* hash a string */

#endif
