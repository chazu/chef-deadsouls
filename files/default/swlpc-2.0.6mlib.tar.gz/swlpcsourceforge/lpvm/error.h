/*
** $Id: error.h,v 1.1.1.1 2001/09/11 04:12:12 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/error.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:12 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _SERROR_H
#define _SERROR_H

#include <stdio.h>
#include <stdarg.h>

extern FILE * errstream;

void efun_error(const char *fmt,...);
char * find_function();
void output_error(char *s, char *fun, int instr);
void stack_error(const char *fmt,...);
int stype_check(unsigned char *pc, int args, char *objname, char *funname);


#endif
