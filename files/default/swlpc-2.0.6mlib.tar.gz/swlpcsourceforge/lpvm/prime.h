/*
** $Id: prime.h,v 1.1.1.1 2001/09/11 04:12:13 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/prime.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:13 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _PRIME_H
#define _PRIME_H

/*
 * some generic large primes used by various hash functions in different
 * files These are not critical.
 */

#define P1      701     /* 3 large, different primes */
#define P2      14009   /* There's a file of them here somewhere :-) */
#define P3      54001

#define HUGE_PRIME  29000039

/*****************************************************************************/ 

#endif
