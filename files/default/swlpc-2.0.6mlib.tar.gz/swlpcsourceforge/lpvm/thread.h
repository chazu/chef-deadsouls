
/*
** $Id: thread.h,v 1.1.1.1 2001/09/11 04:12:18 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/thread.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:18 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 2000
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _THREAD_H
#define _THREAD_H

#include "stack.h"

/* An indvidual thread definition struct */
typedef struct THREAD
{
    byte * sPC;  /* program counter! */
    Obj * currentO;     /* current working object */
    char *last_fun;     /* some "state" memory */

    /* Main Stack stuff */
    Val * stack[MAX_STACK];
    int  rSP;           /* points to the next empty element in the stack */
    int  rBP;           /* base(frame) pointer */

    /* Control Stack stuff */
    int  control[MAX_CONTROL_DEPTH];
    int  rCT;           /* control stack pointer */
    int  CATCHBP;       /* catch base pointer! */
    int  CBP;           /* control frame pointer */

    /* Random state stuff mostly */
    int  total_offset;
    int  FV;
    int  overflow_flag;
    int  terminate;

    /* Debugging aid vars */
    int  last_global;
    int  last_local;

    /* Other Handlers */
    void (*efun_handler)(int);
    Exec_block (*prog_handler)(Obj *, Shared *);

    /* Execution return code */
    Stack_code error_code;
} Thread;

#endif

