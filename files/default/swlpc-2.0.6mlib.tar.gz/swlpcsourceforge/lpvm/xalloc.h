/*
** $Id: xalloc.h,v 1.1.1.1 2001/09/11 04:12:18 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/xalloc.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:18 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

/*
 * We don't fix leaks, we use a garbage collector - mike.
 * NB: the GC package has an awesome leak detector anyway; supersedes leak.c
 */
#include <stdio.h>

/* set by configure */
//#ifdef USE_GC 
#if 0
#include <gc/gc.h>

#define malloc(s)	GC_malloc(s)
#define xalloc(s)	GC_malloc(s)
#define realloc(p, s)	GC_realloc(p, s)
#define xrealloc(p, s)	GC_realloc(p, s)
#define calloc(m,n) GC_malloc((m)*(n)) /* gc malloc initialises it */
#if 1
#define free(p)		GC_free(p)
#else
#define free(p)		1	/* no frees - mud crashes less, but you'll never find the bugs! */
#endif

#else
extern char * xalloc(int);
#endif

/*
**	(old)	Leak fixing stuff
*/

#ifdef FIND_LEAKS

#include <sys/types.h>

extern int	leak_logging;
extern void	leak_dump(void);
extern void	leak_clear(void);

extern void	*leak_malloc(size_t, const char *, int);
extern void	*leak_realloc(void *, size_t, const char *, int);
extern void	leak_free(void *, const char *, int);
extern void	*leak_calloc(size_t, size_t, const char *, int);

#define malloc(s)	leak_malloc(s, __FILE__, __LINE__)
/* #define xalloc(s)	leak_malloc(s, __FILE__, __LINE__) */
#define realloc(p, s)	leak_realloc(p, s, __FILE__, __LINE__)
#define free(p)		leak_free(p, __FILE__, __LINE__)
#define calloc(s, t)	leak_calloc(s, t, __FILE__, __LINE__)

#endif

