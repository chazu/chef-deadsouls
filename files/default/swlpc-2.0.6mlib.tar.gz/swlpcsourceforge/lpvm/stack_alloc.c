/*
** $Id: stack_alloc.c,v 1.3 2002/01/24 00:29:29 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/stack_alloc.c,v $
** $Revision: 1.3 $
** $Date: 2002/01/24 00:29:29 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include <stdlib.h>
#include <stdio.h>
#include "stack.h"
#include "stack_access.h"
#include "stack_alloc.h"

void val_space() {};

/*
 * Stack/Value allocation stuff
 */
Val * make_space(int n)
{
    Val *ret;
#if 1
    ret = alloc_stack_value();
#else
    ret = alloc_value();
#endif
    ret->type = T_NUMBER;
    ret->u.number = n;
    return ret;
}

Val *val_stack;

extern FILE * errstream;

void Sinit_stack()
{
    val_stack = (Val *) malloc(sizeof(Val) * (MAXIMUM_STACK_VALUES+10000));
    errstream = stderr;
}

void free_stack_space()
{
    free(val_stack);
}

int new_frame()
{
    return 0;
}

void close_frame(int backto)
{
#if 0
    if (backto < 0)
    {
        /* ugly fix up */
        new_frame();
        printf("close_frame fuckup: %d\n", backto);
        backto = 0;
        if (FV < 0)
            FV = 0;
    }
#endif
    while (FV > backto)
    {
        free_value(&(val_stack[FV - 1]));
        --FV;
    }
    if (FV < 0)
    {
        fatal("Stack values frame depth too small.\n");
    }
}

Val * alloc_stack_value()
{
    if (FV >= MAXIMUM_STACK_VALUES)
    {
        /* probably an infinite loop - gotta be bad to values! */
        // wipe(FV - (CONTROL_NUM * 2 + 1));
        // overflow_flag = 1;
        val_space();
        stack_error("Out of value space - trying to recover.\n");
    }
    return &(val_stack[FV++]);
}

/*
 * Free values on the value stack back "a" items
 */
void wipe(int a)
{
    int  i;
    for (i = 0; i < a && FV; i++)
    {
        free_value(&(val_stack[FV - 1]));
        --FV;
    }
#if 0
    if (FV < 0)
    {  /* ack */
        fatal("wipe: negative value stack");
    }
#endif
}

/*
 * Pop the return value from the stack
 * and do a wipe() back "a" units.
 */
void clean(int a)
{
    int  i, z;

    STA(-1);
    z = a;
    for (i = 0; i < z && FV; i++)
    {
        free_value(&(val_stack[FV - 1]));
        --FV;
    }
#if 0
    if (FV < 0)
    {  /* ack */
        fatal("clean: negative value stack");
    }
#endif
}

/*
 * Pop the return value from the stack and copy it into "arg"
 * and do a wipe() back to "z"
 *
 * Note: does not free value being assigned to.
 */

void Clean(Val * arg, int z)
{
    Val *x;
    int  i;

    x = STpop;
    assign_value(arg, x);
    for (i = 0; i < z && FV; i++)
    {
        free_value(&(val_stack[FV - 1]));
        --FV;
    }
#if 0
    if (FV < 0)
    {  /* ack */
        fatal("Clean: negative value stack");
    }
#endif
}

#if 0
int show_stack_status()
{
    add_message("CT = %d, SP = %d, CBP = %d, BP = %d, FV = %d, off = %d\n",
                (rCT - (int) control) / PWIDTH, (rSP - (int) stack) / PWIDTH,
                (CBP - (int) control) / PWIDTH, (rBP - (int) stack) / PWIDTH,
                FV, total_offset);
    return (sizeof(Val) * MAXIMUM_STACK_VALUES);
}
#endif


void stack_array()
{
    Val *v;
    int  n, i, s;

    n = CTpop;  /* depth of array */
    if (!n)
    {
        STpush(allocate_array(0));
    }
    else
    {
        s = (STP(-n))->u.number;
        v = allocate_array(s);
        if (n != 1)
        {
            for (i = 0; i < s; i++)
            {
                v->u.vec->item[i].type = T_POINTER;
                v->u.vec->item[i].u.vec = alloc_deep_array(n - 1);
            }
        }
        STA(-n);
        STpush(v);
    }
}

struct vector * alloc_deep_array(int depth)
{
    int  i, s;
    struct vector *v;

    s = (STP(-depth))->u.number;
    v = create_vector(s, "stack.c:alloc_deep_array");
    if (depth == 1) return 0;
    for (i = 0; i < s; i++)
    {
        v->item[i].type = T_POINTER;
        v->item[i].u.vec = alloc_deep_array(depth - 1);
    }
    return v;
}

