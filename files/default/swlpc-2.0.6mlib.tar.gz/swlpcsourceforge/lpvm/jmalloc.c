#include "config.h"
#include "proto.h"
#define UNIX
/*
** malloc/free routines
** written by Jeff Tupper (tupper@cs.ubc.ca , i3130898@rick.cs.ubc.ca) 1991
** 4446 Lazelle Avenue, Terrace B.C., Canada, V8G 1R8
**
*****************************************************************************
**
** Copyright 1991 by Jeff Tupper
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided 
** that the above copyright notice appear in all copies and that both that 
** copyright notice and this permission notice appear in supporting 
** documentation, and that no fee is charged for any service or
** product of which this software or documentation are included in.
**
** Jeff Tupper makes no representations about the 
** suitability of this software for any purpose.  It is provided "as is"
** without express or implied warranty.
**
*****************************************************************************
**
** Version Date		Author		Changes
**
** 1	July 1991	Jeff Tupper	---
** 1.01 July 1994	Geoff Wong	Added in "magic numbers" for	
**					debugging purposes, there
**					appears to be a problem with Merging.
**
*****************************************************************************
**
** using binary trees for size
**
** location is held in a doubly linked list
** which is prefixed to each block:
** pointer to previous
** size (+ to location to get next block)
**
** have an array of sizes  <SmallSize
** of d-l lists
**
** smallest size malloc()able is 8 bytes
**
** same size blocks in the heap have a
** doubly-linked list running up down the
** spine (sizeq,sizep)
**
** there are SMALLTREE small heaps, holding
** free blocks varying SMALLTREEWIDTH in
** size (each heap holds, sizes 0-255,
** 256-511,512-767 ... for WIDTH == 8)
**
** when memory is run-out a list of clean
** functions are called, in order, 1 at a
** time, until enough memory is found or
** all clean(0) functions have been called
**
** if that fails, it allocates INCSIZE bytes
** from the system (sbrk() ) and uses more
** space - only done if total memory use is below
** HARDLIMIT
**
** if that fails, it then calls a list of
** clean functions with 1 as the parameter
**
** if there is still not enough memory,
** it goes through the list of clean functions
** 1 more time, with a parameter of 2
**
** it then returns NULL
**
** recap on memory:
**
** 1) call clean(0)		<-- if memory is being wasted, return now
** 2) sbrk() more		<-- get some more memory
** 3) call clean(1)		<-- try really hard to free() some memory
** 4) call clean(2+count) , return NULL
**			<-- can implement program quit phase if needed
**
** clean functions are registered with cleanerhire() call
** clean functions are deregistered with cleanerfire() call
**
** note that memory is never returned to the system.
**
** if > INCSIZE bytes are allocated at one time & sbrk is necessary, sbrk() will
** be called with the number of bytes allocated, rounded up to the nearest
** multiple of INCSIZE
**
** it initially starts with INITSIZE bytes
**
** Note: for non-contiguous blocks of memory (which may well happen under Mach)
** the last Block in each block will be of type EndBlock
** the size will be zero (to distingish between non-endblocks)
** and the next field points to the next block - the last global variable
** points to the last endblock (last in time, not in space)
**
** the first block has the same EndBlock type, and the next field
** points to the previous block (except for root, which is a FreeBlock)
**
** recognized labels:
**
** VERB : print all malloc(),free(),realloc(),calloc() calls for debugging purposes
** NOSTATS : doesn't keep stats on malloc(),free(),calloc(),realloc() calls
**
** MACH: compile for vm_allocate()
** UNIX: compile for sbrk()
**
** 1 of the above 2 must be defined (UNIX,MACH)
*/

extern int shutdown_size;

#ifdef MACH
#include <mach.h>
#endif

/* note: NeXT's don't seem to like it if you try to redefine these,
	so you will likely have to call the capitalized versions (comment
	these out).  [Xurbax]
*/
#ifndef USE_SYS_MALLOC
#ifndef FIND_LEAKS
#define Malloc malloc
#define Free free
#define Realloc realloc
#define Calloc calloc
#endif
#endif

#ifdef FIND_LEAKS
#include "leak.c"
#else

typedef void *MALLOCP;
typedef unsigned malloc_size;

#define stout add_message
#define fatal(message) {printf(message); exit(1);}

#ifndef NULL
#define NULL 0
#endif

/*#define DEBUG_MALLOC                    /* magic number stuff */

#ifdef DEBUG_MALLOC
#define MAGIC_FB        0xaaaaaaaa
#define MAGIC_UB        0xaaaaaaaa
#define MAGIC_EB        0xaaaaaaaa
/* #define MAGIC_UB        0x55555555
   #define MAGIC_EB        0x99999999 */

#define M_VERIFY(_X, _Y)  if ((_X)->magic != _Y) { \
                                printf("magic number fuckup\n"); \
                                abort(); }  
#define MSIZE 3		/* # of (long *) equivalents in UsedBlock! */
#else
#define M_VERIFY(_X, _Y) 
#define MSIZE 2
#endif

#define VOID	void /* bloody decstation compiler doesn't like void* */

typedef struct smallFreeBlock {
	VOID *prev;
	long size;
#ifdef DEBUG_MALLOC
	unsigned int magic;
#endif
	struct smallFreeBlock *prevs,*nexts;
} SmallFreeBlock;

typedef struct freeBlock {
	VOID *prev;
	long size;
#ifdef DEBUG_MALLOC
	unsigned int magic;
#endif
	struct freeBlock
	*sizel,         /** left child (smaller block)  **/
	*sizer,         /** right child (larger block)  **/
	*sizep,         /** parent                      **/
	*sizeq;         /** queue of same size (dwnward)**/
} FreeBlock;

typedef struct {
	VOID *prev;
	long size;
#ifdef DEBUG_MALLOC
	unsigned int magic;
#endif
} UsedBlock;

typedef struct endBlock {
	VOID *prev;		/** previous block		**/
	long size;		/** must be 0			**/
#ifdef DEBUG_MALLOC
	unsigned int magic;
#endif
	UsedBlock *next;	/** next block pointer		**/
} EndBlock;

static long 	malloc_total_memory,
  		malloc_memory_available;


static long 	malloc_count = 0,
		free_count = 0,
		stat_count = 0,
		detail_count = 0,
		realloc_count = 0,
		calloc_count = 0,
		sbrk_count = 0,
		warn_level = 0,
		clean_count[3] = {0,0,0};


/* size of sbrk() calls - 64K -
   ensure that it is a multiple of system page size */

#define INCSIZE 0x10000

/* initial size  - 256K */

#define INITSIZE 0x40000

typedef void (*Cleaner)(/*long*/); /* a pointer to a function returning void */
static Cleaner *cleaners;
static int cleaning_staff=0;	/** # of cleaners **/

/* must be at least sizeof(FreeBlock) */
#define SmallSize 256

/* must be >= sizeof(FreeBlock) */
#define MergeSize (sizeof(FreeBlock))
/* #define MergeSize 0 */

#define Array(array,element) array[element/4]

static SmallFreeBlock *Array(SmallTable,SmallSize);

#define MarkAsUsed(a) ((a)->size |= 0x80000000)
#define MarkAsFree(a) ((a)->size &= 0x7fffffff)

#define SMALLTREE 256
#define SMALLTREEWIDTH 8  /** 2^8 = 256 **/

static FreeBlock *root, *roots[SMALLTREE+1], *rooted[SMALLTREE+2];
static EndBlock *last;

MALLOCP		Malloc(malloc_size size);
void 		Free(MALLOCP ptr);
MALLOCP 	Realloc(MALLOCP ptr,malloc_size size);
MALLOCP 	Calloc(malloc_size elem,malloc_size size);
malloc_size 	MallocSize(MALLOCP block);

void 		CleanerHire(Cleaner new);
void 		CleanerFire(Cleaner old);
void 		CleanerWarnLevel(long level);

static int init_malloc = 1;

/*
** system independant sbrk() - returns address given,
** or NULL if none
**
** variable sbrk_cont is true if allocation is directly after last allocation
** it will be false after first allocation, most likely...
*/

static int sbrk_cont;

VOID *Sbrk(long bytes)
{
VOID *addr;
static VOID *last;

#ifdef MACH
	static int first = 1;
	kern_return_t ret;

	addr = last;
	ret = vm_allocate(task_self(),(vm_address_t *) &addr,bytes,first);
	if (ret != KERN_SUCCESS) {
		ret = vm_allocate(task_self(),(vm_address_t) &addr,bytes,TRUE);
		sbrk_cont = 0;
	}
	if (ret != KERN_SUCCESS) return(NULL);
#endif

#ifdef UNIX
	addr = (VOID *) sbrk(bytes);
	if (addr == (VOID *) -1) return(NULL);
#endif

	sbrk_cont = (last == addr);
	last = (VOID *)((char *) addr + bytes);

	sbrk_count++;

	return(addr);
}

/*
** initializes Malloc package
**
** returns 0 on failure (could not sbrk() INCSIZE bytes)
*/
int
MallocInit()
{
FreeBlock *block;
int i;

	if (init_malloc == 0) return 0;

	malloc_total_memory = malloc_memory_available = INITSIZE;

	for (i=0; i<SmallSize; i++) 
		Array(SmallTable,i) = NULL;

	root = (FreeBlock *) Sbrk(INITSIZE);
	if (root == NULL)
		 fatal("malloc: could not sbrk() first memory chunk");

	for (i=0;i<SMALLTREE;i++) {
		roots[i] = NULL; 
		rooted[i] = root;
	}
	rooted[i] = root;
	rooted[i+1] = root;

	roots[i] = root; 

	root->size = sizeof(FreeBlock);
#ifdef DEBUG_MALLOC
	root->magic = MAGIC_FB;
#endif
	root->sizep =
	root->prev =
	root->sizeq =
	root->sizel = (FreeBlock *)NULL;


#ifdef DEBUG_MALLOC
	block = root + 1;	/* +1 HUH? */
#else
	block = root + 1;	/* +1 HUH? */
#endif
	root->sizer = block;

	block->size = INITSIZE - sizeof(FreeBlock) - sizeof(EndBlock);
#ifdef DEBUG_MALLOC
	block->magic = MAGIC_FB;
#endif
	block->sizel = block->sizer = NULL;
	block->sizep = root;
	block->sizeq = NULL;
	block->prev = (VOID *)root;

	last = (EndBlock *) (((char *)root)+INITSIZE - sizeof(EndBlock));
#ifdef DEBUG_MALLOC
	last->magic = MAGIC_EB;
#endif
	last->size = 0;
	last->prev = (VOID *)block;
	last->next = NULL;

	MarkAsUsed(root);
	MarkAsUsed(last);

	init_malloc = 0;
	return 1;
}

/*
** finds the nearest sized block, that is a child of the given block
** works for size >= SmallSize
*/
static FreeBlock
*FindSizeChild(FreeBlock *block)
{
FreeBlock *near;

	if (block == NULL) return(NULL);

	if (near = block->sizer)
		while (near->sizel) near = near->sizel;
	else if (near = block->sizel)
		while (near->sizer) near = near->sizer;

	return(near);
}

/*
** sets the parents handle (either sizel or sizer) to the setting
*/
#define SetSizeParentHandle(node,setting) \
	if (node->sizep->sizel == node) node->sizep->sizel = setting; \
	else node->sizep->sizer = setting;

/*
** deletes a smallfreeblock from d-l list
*/
static void
DeleteSmallFreeBlock(SmallFreeBlock *block)
{
	M_VERIFY(block, MAGIC_FB);
	if (block->nexts)
		 block->nexts->prevs = block->prevs;
	if (block->prevs) 
		block->prevs->nexts = block->nexts;
	else
		 Array(SmallTable,block->size) = block->nexts;
}

/*
** sets the tree table to the new value
*/
static void
SetTreeTable(int bits,FreeBlock *block)
{
	if (bits < 0) {	/* we got problems! */
		printf("SetTreeTable bits fuckup: %d\n", bits);
		abort();
	}

	if (bits > SMALLTREE) bits = SMALLTREE -1;

	if (block)
	{
		 rooted[bits] = roots[bits] = block;
	}
	else
	{
		roots[bits] = NULL;
		rooted[bits] = rooted[bits+1];
	}

	while (bits--) {
		if (!roots[bits]) rooted[bits] = rooted[bits+1];
		else bits = 0;
	}
}

/*
** deletes a FreeBlock from the heap
** works for size >= SmallSize
**
** for size < SmallSize it removes from d-l list
*/
static void
DeleteFreeBlock(FreeBlock *node)
{
FreeBlock *replace;

	malloc_memory_available -= node->size;

	M_VERIFY(node, MAGIC_FB);

	if (node->size < SmallSize) {
		DeleteSmallFreeBlock((SmallFreeBlock *) node);
		return;
	}


	if (replace = node->sizeq)	/** update Q **/
	{
		M_VERIFY(replace, MAGIC_FB);
		if (node->sizep)
		if (node->sizep->sizeq == node)
		{
			node->sizep->sizeq = replace;
			replace->sizep = node->sizep;
			return;
		}
	}
	else
	{
		if ((node->sizep) &&(node->sizep->sizeq == node))
					/** bottom of Q **/
		{ 
			node->sizep->sizeq = NULL; 
			return; 
		}

		else	/** update tree **/
		if (replace = FindSizeChild(node))
		{
			M_VERIFY(replace, MAGIC_FB);
			if (replace->sizel)
			{
				SetSizeParentHandle(replace,replace->sizel); 
				replace->sizel->sizep = replace->sizep;
			}
			else if (replace->sizer)
			{
				SetSizeParentHandle(replace,replace->sizer); 
				replace->sizer->sizep = replace->sizep;
			}
			else SetSizeParentHandle(replace,NULL);
		}
	}

	if (replace)	/** update new node **/
	{
		M_VERIFY(replace, MAGIC_FB);
		if (replace->sizel = node->sizel) 
			replace->sizel->sizep = replace;
		if (replace->sizer = node->sizer)
			replace->sizer->sizep = replace;
		replace->sizep = node->sizep;
	}

	if (node->sizep)
	{ 
		SetSizeParentHandle(node,replace); 
	}
	else {
		SetTreeTable(node->size >> SMALLTREEWIDTH,replace);
	}

}

/*
** finds the best-fitting block of memory in
** the heap
** works for size >= SmallSize
*/
static FreeBlock *
BestFit(long size)
{
FreeBlock *curr,*last = NULL,*too_big = NULL;
long bits;
int first = 1;

	if ((bits = (size >> SMALLTREEWIDTH)) > SMALLTREE)
		bits = SMALLTREE;
	curr = roots[bits];

hack:

	if (curr == NULL) curr = rooted[bits];
	while (curr)
	{
		M_VERIFY(curr, MAGIC_FB);
		last = curr;

		if (curr->size > size) {
			too_big = curr;
			curr = curr->sizel;
		}
		else if (curr->size < size) curr = curr->sizer;
		else return(curr);
	}

	if (last->size < size) 
		if (too_big) return(too_big);
		else if (first) { 
			first = 0;
			bits++; 
			curr = NULL;
			goto hack;
		}
       		else return(NULL);
	else return(last);
}

/*
** Finds a block with similar size characteristics
** such that the given size can be placed as one of
** the children of the returned block
**
** works for size >= SmallSize
*/
static FreeBlock *
CloseFit(long size,FreeBlock *loc)
{
FreeBlock *curr;
long bits;

	M_VERIFY(loc, MAGIC_FB);
	if ((bits = (size >> SMALLTREEWIDTH)) > SMALLTREE)
		bits = SMALLTREE;

	if ((curr = roots[bits]) == NULL)
		return(NULL);

	while (1) {
		M_VERIFY(curr, MAGIC_FB);
		if (curr->size == size) return(curr);
	  	else {
		/** parent is not same size as request **/
		if (curr->size > size)
			if (curr->sizel)
				curr = curr->sizel;
			else return(curr);
		else
			if (curr->sizer)
				curr = curr->sizer;
			else return(curr);
		}
	}
}

static FreeBlock *dummy_free_block;

#define ActualSize(a) ((a)->size & 0x7fffffff)

/* returns block directly after */
#define DirectlyAfter(a) (FreeBlock *) ((char *) (a) + (a)->size)

/* returns block directly before */
#define DirectlyBefore(a) (FreeBlock *) ((a)->prev)

/* returns true if block is used */
#define BlockUsed(a) ((a)->size & 0x80000000)
#define BlockFree(a) (!BlockUsed(a))

/*
** adds a block to the heap
** with the dl-list it just attaches the next block back to the new one
** (the prev one should be ok, as the size is the indirect pointer)
**
** works for size >= SmallSize
**
** for size < SmallSize it ataches the block to its entry on the SmallTable
**
** if same size is in heap, attaches to Q
*/
static void 
AddFreeBlock(FreeBlock *block)
{
FreeBlock *next;

malloc_memory_available += block->size;

	if (block->size < SmallSize) {
		SmallFreeBlock *old_head = Array(SmallTable,block->size);

		if (old_head)
			 old_head->prevs = (SmallFreeBlock *) block;
#ifdef DEBUG_MALLOC
  		((SmallFreeBlock *) block)->magic = MAGIC_FB;
#endif
		((SmallFreeBlock *) block)->nexts = old_head;
		((SmallFreeBlock *) block)->prevs = NULL;
		Array(SmallTable,block->size) = (SmallFreeBlock *) block;
	 }
	 else {
		FreeBlock *parent;

		parent = CloseFit(block->size,block);

#ifdef DEBUG_MALLOC
  		block->magic = MAGIC_FB;
#endif
		block->sizel = NULL;
		block->sizer = NULL;
		block->sizeq = NULL;

		if (parent) {
		    if (parent->size > block->size)
			      parent->sizel = block;
		   else if (parent->size < block->size)
			      parent->sizer = block;
		   else { 
			if (block->sizeq = parent->sizeq) 
				block->sizeq->sizep = block; 
			parent->sizeq = block; 
		   }
	 	}
		else { 
			SetTreeTable(block->size >> SMALLTREEWIDTH,block); 
		}

		block->sizep = parent;
 	}

	next = DirectlyAfter(block);
	next->prev = (VOID *)block;
}

/*
** splits a FreeBlock into 2 FreeBlocks
** if possible, otherwise keeps FreeBlock intact
**
** it modifies the given block to be the given size,
** during splitting, if possible
*/
static void 
SplitFreeBlock(FreeBlock *block,long size)
{
FreeBlock *split;

	M_VERIFY(block, MAGIC_FB);

	if (block->size < size + sizeof(SmallFreeBlock))
		  return;  /** not enough space to split up **/

	split = (FreeBlock *) ((char *) block + size);

	split->size = block->size - size;
#ifdef DEBUG_MALLOC
	split->magic = MAGIC_FB;
#endif
	split->prev = (VOID *)block;
	AddFreeBlock(split);

	block->size = size;
#ifdef DEBUG_MALLOC
	block->magic = MAGIC_FB;
#endif
}

/*
** hires a cleaner
*/
void CleanerHire(Cleaner new)
{
	if (cleaning_staff)
		cleaners = (Cleaner *) Realloc((MALLOCP) cleaners,
				(cleaning_staff+1) * (sizeof(Cleaner)));
	else cleaners = (Cleaner *) Malloc(sizeof(Cleaner));

	cleaners[cleaning_staff++] = new; 	
		/** not done above, incase they get called during realloc **/
}

/*
** fires a cleaner
*/
void 
CleanerFire(Cleaner old)
{
int index;

	for (index=0;index<cleaning_staff;index++) { 
		if (cleaners[index] == old) 
			for (cleaning_staff--;index < cleaning_staff;index++)
			   cleaners[index] = cleaners[index+1];
	}
}

/*
** sets the current warning level
*/
void 
CleanerWarningLevel(long level)
{
	 warn_level = level;
}

/*
** moves the last block of memory up
** needed to be done, whenever sbrk()
** is called
*/
static void 
moveuplast(long shift)
{
EndBlock *oldlast = last;

	last = ((EndBlock *) ((char *) last + shift));
	last->size = 0;
#ifdef DEBUG_MALLOC
	last->magic = MAGIC_EB;
#endif
	last->next = NULL;
	MarkAsUsed(last);

	MarkAsFree(oldlast);  /** not really necesarry, look at next line **/
#ifdef DEBUG_MALLOC
	oldlast->magic = MAGIC_EB;
#endif
	oldlast->size = shift;

	last->prev = (VOID *)oldlast;

	AddFreeBlock((FreeBlock *) oldlast);
}

#define AlignSize(size) \
if (size <= 8) size = 16; /** 8 is minimum amount of malloc()ed memory **/ \
 else size = (size+11) & 0xfffffffc; /** round up to longword-aligned size **/

/*
** creates a non-contiguous block of malloc() memory
** needed by MACH, which may give back non-contiguous
** vm blocks
**
** note, there is no attempt to re-connect blocks
** so fragmentation will result because of this
** scheme (if previously allocated blocks become
** available to this module)
*/
static void addblock(/*void*/ int *start,long size)
{
UsedBlock *Start;
EndBlock  *End;
FreeBlock *Block;

	Start = (UsedBlock *) start;
	End = (EndBlock *) ((char *)start + size - sizeof(EndBlock));

	Start->size = sizeof(UsedBlock);
	End->size = 0;
	End->next = NULL;
#ifdef DEBUG_MALLOC
	Start->magic = MAGIC_UB;
	End->magic = MAGIC_EB;
#endif

	Block = DirectlyAfter(Start);
	Block->size = size - sizeof(UsedBlock) - sizeof(EndBlock);
#ifdef DEBUG_MALLOC
	Block->magic = MAGIC_FB;
#endif

	MarkAsUsed(Start);
	MarkAsUsed(End);

	Block->prev = (VOID *)Start;
	End->prev = (VOID *)Block;

	AddFreeBlock(Block);
	last->next = Start;	/** link the fragmented blocks together **/
	last = End;
}

/*
** attempts to get more memory, for Malloc()
*/
#define SHUTDOWN_SIZE shutdown_size
static int being_shut_down = 0;
#define HARDLIMIT (shutdown_size + 1000000)

static void *Coerce(long size)
{
int index;
VOID *block,*start;
static int coercing = 0;
extern int game_is_being_shut_down;
long sbrk_amount;
long actual_size = size;

	if (coercing) return NULL;
	coercing = 1;

	AlignSize(actual_size);

	clean_count[0]++;
	for (index=0;index<cleaning_staff;index++) 
		(*(cleaners[index]))(0);

	if (block = Malloc(size)) { 
		coercing = 0; 
		return(block); 
	}

	if (malloc_total_memory < HARDLIMIT) {
		sbrk_amount = INCSIZE * ((actual_size + INCSIZE - 1 
			+ sizeof(UsedBlock) + sizeof(EndBlock)) / INCSIZE);
		if ((sbrk_amount + malloc_total_memory) > HARDLIMIT)
			sbrk_amount = HARDLIMIT-malloc_total_memory;
					/** enfore the HARDLIMIT **/
		if (start = Sbrk(sbrk_amount)) {
			malloc_total_memory += sbrk_amount;

			if ((malloc_total_memory > SHUTDOWN_SIZE) && 
				!being_shut_down && !game_is_being_shut_down) {
				being_shut_down = 1;
				slow_shut_down(5);
			}

			if (sbrk_cont)
				moveuplast(sbrk_amount);
			else 
				addblock(start,sbrk_amount);

			block = (VOID *)Malloc(size);
			coercing = 0;
			return (block);
		}
	}

	clean_count[1]++;
	for (index=0;index<cleaning_staff;index++) 
			(*(cleaners[index]))(1);

	if (block = (VOID *)Malloc(size)) { 
		coercing = 0; 
		return(block); 
	}

	for (index=0;index<cleaning_staff;index++) 
		(*(cleaners[index]))(2+warn_level);
		clean_count[2]++;
	warn_level++;

	coercing = 0;
	return(NULL);
}

/*
** Allocates from the SmallTable
*/
FreeBlock *TableMalloc(long size)
{
SmallFreeBlock *block;

	if (size >= SmallSize) return(NULL);
	if ((block = Array(SmallTable,size)) == NULL) return(NULL);

	block = Array(SmallTable,size);
	if (Array(SmallTable,size) = block->nexts) 
			block->nexts->prevs = NULL;

	malloc_memory_available -= size;

	return((FreeBlock *) block);
}

/*
** allocates a block of given size (perhaps more)
** and return pointer to it, or NULL
** if OOM
*/
MALLOCP
Malloc(malloc_size size)
{
FreeBlock *free_block;
MALLOCP block;
long actual_size = size;
int i;

	if (init_malloc) MallocInit();

#ifndef NOSTATS
	malloc_count++;
#endif

	AlignSize(actual_size);
	if ((free_block = TableMalloc(actual_size)) == NULL) {
		free_block = BestFit(actual_size);
		if (free_block == NULL) return (Coerce(size));  /** OOM **/

		DeleteFreeBlock(free_block);
		SplitFreeBlock(free_block,actual_size); 
				/** if block too large, split it up **/
	}

	MarkAsUsed(free_block);
	block = (MALLOCP) ((long *) free_block + MSIZE);
#ifdef VERB
	stout("%08x = Malloc(%d)\n",block,size);
#endif
	return((MALLOCP) block);
}

/*
** returns the size of the given block
*/
malloc_size
MallocSize(MALLOCP block)
{
UsedBlock *used_block;

	used_block = (UsedBlock *) ((long *) block - MSIZE);

	return(ActualSize(used_block) - 8);
}

/*
** merges with the next block
*/
static void
MergeNext(FreeBlock *block)
{
FreeBlock *next;

        next = DirectlyAfter(block);

        M_VERIFY(block, MAGIC_FB);
        M_VERIFY(next, MAGIC_FB);

        if (BlockFree(next)) {
                DeleteFreeBlock(block);
                DeleteFreeBlock(next);
                block->size += next->size;
                AddFreeBlock(block);
        }
}

/*
** merges adjacent free blocks
*/
static void 
MergeAdjacent(FreeBlock *block)
{
FreeBlock *prev,*next;

        prev = DirectlyBefore(block);
        next = DirectlyAfter(block);

        M_VERIFY(block, MAGIC_FB);
        M_VERIFY(prev, MAGIC_FB);
        M_VERIFY(next, MAGIC_FB);

        if (BlockFree(prev)) {
                DeleteFreeBlock(block);
                DeleteFreeBlock(prev);
                prev->size += block->size;
                if (BlockFree(next)) {
                    DeleteFreeBlock(next);
                    prev->size += next->size;
                }
                AddFreeBlock(prev);
        }
        else
                MergeNext(block);
}

/*
** free a previously Malloc()ed block
*/
void
Free(MALLOCP block)
{
FreeBlock *Block;
int i;

#ifdef VERB
        stout("Free(%08x)\n",block);
#endif
#ifndef NOSTATS
        free_count++;
#endif

        if (block == NULL) return;      /** allow free(NULL), to be nice **/
        Block = (FreeBlock *) ((long *) block - MSIZE);

        M_VERIFY(Block, MAGIC_FB);

        MarkAsFree(Block);
        AddFreeBlock(Block);
        if (Block->size > MergeSize) MergeAdjacent(Block);

}

/*
** reallocate a block (make larger if possible, otherwise move)
*/
MALLOCP
Realloc(MALLOCP block,malloc_size size)
{
FreeBlock *Block;
MALLOCP   new;
#if 0
char memory[sizeof(FreeBlock)-sizeof(UsedBlock)];
#endif

#ifdef VERB
	stout("Realloc(%08x,%d)\n",block,size);
#endif
#ifndef NOSTATS
	realloc_count++;
#endif

	AlignSize(size);
        Block = (FreeBlock *) ((long *) block - MSIZE);
        M_VERIFY(Block, MAGIC_FB);

        if (ActualSize(Block) >= size) return(block);

        new = (MALLOCP) Malloc(size);
        bcopy(block, new, ActualSize(Block));
        Free(block);                            /* inline block */
        return ((MALLOCP) new);

#if 0
        bcopy(block,memory,sizeof(FreeBlock)-sizeof(UsedBlock));

        MarkAsFree(Block);
        AddFreeBlock(Block);

        while (BlockFree(DirectlyAfter(Block))) MergeNext(Block);

        DeleteFreeBlock(Block);
        MarkAsUsed(Block);
        bcopy(memory,block,sizeof(FreeBlock)-sizeof(UsedBlock));

        if (ActualSize(Block) >= size) return(block);

        if (new = (FreeBlock *) Malloc(size)) {
                bcopy(block,new,ActualSize(Block));
                MarkAsFree(Block);
                AddFreeBlock(Block);
                return((MALLOCP) new);
        }

        return((MALLOCP) new);
#endif
}

/*
** allocate a cleared block
*/
MALLOCP Calloc(malloc_size elem,malloc_size elsize)
{
MALLOCP new;

	long size = elem*elsize;

#ifndef NOSTATS
	calloc_count++;
#endif

	if (new = (MALLOCP)Malloc(size)) 	
			bzero(new,size);

#ifdef VERB
	stout("%08x = Calloc(%d,%d)\n",new,elem,elsize);
#endif

	return ((MALLOCP)new);
}

/*
** give out some stats in ASCII format
** must use a printf-like function
*/
void MallocStats()
{
int i;
stat_count++;

stout("    Total memory: %d\n",malloc_total_memory);
stout("     Free memory: %d\n",malloc_memory_available);
stout("    Used  memory: %d\n",malloc_total_memory-malloc_memory_available);
stout("   Shutdown size: %d\n\n",shutdown_size);
stout("  Min block size: 16 bytes\n");
stout("Small block size: %d bytes\n",SmallSize);
stout("Merge block size: %d bytes\n\n",MergeSize);
stout("     Small trees: %d\n",SMALLTREE);
stout("Small tree width: %d\n\n",SMALLTREEWIDTH);
stout("    Malloc calls: %d\n",malloc_count);
stout("      Free calls: %d\n",free_count);
stout("   Realloc calls: %d\n",realloc_count);
stout("    Calloc calls: %d\n",calloc_count);
stout("      Stat calls: %d\n",stat_count);
stout("    Detail calls: %d\n\n",detail_count);
stout("      Sbrk calls: %d\n",sbrk_count);
for (i=0;i<3;i++)
stout("    Clean%d calls: %d\n",i,clean_count[i]);
stout("   Warning level: %d\n",warn_level);
stout("   # of Cleaners: %d\n",cleaning_staff);
}

/*
** nice recursive descent through tree looking
** for info, returns max height
*/

long
MallocTreeDetails(FreeBlock *block,long *total_height,long *nodes,long depth,
        long *lefts,long *rights,long *smallest,long *largest)
{
FreeBlock *left,*right;
long lh,rh,dummy;

        M_VERIFY(block, MAGIC_FB);

        left  = block->sizel;
        right = block->sizer;
        depth++;

        if (left) {
                lh = MallocTreeDetails(left,total_height,nodes,depth,
                        lefts,rights,smallest,&dummy); 
                        (*lefts)++;
        }
        else { 
                lh = 0;
                (*smallest) = block->size;
        }
        if (right) {
                rh = MallocTreeDetails(right,total_height,nodes,depth,
                        lefts,rights,&dummy,largest); 
                        (*rights)++;
        }
        else { 
                rh = 0; 
                (*largest) = block->size; 
        }
        (*nodes)++;
        (*total_height) += depth;

        if (lh>rh) return(lh+1); 
        else return(rh+1);
}

#define LargeSize 256
#define LargeMults 16
#define HugeSize (LargeSize * LargeMults)

/*
** gives detailed, slow stats
*/
void MallocDetails()
{
int	Array(used,SmallSize),Array(free,SmallSize),
	USED[LargeMults],FREE[LargeMults],
	i,lfree,lused,corrupt,segments;
long	asize;
UsedBlock *block,*prev,*start;
long total_height,nodes,lefts,rights,max_depth,large,small;

detail_count++;

for (i=0;i<SmallSize;i+=4) Array(used,i) = Array(free,i) = 0;
for (i=0;i<LargeMults;i++) USED[i] = FREE[i] = 0;
lfree = 0;
lused = 0;
corrupt = 0;
segments = 0;

start = block = (UsedBlock *) root;

stout("Segment Start    End      Size     Size\n");

while (block != NULL)
 {
  asize = ActualSize(block);
  if (asize < SmallSize)
     if (BlockFree(block))
        Array(free,asize)++;
      else Array(used,asize)++;
   else if (asize < HugeSize)
     if (BlockFree(block))
	FREE[asize / LargeSize]++;
      else USED[asize / LargeSize]++;
   else if (BlockFree(block))
        lfree++;
      else lused++;
  prev = block;
  if (ActualSize(block) == 0)
    {
     asize = ((char *)block - (char *)start) + sizeof(EndBlock);
     stout("%7d %08x %08x %08x %d\n",segments,start,(char *)start + asize,asize,asize);
     start = block = ((EndBlock *)block)->next;
     segments++;
    }
   else
    {
     block = (UsedBlock *) (((char *) block) + ActualSize(block));
     if (prev != (UsedBlock *) block->prev) corrupt++;
    }
 }

stout("\nSIZE     USED   FREE\n");
stout("--------------------\n");
for (i=4;i<SmallSize;i+=4)
 stout("%5d  %6d %6d\n",i,Array(used,i),Array(free,i));
for (i=0;i<LargeMults;i++)
 stout("%5d  %6d %6d\n",(i+1)*LargeSize,USED[i],FREE[i]);
stout("Large  %6d %6d\n\n",lused,lfree);
stout("%d corrupt link(s)\n\n",corrupt);

stout("TREE Nodes Left Right Depth Avg Depth Smallest Largest\n");
for (i=0;i<SMALLTREE;i++)
 if (roots[i])
 {
  total_height = nodes = lefts = rights = 0;
  max_depth = MallocTreeDetails(roots[i],&total_height,&nodes,0,&lefts,&rights,&small,&large);
  stout("%4d %4d %4d %5d %5d   %f %8d %7d\n",
	i,nodes,lefts,rights,max_depth,(float) total_height / (float) nodes,small,large);
 }
if (root->sizer)
 {
  total_height = nodes = lefts = rights = 0;
  max_depth = MallocTreeDetails(root->sizer,&total_height,&nodes,0,&lefts,&rights,&small,&large);
  stout("MAIN %4d %4d %5d %5d   %f %8d %7d\n",
	nodes,lefts,rights,max_depth,(float) total_height / (float) nodes,small,large);
 }

}

/* for lpmud */

int debugmalloc = 1;

void
dump_malloc_data() { 
#ifdef USE_SYS_MALLOC
	add_message("Using system malloc\n");
#else
	if (debugmalloc) MallocDetails();
	MallocStats();
#endif
}

resort_free_list() { 
	return 0; 
}	
#endif
