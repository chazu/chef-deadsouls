/*
** $Id: error.c,v 1.6 2003/06/07 08:22:21 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/error.c,v $
** $Revision: 1.6 $
** $Date: 2003/06/07 08:22:21 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

/*
** Error handling and support stuff below.
** Still pretty ugly; needs to be cleaned up.
** Line number and variable name support needs to be added!
*/

#include <stdlib.h>
#include <stdio.h>
#include "stack_access.h"
#include "stack_alloc.h"
#include "stralloc.h"

extern void 
    catchable_error(),
    terminal_error()
    ;

Shared * backtrace(int)
    ;

FILE * errstream = NULL;

void inf_loop() {};

void Serror_stream(FILE * f)
{
    if (f == NULL) errstream = stderr;
    else errstream = f;
}

char * find_function()
{
    int  RA;
    byte tmp[4], e;
    char *fun;

    RA = CBP_RA;
    if (RA)
    {  /* ok - can we get function name? */
        e = *((byte *) ((int) RA - 5));
        if (e == S_CALLO)
        {
            tmp[0] = (*((byte *) ((int) RA - 1)));
            tmp[1] = (*((byte *) ((int) RA - 2)));
            tmp[2] = (*((byte *) ((int) RA - 3)));
            tmp[3] = (*((byte *) ((int) RA - 4)));
            fun = (char *) *((unsigned long *) tmp);
            return fun;
        }
    }
    return NULL;
}

/*
 * Given a program counter, find the enclosing function.
 * Returns null if the function isn't in the code segment for
 * the given object.  Doesn't look at inherited funcs.
 */

Func * find_local_header(Class * ob, byte * pc)
{
    Func *f = ob->prog;

    if (ob == NULL) return NULL;
    if (pc == NULL) return NULL;

    while (f)
    {
        if ((pc >= f->block) && (pc < (f->block + f->size)))
            return f;
        f = f->next;
    }

    return NULL;
}


/*
 * Given an object and a PC, find which function or inherited function
 * contains the object.  NOTE: We SHOULD also return which object it was,
 * if it's found in an inherited object.
 */

Func * find_func_header(Class * ob, byte * pc)
{
    int  x = 0;
    Func *f;
    
    if (ob == NULL) return NULL;
    if (pc == NULL) return NULL;

    f = find_local_header(ob, pc);
    if (f) return f;

    if (ob->inherit)
    {
        for (x = 0; ob->inherit[x]; x++)
        {
            f = find_func_header(ob->inherit[x], pc);
            /* inherits are flat, right?  No.. */
            if (f)
                return f;
        }
    }

    return NULL;
}

static char emsg_buf[2000];
#define MAX_MESSAGE 512

void stack_error(const char *fmt,...)
{
    int  fv, instr = -1;
    char *fun;
    char s[MAX_MESSAGE];
    va_list args;
    Func *prog;


    va_start(args, fmt);
    vsprintf(s, fmt, args);
    va_end(args);

#if 0
    printf("BE: %s (t:%d)\n", currentO->name, total_offset);
    printf("stack_error: %s\n", s);
#endif
    // hack to try and resolve constant problems.
    initfixedints();

    if (CATCHBP == (int) control || overflow_flag)
    {
        if (!overflow_flag)
        {
            fprintf(errstream, "\n*Uncaught error : ");
        }
        else
        {
            fprintf(errstream, "\n*Possible infinite loop error: ");
            // inf_loop();
        }

        prog = find_func_header(currentO->code, sPC);
        if (!prog)
        {
            fun = last_fun;
        }
        else
        {
            fun = prog->name->str;
            instr = (int) sPC - (int) (prog->block);
        }
        output_error(s, fun, instr);
        if (overflow_flag) 
        {
            terminal_error();
        }
        else
        {
            catchable_error();
        }
    }
    else
    {

        prog = (Func *) CBP_FUNC;

        if (!prog)
        {
            fun = last_fun;
        }
        else
        {
            fun = prog->name->str;
            instr = (int) sPC - (int) (prog->block);
        }


        rCT = CATCHBP;
        fv = CTpop;
        sPC = (byte *) CTpop;
        if (sPC == 0) output_error(s, fun, instr);
        CBP = CTpop;
        rBP = CTpop;
        rSP = CTpop;
        // if (sPC != 0) STA(-1);
        /* should we also restore total_offset in here? 
         * only if we enter()ed another stack frame and 
         * the error occurred in that stack frame I think */
        total_offset = CBP_OFFSET;  /* ick */
        CATCHBP = CTpop;

        /* this shouldn't happen! */
        if ((CATCHBP - (int) control) > CSTACK_OFLOW * PWIDTH)
        {
            // CATCHBP = (int) control;
            fprintf(errstream, "WARNING: unrecoverable control stack overflow!\n");
            if (sPC != 0) output_error(s, fun, instr);
            terminal_error();
        }

        currentO = (Obj *) CBP_OBJ;
#ifdef SDEBUG
        if (currentO) printf("Sset_current (stack_error): %s\n", currentO->name->str);
        else printf("Sset_current (stack_error): 0\n");
#endif


#if 0
        if (CBP >= ((int) control + CONTROL_NUM * PWIDTH))
        {
            currentO = CBP_OBJ;
        }

        if (sPC != NULL)
        {
            if (currentO)
            {
                printf("CO = %s: ", currentO->name);
                if (fun)
                    printf("%s\n", fun);
                else
                    printf("\n");
            }
            /* Set a new current object if we're still executing */
            if ((rBP - CBP_ARGS - 1 >= (int) control) 
                                && (STbase(-CBP_ARGS - 1)))
            {
                currentO = (STbase(-CBP_ARGS - 1))->u.ob;
            }
        }
#endif
#if 0
        printf("CATCHBP (set:stack_error) = %d\n", (int)(CATCHBP-(int)control));
        fflush(0);
        printf("CE: %s @ %d (t:%d)\n", currentO->name, (int) sPC,
               total_offset);
#endif
        close_frame(fv);

        if (FV >= MAXIMUM_STACK_VALUES)
        {
            fprintf(errstream, "WARNING: unrecoverable stack overflow!\n");
            if (sPC != 0) output_error(s, fun, instr);
            terminal_error();
        }

        /* leave the error string on top of the stack */
        STpush(make_string(s));
        if (!sPC) catchable_error();
    }
}

/*
 * Be aware output error (may) call catch_output
 * which resets error_flag.
 * 
 * If the error is in catch_output then we have big problems!
 * (ie. can infinite loop - so we have a quick hack to avoid it!)
 */
void output_error(char *s, char *fun, int instr)
{
    char *globname = 0;
    Shared * bt;

    /* all system errors get a * at the start */
    emsg_buf[0] = '*';
    emsg_buf[1] = '\0';

    if (currentO)
    {
        if (last_global != NON_VAR && last_global >= 0 &&
            last_global < currentO->code->num_variables)
        {
            globname = currentO->code->global_table[last_global]->u.string->str;
        }
        sprintf(emsg_buf + strlen(emsg_buf),
                "%s in %s (%s:%d) [lg=%s, ll=%d];\n",
             s, currentO->name->str, 
        (currentO->su_name ? currentO->su_name->str : "Game driver"),
        currentO->level, globname ? globname : "unknown", last_local);
        bt = backtrace(instr);

#if 0
        debug_message("%s", emsg_buf + 1);

        /* output to screen - with hack to avoid infinite loop! */
        if (last_fun == C("catch_output"))
        {
            /* fatal("Error in catch_output (probably another problem).\n"); */
            return;
        }

        /* FIX: need some way to retun an error to the invoker */
        if (command_giver && !overflow_flag)
            add_message("%s", emsg_buf + 1);
#else
        fprintf(errstream, "\n%s%s", emsg_buf, bt->str);
        fflush(errstream);
        free_string(bt);
        /* if (errstream != stderr) fprintf(stderr, "%s", emsg_buf); */

#endif
    }
#if 0
    else
    {
        debug_message("%s with no current object.\n", s);
    }
#endif
}

/*
 * this if for error that occur in efuns (hence the rest
 * or the efun code gets called after returning).
 * We simply duplicate the top of stack because
 * efun() nukes the extra value (expected return value).
 */

static int in_efun_error = 0;
void efun_error(const char *fmt,...)
{
    char buff[MAX_MESSAGE];
    va_list args;

    va_start(args, fmt);
    vsprintf(buff, fmt, args);
    va_end(args);

    in_efun_error = 1;
    stack_error(buff);

#if 0
    /* duplicate top of stack because efun() nukes it.. */
    if (in_efun_error)
    {
        STP(0) = STtop;  
        STA(1);
        efun_error = 0;
    }
#endif
}


/*
 * Type checking stuff.
 * 
 * The bytes before ENTER() are type checking info.
 * We check it at the line doing to the function call.
 * 
 * We temporarily use sPC;
 */
int stype_check(unsigned char *pc, int args, char *objname, char *funname)
{
    int  a, i = 0, tpe;
    Val *x;
    byte *oldpc = sPC;
    a = 0;
    for (a = 0; a < args; a++)
    {
        if (pc[i] != S_TYPEC)
        {
            fatal("FATAL: Illegal type block called from %s\n",
                  currentO->name->str);
        }
        else
        {
            x = STP(-(a + 1));
            sPC = (byte *) ((unsigned int) pc + i + 1);
            tpe = (unsigned int) INST16;
            if (!(x->type & tpe))
            {
                sPC = oldpc;
                stack_error("Type mismatch in argument (%d) calling (%s:%s)\n",
                            (args - a), objname, funname);
                return 0;
            }
            i += 3;
        }
    }

    /* safety check */
    if (pc[i] != S_ENTER)
    {
        fatal("FATAL: Incorrect type block called from %s\n", currentO->name->str);
    }
    sPC = oldpc;
    return 1;
}


/*
 * Name: get_line
 * Purpose: work out what line number this instruction relates to
 */

int get_line(Func * f, int instr)
{
    int x;

    if (instr < 0) return 0;

    for (x = 0; x < f->num_lines; x++)
    {
        if (instr < f->linemap[x]) break;
    }
    return x - 1;
}

/*
 * Name: Backtrace
 * Purpose: Build a string which is a backtrace of the calls to 
 *  reach the current point in execution.
 */

#define MAX_NUM_LEN 32
#define MAX_BT 32

Shared * backtrace(int instr)
{
    Shared * ret = string_copy("\t");
    int  a, oCBP = CBP, pCBP, first = 0, line, oRA = 0;
    Func * fun;
    Obj * ob;
    char buf[MAX_NUM_LEN];
    int count = 0;

    while (((CBP - (int) control) > CONTROL_NUM * 2 - 1) && count++ < MAX_BT)
    {
        a = CBP_ARGS;
        fun = (Func *) CBP_FUNC;
        ob = (Obj *) CBP_OBJ;
        if (ob != NULL)
            ret = string_cat(ret, ob->name);
        else
            ret = stringstr_cat(ret, "unknown_obj");
        ret = stringstr_cat(ret, ":");
        ret = string_cat(ret, fun->name);
        ret = stringstr_cat(ret, " (line ");


        if (first != 0) 
            instr = (int) oRA - (int) (fun->block);
        line = fun->line + get_line(fun, instr);

        sprintf(buf, "%d", line);
        ret = stringstr_cat(ret, buf);
        ret = stringstr_cat(ret, ")\n\t");
        first = 1;
        pCBP = CBP;
        oRA = CBP_RA;
        CBP = CBP_CBP;
        if (pCBP == CBP) 
        {
            ret = stringstr_cat(ret, "SERIOUS loop in control stack.\n\t");
            break;
        }
    }
    CBP = oCBP;

    return ret;
}
