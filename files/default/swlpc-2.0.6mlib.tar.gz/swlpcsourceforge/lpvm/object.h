/*
 * Definition of an object. If the object is inherited, then it must not be
 * destructed !
 
 * Really I'd like to have two object structures (I guess we needs "types"
 * of object (as well as object type signatures):
 * 	- named objects (as below)
 *	- unnamed objects which are essentially "classes"
 *	(these would be a similar but much smaller struct).
 * 	These could have their variables accessed via
 *	"named" fields (ie. the names of the variables);
 *	although we'd need to "import" the definition so we
 * 	didn't need to carry about the global names. hmm..
 *	
 *	-- Geoff
 */

#ifndef _OBJECT_H
#define _OBJECT_H

#include "magic.h"
#include "stralloc.h"

struct object;
struct vector;
struct vector_regexp;

union u 
{
    Shared * string;
    int number;
    float real; /* check that it fits :) */
    struct object * ob;
    struct vector * vec;
    struct vector_regexp * reg;
};

struct value 
{
    union u u;
    int type;
};
typedef struct value Val;


struct object 
{
#ifdef SHMAGIC
    void * magic[2];
#endif
    char        enable_commands;	/* Enable usage of sentence commands */
    char        cloned;	            /* A cloned object - pointless. */
    char        destructed;	        /* True when the object is destructed */

    unsigned short  ref;	        /* Reference count. */
    unsigned short  level;	        /* capability based security */
    struct CLASS    * code;         /* class we're cloned from */

    struct interactive *interactive;	
                    /* Data about an interactive player */
					/* do we give a shit? should this */
					/* be passed into LPC and forgotten here? */

    /* named object stuff (as opposed to class stuff) */
    Shared          * name;
    Shared          * su_name;	/* playername for owner */
    struct object   * next_inv, *next_hash;
    struct object   * contains;
    struct object   * super;	/* Which object surround us ? */

    struct value    variables[1];	
                    /* All variables to this program */
				    /* nice to be of T_POINTER type.. */

};

typedef struct object Obj;

/* new object stuff */

struct CLASS 
{
    char inherited;
    char file_was_suid;	                /* this is kind of ugly */
    unsigned short  ref;			    /* Reference count. */

    unsigned short  num_variables;	    /* Number of variables (total) */
    unsigned short	num_constants;	    /* number of constants */

    Shared          * name;             /* file we originally came from */

    struct function_def * prog;
    struct value    ** global_table;  	/* sigh */
    struct constval ** constant_table;	/* ho hum */
    struct CLASS    ** inherit;	        /* Where to inherit from */
			                            /* a list of inheritance pointers */
    int	 	        * inherit_offsets;
};

typedef struct CLASS Class;

struct OBJECT 
{
    unsigned short  ref;			/* Reference count. */
    char        destructed;	        /* True when the object is destructed */
    char        enable_commands;	/* Enable move_object support */
    Class * code;

    // Stuff it'd be nice to handle in others ways
    // and not carry around with every object
    Shared          * name;
    Shared          * su_name;	/* playername for owner */
    struct object   * next_inv, *next_hash;
    struct object   * contains;
    struct object   * super;	/* Which object surround us ? */
    int             level;	    /* capability based security */
    struct interactive *interactive;	
            /* Data about an interactive player */

    struct value    * variables;	
                    /* All variables to this program */
				    /* nice to be of T_POINTER type.. */
};

typedef struct OBJECT Object;

extern struct object *current_object, *command_giver;
extern struct object *obj_list;

/* Runtime definitions - mud only */
void    remove_destructed_objects(),
        add_ref (struct object *, char *),
        free_object (struct object *, char *);

extern int show_otable_status ();

extern Obj
    * get_empty_object(),
    * find_object(Shared *),
    * find_object2(Shared *),
    * find_object_cstr(char *),
    * instantiate_class(Class * code),
    * load_object(Shared *name)
    ;

void add_functions(Class * obj, Class * which_obj, short offset),
    remove_functions(Class * obj, Class * which_obj)
    ;

#endif

