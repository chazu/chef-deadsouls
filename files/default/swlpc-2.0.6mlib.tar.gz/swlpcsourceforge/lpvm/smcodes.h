/*
**	Copyright (C), Geoff Wong, June 1993.
**
**	All code contained herein was written by Geoff Wong (unless
**	otherwise explicitly mentioned).
**	The code may not be copied without explicit permission
**	from the author (Geoff Wong).
**	The code may not be used as part of a package or a service 
**	requiring monetary recompense without explicit written permission
**	from the author (Geoff Wong).
**
**	Geoff Wong, email address :- geoff@serc.rmit.edu.au
*/

#define S_END		0
#define S_PUSHC		1 
#define S_ADDIND 	2
#define S_ADDSP 	3
#define S_AGGREGATE 	4
#define S_AND 		5
#define S_CALL 		6
#define S_CALLO 	7
#define S_CALL_OUT 	8
#define S_CATCH 	9
#define S_COPY 		10
#define S_PUSHG	        11
#define S_DIVIDE 	12
#define S_EFUN 		13
#define S_ENTER 	14
#define S_EQ 		15
#define S_GE 		16
#define S_GT 		17
#define S_LT		18
#define S_JNZERO 	19
#define S_JUMP 		20
#define S_JUMPU 	21
#define S_JZERO 	22
#define S_LAND 		23
#define S_LE 		24
#define S_LNOT 		25
#define S_LOR 		26
#define S_LSH 		27
#define S_MINUS 	28
#define S_MOD 		29
#define S_POPG	 	30
#define S_MULT 		31
#define S_NE 		32
#define S_NEGATE 	33
#define S_NOT 		34
#define S_OR 		35
#define S_PLUS 		36
#define S_PUSH8		37
#define S_POPCATCH 	38
#define S_POPL 		39
#define S_PUSH 		40
#define S_RETURN 	41
#define S_RSH 		42
#define S_THROW 	43
#define S_TYPEC 	44
#define S_XOR 		45
#define S_PUSHL		46
#define S_CALLU		47	/*-117 */
#define S_EFUND 	48
#define S_POPI		49
#define S_PUSHi		50
#define S_CALLOF	51
#define S_POPO		52
#define S_PUSHr         53
#define S_PUSHs		54
#define S_ARR_ALLOC	55
#define S_OFLOW_CHECK   56
#define S_PUSHCi	57
#define S_SWITCH	58

#define MAX_SMCODES 	59

struct var_def {
	int type;
	Shared * name;
	struct value * v;
	struct var_def * next;
	};

#define NONE  -999

void  
   my_end(), addind(), addsp(), aggregate(), and(), calln(), callo(),
   call_out(), catch(), copy(), divide(), efun(), enter(), eq(), ge(),
   gt(), jnzero(), jump(), undefined(), jzero(), land(), le(),
   lnot(), lor(), lsh(), minus(), mod(), moveb0(), mult(), ne(),
   negate(), not(), or(), popcatch(), popl(), pushl(), lt(), oflow_check(),
   _return(), rsh(), throw(), typec(), xor(), pushl(), plus(), push(),
   pushc(), pushg(), popg(), smextract(), popi(), pushi(), callu(),
   Callo(), Popcatch(), push8(), popo(), pushr(), pushs(), stack_array(),
   pushci(), my_switch(), efun_direct()
	;

#define GLOBAL 1
#define LOCAL 0
#define INDEX_TY 2
#define AGGREGATE 3

#define byte unsigned char

/*
 * Modifications for dbx - mmcg.
 */

#define       SA_NONE         0       /* no args */
#define       SA_EFUN         1       /* a kcall, int8 */
#define       SA_SMCADDR      3       /* 32 bit stack machine code address */
#define       SA_SMCR16       4       /* stack machine code offset - 16 bits */
#define       SA_CSTRING      5       /* a string pointer */
#define       SA_INT8         6       /* a byte interpreted as an int */
#define       SA_INT16        7
#define       SA_INT32        8       /* inline 32 bit int */
#define       SA_REAL         9       /* inline float (32 bit storage) */
#define       SA_TYI16        10      /* inline type mask */
#define       SA_GLOBREF      11      /* global var ref (an int8) */
#define       SA_LOCREF       12      /* local var ref (an int8) */
#define       SA_VALPTR       13      /* local var ref (an int8) */

struct otbl {
      char * name;
      int scode;
      int argtype;
      };

extern struct otbl codes[];
