

/*
** $Id: fatal.h,v 1.1.1.1 2001/09/11 04:12:12 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/fatal.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:12 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/


/*
** Error handling stuff
*/

#ifndef _FATAL_H
#define _FATAL_H

#include <stdio.h>
#include <stdarg.h>

void fatal(const char *fmt,...);


#endif
