/*
 * Just to see if we can fiddle the assembly to make it faster
 * It's certainly much faster than the thread safe glibc strcpy...
 */

char * strncpy(char * t, char * f, int n) 
{
    register char * nt;
    nt = t;
    while ((n--) > 0 && (*(nt++) = *(f++)))
	;
    return t;
}
