/*
** $Id: stack_alloc.h,v 1.1.1.1 2001/09/11 04:12:16 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/stack_alloc.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:16 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _STACK_ALLOC_H
#define _STACK_ALLOC_H

#include "value.h"

Val 
    * alloc_stack_value(),
    * make_space(int n)
    ;

struct vector 
    * alloc_deep_array(int depth)
    ;

int 
    new_frame(),
    show_stack_status()
    ;

void 
    stack_array(),
    wipe(int a),
    free_stack_space(),
    close_frame(int backto),
    clean(int a),
    Clean(Val * arg, int z),
    Sinit_stack()
    ;

#endif

