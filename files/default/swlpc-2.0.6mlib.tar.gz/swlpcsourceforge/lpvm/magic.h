
/*
** $Id: magic.h,v 1.2 2001/10/30 12:03:39 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/magic.h,v $
** $Revision: 1.2 $
** $Date: 2001/10/30 12:03:39 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _MAGIC_H
#define _MAGIC_H

// #define SHMAGIC 

#define SMAGIC1 0xFEC3
#define SMAGIC2 0xAF09

#define OMAGIC1 0xEFC7
#define OMAGIC2 0xBEF5

#endif

