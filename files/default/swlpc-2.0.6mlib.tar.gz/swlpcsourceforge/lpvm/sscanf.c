/* miscellaneous hack */

/*
 * This is an EVIL fucked up function that needs to
 * be exterminated!
 * 
 * Why? - because it's not pass by value like everything
 * else in the language (well except arrays aren't copied
 * either).
 */
#define type_check(a,b,c,d) { if (!(a) || !((a)->type & (b))) \
{ type_error(a,b,c,d); return; } }

/*
 * needed for inter_sscanf
 */
char * find_percent(char *str)
{
    while (1)
    {
        str = strchr(str, '%');
        if (str == 0)
            return 0;
        if (str[1] != '%')
            return str;
        str++;
    }
    return 0;
}

void inter_sscanf()
{
    Val *p;
    char *fmt;                  /* Format description */
    char *in_string;            /* The string to be parsed. */
    int  matches, nargs = 0, argc;
    char *cp;

    /*
     * First get the string to be parsed.
     */
    nargs = CTpop;
    if (nargs < 3)
    {
        efun_error("Not enough args to sscanf()\n");
        return;
    }
    p = STP(-nargs);

    type_check(p, T_STRING | T_OBJECT, "sscanf", 1);
    if (p->type == T_STRING)
        in_string = p->u.string;
    else
        in_string = p->u.ob->name;
    if (in_string == 0)
    {
        STA(-nargs);
        STpush(Const(0));
        return;
    }

    /*
     * Now get the format description.
     */
    p = STP(-nargs + 1);
    type_check(p, T_STRING, "sscanf", 2);
    fmt = p->u.string;
    /*
     * First, skip and match leading text.
     */
    for (cp = find_percent(fmt); fmt != cp; fmt++, in_string++)
    {
        if (in_string[0] == '\0' || fmt[0] != in_string[0])
        {
            STA(-nargs);
            STpush(Const(0));
            return;
        }
    }
    /*
     * For every % or substring in the format.
     */
    argc = nargs - 2;
    for (matches = 0; matches < argc; matches++)
    {
        int  i, type;

        if (fmt[0] == '\0')
        {
            /*
             * We have reached end of the format string. If there are any
             * chars left in the in_string, then we put them in the last
             * variable (if any).
             */
            if (in_string[0])
            {
                /* free first! */
                assign_value(STP(-(argc - matches)),
                             share_string(in_string));
                matches++;
            }
            break;
        }
        if (fmt[0] != '%')
            fatal("Should be a %% now !\n");
        type = T_STRING;
        if (fmt[1] == 'd')
            type = T_NUMBER;
        else if (fmt[1] == 'f')
            type = T_REAL;
        else if (fmt[1] != 's')
        {
            efun_error("Bad type specification : '%%%c' in sscanf fmt string.",
                       fmt[1]);
            return;
        }
        fmt += 2;
        /*
         * Parsing a number is the easy case. Just use strtol() to find the
         * end of the number.
         */
        if (type == T_NUMBER)
        {
            extern long strtol();
            char *tmp = in_string;
            int  tmp_num;

            tmp_num = (int) strtol(in_string, &in_string, 0);
            if (tmp == in_string)
            {
                /* No match */
                break;
            }
            /* free first? */
            clear_assign(STP(-(argc - matches)), make_number(tmp_num));
            while (fmt[0] && fmt[0] == in_string[0])
                fmt++, in_string++;
            if (fmt[0] != '%')
            {
                matches++;
                break;
            }
            continue;
        }
        if (type == T_REAL)
        {
            extern double strtod();
            char *tmp = in_string;
            float tmp_num;

            tmp_num = (float) strtod(in_string, &in_string);
            if (tmp == in_string)
            {
                /* No match */
                break;
            }
            /* free first? */
            clear_assign(STP(-(argc - matches)), make_real(tmp_num));
            while (fmt[0] && fmt[0] == in_string[0])
                fmt++, in_string++;
            if (fmt[0] != '%')
            {
                matches++;
                break;
            }
            continue;
        }
        /*
         * Now we have the string case.
         */
        cp = find_percent(fmt);
        if (cp == fmt)
        {
            STA(-nargs);
            efun_error("Illegal to have 2 adjacent %'s in fmt string in sscanf.");
            return;
        }
        if (cp == 0)
            cp = fmt + strlen(fmt);
        /*
         * First case: There was no extra characters to match. Then this is
         * the last match.
         */
        if (cp == fmt)
        {
            /* free first ? */
            clear_assign(STP(-(argc - matches)), share_string(in_string));
            matches++;
            break;
        }
        for (i = 0; in_string[i]; i++)
        {
            if (strncmp(in_string + i, fmt, cp - fmt) == 0)
            {
                char *match;
                /*
                 * Found a match !
                 */
                match = malloc(i + 1);
                (void) strncpy(match, in_string, i);
                in_string += i + (cp - fmt);
                match[i] = '\0';
                /* free first? */
                clear_assign(STP(-(argc - matches)), share_string(match));
                free(match);
                fmt = cp;  /* Advance fmt to next % */
                break;
            }
        }
        if (fmt == cp)  /* If match, then do continue. */
            continue;
        /*
         * No match was found. Then we stop here, and return the result so
         * far !
         */
        break;
    }
    STA(-nargs);
    STpush(make_number(matches));
}

