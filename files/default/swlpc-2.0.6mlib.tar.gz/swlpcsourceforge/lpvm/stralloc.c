
/*
** $Id: stralloc.c,v 1.3 2003/01/31 04:14:46 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/stralloc.c,v $
** $Revision: 1.3 $
** $Date: 2003/01/31 04:14:46 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include "fatal.h"
#include "stralloc.h"
#include "magic.h"

/* #define DEBUG_STRING   */

/*
 * stralloc.c - string management.
 * 
 * All strings are stored in an extensible hash table, with reference counts.
 * free_string decreases the reference count; if it gets to zero, the string
 * will be deallocated.  add_string increases the ref count if it finds a
 * matching string, or allocates it if it cant.  There is no way to allocate
 * a string of a particular size to fill later (hash wont work!), so you'll
 * have to copy things freom a static (or malloced and later freed) buffer -
 * that is, if you want to avoid space leaks...
 * 
 * Current overhead: 8 bytes per string (next pointer, and 2 shorts for length
 * and refs) Strings are nearly all fairly short, so this is a significant
 * overhead- there is also the 4 byte malloc overhead and the fact that
 * malloc generally allocates blocks which are a power of 2 (should write my
 * own best-fit malloc specialised to strings); then again, GNU malloc is bug
 * free...
 */


int             num_distinct_strings = 0;
int             bytes_distinct_strings = 0;
int             overhead_bytes = 0;
static int      allocd_strings = 0;
static int      allocd_bytes = 0;
static int      search_len = 0;
static int      num_searches = 0;


/*
 * hash table - list of pointers to heads of string chains. Each string in
 * chain has a pointer to the next string and a reference count (char *, int)
 * stored just before the start of the string. HTABLE_SIZE is in gd_config.h,
 * and should be a prime, probably between 1000 and 5000.
 */

static Shared **base_table = 0;

void ssdum() { };

void
init_strings()
{
    int             x;
    base_table = (Shared **) 
            malloc(sizeof(Shared *) * HTABLE_SIZE);
/*    base_table = &(base_table[HTABLE_SIZE*5]); */   
    overhead_bytes += (sizeof(char *) * HTABLE_SIZE);

    for (x = 0; x < HTABLE_SIZE; x++) base_table[x] = NULL;
}

void
free_Stable()
{
    free(base_table);
}

/*
 * Hash a bit of memory
 */

unsigned int hashmem(const void * s, unsigned int length, int hashs)
{

    register unsigned int h = 0;
    register unsigned char *p;

    if (length > MAXH) length = MAXH;
    p = ((unsigned char *) s) - 1;

    while (length--)
    {
        h = h * 3 + (*++p);
    }

    return (h / 3) % hashs;  
}


/*
 * generic hash function.  This is probably overkill; I haven't checked the
 * stats for different prime numbers, etc.
 */

int StrHash(char * s, unsigned int tsize)
{
    int             h = 0;

    while (*s) 
    {
        h = (h * P1 + *(s++) * P2 + P3) % tsize;
    }

    return (h);
}

int LPC_StrHash(Shared * ss, unsigned int tsize)
{
    int  h = 0, countx = ss->length;
    char * s = ss->str;

    if (countx == 0) return 0;
    if (countx > MAXH) countx = MAXH;

    while (--countx)
        h = (h * P1 + *(s++) * P2 + P3) % tsize;

    return (h);
}

/*
 * Looks for a string in the table.  If it finds it, returns a pointer to the
 * start of the string part, and moves the entry for the string to the head
 * of the pointer chain.  One thing (blech!) - puts the previous pointer on
 * the hash chain into fs_prev.
 */

static Shared *
findstring(const void * s, unsigned int length)
{
    int h;
    int loop = 0;
    Shared * curr, * prev;

    h = hashmem(s, length, HTABLE_SIZE);

#if 0
    if (base_table[h])
        printf("find: hash=%d, string=%s, bt=%s\n", h, (char *) s,
            base_table[h]->str);
    else
        printf("find: hash=%d, string=%s, bt=%d\n", h, (char *) s,
            (int) base_table[h]);
#endif

    curr = base_table[h];
    prev = NULL;
    num_searches++;

    while (curr != NULL) 
    {
        search_len++;
        loop++;
        if ( (curr->length == length) && (memcmp(curr->str, s, length) == 0)) 
        {    
            return curr;    /* pointer to string */
        }
        prev = curr;
        curr = curr->next;
    }

    return NULL;            /* not found */
}

/*
 * Make a space for a string.  This is rather nasty, as we want to use
 * alloc/free, but malloc overhead is generally severe.  Later, we will have
 * to compact strings...
 */

static Shared *
alloc_new_string(const char * str, unsigned int length)
{
    int  h;
    Shared * s;

    h = hashmem(str, length, HTABLE_SIZE);
    s = (Shared *)
            malloc((length * sizeof(char)) + sizeof(struct _SHARED_STRING));

    memcpy(s->str, str, length);

    /* wasted a byte to C-terminate */
    s->str[length] = '\0';

    s->length = length;
    s->refs = 1;
    s->next = base_table[h];
#ifdef SHMAGIC
    s->magic[0] = SMAGIC1;
    s->magic[1] = SMAGIC2;
#endif
    base_table[h] = s;

#ifdef DEBUG_STRING
    printf("INSERTING: hash=%d, string=%s, bt=%d\n", h, str, 
            (int) base_table[h]);
#endif

    num_distinct_strings++;
    bytes_distinct_strings += sizeof(struct _SHARED_STRING) + length;
    overhead_bytes += sizeof(char *) + sizeof(REFTYPE);
    return (s);
}

Shared * string_ncopy(const void * str, unsigned int length)
{
    Shared * s;


    s = findstring(str, length);

    if (s == NULL) 
    {
        s = alloc_new_string(str, length);
    }
    else 
    {
#ifdef DEBUG_STRING
        printf("string_ncopy(%s:%d)\n", (char *)str, s->refs);
#endif
        if (s->refs < MAXREFS) s->refs++;
    }

    allocd_strings++;

    return s;
}

Shared * string_copy(const char * str)
{
    return string_ncopy(str, strlen(str));
}

Shared * shared_string_copy(Shared * s)
{
#ifdef DEBUG_STRING
    printf("shared_string_copy(%s:%d)\n", s->str, s->refs);
#endif

    if (s->refs == 0) fatal("FATAL: shared_string_copy of %s with 0 refs\n", s->str);

    if (s->refs < MAXREFS)
        s->refs++;

    allocd_strings++;

    return s;
}

/*
 * free_string - reduce the ref count on a string.  Various sanity checks
 * applied, the best of them being that a add_string allocated string will
 * point to a word boundary + sizeof(int)+sizeof(REFTYPE), since malloc always
 * allocates on a word boundary. On systems where a REFTYPE is 1/2 a word, this
 * gives an easy check to see whather we did in fact allocate it.
 * 
 * Don't worry about the overhead for all those checks!
 */

/*
 * function called on free_string detected errors; things return checked(s).
 */

static void
checked(char * s, Shared * str)
{
    fprintf(stderr, "%s (\"%s\")\n", s, str->str);
    fatal(s);            /* brutal - debugging */
}

void free_string(Shared * s)
{
    Shared * curr, * prev = NULL;
    int h;

    if (s == NULL) 
    {
        fprintf(stderr, "free_string: NULL shared string!");
        ssdum();
        abort();
        return;
    }
#ifdef DEBUG_STRING
printf("free_string(%s:%d)\n", s->str, s->refs);
#endif

    if (s->magic[0] != SMAGIC1 && s->magic[1] != SMAGIC2)
    {
        fprintf(stderr, "free_string: on non shared string.\n");
        ssdum();
        abort();
        return;
    }


    if (s->refs >= MAXREFS) return;
    if (s->refs <= 0) 
    {
        checked("free_string: string refs zero or -ve!", s);
        ssdum();
        abort();
        return;
    }

    allocd_strings--;
    s->refs--;

    if (s->refs > 0) return;

    h = hashmem(s->str, s->length, HTABLE_SIZE);
#ifdef DEBUG_STRING
printf("DELETING: hash=%d, (%s:%d).\n", h, s->str, s->refs);
#endif

    /* Remove it from the hash chain */
    curr = base_table[h];
    while (curr != NULL) 
    {
        if (curr == s) break;
        prev = curr;
        curr = curr->next;
    }
    if (prev == NULL)
    {
        base_table[h] = s->next;
    }
    else
    {
        prev->next = s->next;
    }

    num_distinct_strings--;

    /* We know how much overhead malloc has */
    bytes_distinct_strings -= sizeof(struct _SHARED_STRING) + s->length;
    overhead_bytes -= sizeof(REFTYPE) + sizeof(char *);

    /* Hmm - stuff it with zeros so we might find problems more quickly */
    s->length = 0;
    s->str[0] = 0;
    s->next = 0;

    clean_free(s);

    return;
}

/*
 * you think this looks bad!  and we didn't even tell them about the GNU
 * malloc overhead!  tee hee!
 */

static char stringbuf[2000];
static char stbuf[100];

char * 
add_string_status()
{
    /* EXT: add_message() */
    sprintf(stbuf, "%6.3f", (float) search_len / num_searches);
    sprintf(stringbuf, 
    "String space required: %5d (%10d bytes); asked for %5d (%d bytes)\n\
    Hash overhead: %d; Searches: %d;  average search length: %s\n", 
        num_distinct_strings, bytes_distinct_strings,
        allocd_strings, allocd_bytes, overhead_bytes, num_searches, stbuf);
#ifdef KEEP_STATS
    add_message("Space saved: %d%%\n", 100 -
        (bytes_distinct_strings + overhead_bytes) * 100 / allocd_bytes);
#endif
    return stringbuf;
}

int string_space_used()
{
    return (bytes_distinct_strings + overhead_bytes);
}


/*
 * Converts shared into an unshared C  string
 * Doesn't work so well if it's a binary thing with \0's in it.
 */
char *
unshared_str_copy(Shared * s)
{
    char * c = malloc(s->length + 1);

    memcpy(c, s->str, s->length);
    c[s->length] = '\0';

    return c;
}

char * str_copy(const char * s)
{
    int l;
    char * c;
    
    c = malloc((l = strlen(s)) + 1);

    memcpy(c, s, l);
    c[l] = '\0';

    return c;
}

/*
 * Our own "string" compare
 * Follows same rules as normal strcmp()
 */

int string_cmp(Shared * x, Shared * y)
{
    int l, m, r, g;

    l = x->length;
    m = y->length;
    if (l != m)
    {
        g = -1;
        if (l < m) 
        {
            m = l;
            g = 1;
        }
        r = memcmp(x->str,y->str,m);
        if (r == 0) return g;
        return r;
    }
    else return memcmp(x->str,y->str,m);
}

int stringcasecmp(const Shared * a, const char * b)
{
    return strcasecmp(a->str, b);
}

int string_ccmp(const Shared * a, const char * b)
{
    return strcmp(a->str, b);
}

/*
 * Our own "string" compare
 * Follows same rules as normal strcmp()
 */

int string_ncmp(Shared * x, Shared * y, int n)
{
    return memcmp(x->str,y->str,n);
}

/*
 * string_cat
 * Basic string addition function
 *
 * FIX: can be made more efficient (don't double malloc)
 */

Shared * string_cat(Shared * x, Shared * y)
{
    char * ns;
    Shared * ret;
    int len1, len2;

    if (x == NULL) 
    {
        if (y == NULL) return string_copy("");
        return shared_string_copy(y);
    }
    len1 = x->length;
    if (y != NULL) len2 = y->length;
    else len2 = 0;

    ns = (char *)malloc((1 + len1 + len2) * sizeof(char));
    memcpy(ns, x->str, len1);
    if (len2) memcpy(&(ns[len1]), y->str, len2);
    ret = string_ncopy(ns, len1 + len2);
    free(ns);
    return ret;
}

Shared * stringstr_cat(Shared * x, const char * y)
{
    char * ns;
    Shared * ret;
    int l;

    ns = (char *)malloc((1 + x->length + (l = strlen(y))) * sizeof(char));
    memcpy(ns, x->str, x->length);
    memcpy(&(ns[x->length]), y, l);
    ret = string_ncopy(ns, (x->length + l));
    free(ns);
    return ret;
}


/*
 * Debugging Fun
 *
 */

void dump_all_strings()
{
    FILE   * d;
    Shared * str;
    int x;

    d = fopen("STR_DUMP", "w");
    if (!d) return;
    
    for (x = 0; x < HTABLE_SIZE; x++) 
    {
        str = base_table[x];
        while (str)
        {
            fprintf(d, "%d: %d: %s\n", x, str->refs, str->str);
            str = str->next;
        }
    }

    fclose(d);
}
