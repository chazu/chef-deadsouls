
/*
** $Id: debug_malloc.c,v 1.1.1.1 2001/09/11 04:12:11 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/debug_malloc.c,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:11 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1993-2000
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include "magic.h"

void dddum() {}

void dfree(void * m, const char * file, int line)
{
    unsigned int * x = (int *) m;

    if (!m) return;

#if 0
    if (x[0] == SMAGIC1 && x[1] == SMAGIC2)
    {
        dddum();
        output_error("Free()ing string value should be free_string'ed first!\n", file, line);
    }
    else if (x[0] == OMAGIC1 && x[1] == OMAGIC2)
    {
        dddum();
        output_error("Free()ing object value should be free_object'ed first!\n", file, line);
    }
#endif
    free(m);
}

void clean_free(void * m)
{
    free(m);
}

