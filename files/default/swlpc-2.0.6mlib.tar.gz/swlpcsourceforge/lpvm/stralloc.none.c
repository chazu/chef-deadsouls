

/*
** $Id: stralloc.none.c,v 1.1.1.1 2001/09/11 04:12:17 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/stralloc.none.c,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:17 $
** $State: Exp $
**
** Author: Mike McGaughey
** Copyright(C) 1993-1998
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.        
*/

#include <string.h>
#include "proto.h"

/*
 * stralloc.c - string management.
 * 
 * All strings are stored in an extensible hash table, with reference counts.
 * free_string decreases the reference count; if it gets to zero, the string
 * will be deallocated.  add_string increases the ref count if it finds a
 * matching string, or allocates it if it cant.  There is no way to allocate
 * a string of a particular size to fill later (hash wont work!), so you'll
 * have to copy things freom a static (or malloced and later freed) buffer -
 * that is, if you want to avoid space leaks...
 * 
 * Current overhead: 8 bytes per string (next pointer, and 2 shorts for length
 * and refs) Strings are nearly all fairly short, so this is a significant
 * overhead- there is also the 4 byte malloc overhead and the fact that
 * malloc generally allocates blocks which are a power of 2 (should write my
 * own best-fit malloc specialised to strings); then again, GNU malloc is bug
 * free...
 */

/*
 * there is also generic hash table management code, but strings can be
 * shared (that was the point of this code), will be unique in the table,
 * require a reference count, and are malloced, copied and freed at will by
 * the string manager.  Besides, I wrote this code first :-). Look at
 * htable.c for the other code.  It uses the Hash() function defined here,
 * and requires hashed objects to have a pointer to the next element in the
 * chain (which you specify when you call the functions).
 */

#define    MAXREFS        ((1 << ((sizeof(REFTYPE) )*8 - 1)) - 16) /* 15 is slop */
#define    WORD_ALIGN_BIT    0x3    /* these are 0 for aligned ptrs */
/* #define BUG_FREE */

extern int  hashstr(char *s, int maxn, int hashs);

int             num_distinct_strings = 0;
int             bytes_distinct_strings = 0;
int             overhead_bytes = 0;
static int      allocd_strings = 0;
static int      allocd_bytes = 0;
static int      search_len = 0;
static int      num_searches = 0;

/*
 * strings are stored: (char * next) (short numrefs) string ^ pointer points
 * here
 */

#define    REFTYPE        short
#define    NEXT(str)    (*((char **)((char *) (str) - sizeof(REFTYPE)    \
                           - sizeof(char *))))
#define    REFS(str)    (*((REFTYPE *)(((char *) (str)) - sizeof(REFTYPE))))

/*
 * hash table - list of pointers to heads of string chains. Each string in
 * chain has a pointer to the next string and a reference count (char *, int)
 * stored just before the start of the string. HTABLE_SIZE is in gd_config.h,
  and should be a prime, probably between 1000 and 5000.
 */

static char   **base_table = 0;

void
init_strings()
{
    int             x;
    base_table = (char **) xalloc(sizeof(char *) * HTABLE_SIZE);
    overhead_bytes += (sizeof(char *) * HTABLE_SIZE);

    for (x = 0; x < HTABLE_SIZE; x++)
    base_table[x] = 0;
}

void
free_Stable()
{
    free(base_table);
}
/*
 * generic hash function.  This is probably overkill; I haven't checked the
 * stats for different prime numbers, etc.
 */


int StrHash(char * s, int tsize)
{
    int             h = 0, countx = 80;


    while (*s) /* && --countx) */
    h = (h * P1 + *(s++) * P2 + P3) % tsize;

    return (h);
}

int LPC_StrHash(char *s, int tsize)
{
    int             h = 0, countx = 80;


    while (*s && --countx)
    h = (h * P1 + *(s++) * P2 + P3) % tsize;

    return (h);
}

/*
/*
 * Looks for a string in the table.  If it finds it, returns a pointer to the
 * start of the string part, and moves the entry for the string to the head
 * of the pointer chain.  One thing (blech!) - puts the previous pointer on
 * the hash chain into fs_prev.
 */

static char    *
findstring(char *s)
{
    char           *curr, *prev;

    int             h = hashstr(s, MAXH, HTABLE_SIZE);

/*    if (!base_table) init_strings(); */
    curr = base_table[h];
    prev = 0;
    num_searches++;

    while (curr != NULL) {
    search_len++;
    if (*curr == *s && !strcmp(curr, s)) {    /* found it */
        if (prev) {        /* not at head of list */
        NEXT(prev) = NEXT(curr);
        NEXT(curr) = base_table[h];
        base_table[h] = curr;
        }
        return (curr);    /* pointer to string */
    }
    prev = curr;
    curr = NEXT(curr);
    }

    return (0);            /* not found */
}

/*
 * Make a space for a string.  This is rather nasty, as we want to use
 * alloc/free, but malloc overhead is generally severe.  Later, we will have
 * to compact strings...
 */

static char    *
alloc_new_string(char *string)
{
    char           *s = xalloc(1 + strlen(string) + sizeof(char **) + sizeof(REFTYPE));
    int             h = hashstr(string, MAXH, HTABLE_SIZE);

/*    if (!base_table) init_strings(); */
    s += sizeof(char *) + sizeof(REFTYPE);
    strcpy(s, string);
#if 0
    REFS(s) = 0;
#endif
    NEXT(s) = base_table[h];
    base_table[h] = s;
    num_distinct_strings++;
    bytes_distinct_strings += 4 + (strlen(s) + 3) & ~3;
    overhead_bytes += sizeof(char *) + sizeof(REFTYPE);
    return (s);
}

char           *
string_copy(char *str)
{
    char           *s;

    s = findstring(str);
    if (s == NULL) {
    s = alloc_new_string(str);
    REFS(s)  = 1;
    }
    else {
        if (REFS(s) < MAXREFS)
        REFS(s)++;
    }
#if 0
/* this was a useful test feature :) */
    switch (REFS(s)) {
    case 50: fprintf(stderr, "+%5d refs: %s\n", 50, s); break;
    case 100: fprintf(stderr, "+%5d refs: %s\n", 100, s); break;
    case 250: fprintf(stderr, "+%5d refs: %s\n", 250, s); break;
    case 500: fprintf(stderr, "+%5d refs: %s\n", 500, s); break;
    case 1000: fprintf(stderr, "+%5d refs: %s\n", 1000, s); break;
    case 2000: fprintf(stderr, "+%5d refs: %s\n", 2000, s); break;
    case 2500: fprintf(stderr, "+%5d refs: %s\n", 2500, s); break;
    case 3000: fprintf(stderr, "+%5d refs: %s\n", 3000, s); break;
    case 3500: fprintf(stderr, "+%5d refs: %s\n", 3500, s); break;
    case 4000: fprintf(stderr, "+%5d refs: %s\n", 4000, s); break;
    case 4500: fprintf(stderr, "+%5d refs: %s\n", 4500, s); break;
    case 5000: fprintf(stderr, "+%5d refs: %s\n", 5000, s); break;
    case 10000: fprintf(stderr, "+%5d refs: %s\n", 10000, s); break;
    }
#endif
    allocd_strings++;
#ifdef KEEP_STATS
    allocd_bytes += 4 + (strlen(str) + 3) & ~3;
#endif
    return (s);
}

char *
string_inc_ref(char * s)
{
#if 0
    if (!s) {
        fprintf(stderr,"string_inc_ref fucked up.\n");
        return 0;
    }
#endif
        if (REFS(s) < MAXREFS)
        REFS(s)++;
        allocd_strings++;
#ifdef KEEP_STATS
    allocd_bytes += 4 + (strlen(str) + 3) & ~3;
#endif
    return s;
}


/*
 * free_string - reduce the ref count on a string.  Various sanity checks
 * applied, the best of them being that a add_string allocated string will
 * point to a word boundary + sizeof(int)+sizeof(REFTYPE), since malloc always
 * allocates on a word boundary. On systems where a REFTYPE is 1/2 a word, this
 * gives an easy check to see whather we did in fact allocate it.
 * 
 * Don't worry about the overhead for all those checks!
 */

/*
 * function called on free_string detected errors; things return checked(s).
 */

static void
checked(char * s, char *str)
{
    fprintf(stderr, "%s (\"%s\")\n", s, str);
    fatal(s);            /* brutal - debugging */
}

void free_string(char *str)
{
    char           *s;

    allocd_strings--;
#ifdef KEEP_STATS
    allocd_bytes -= 4 + (strlen(str) + 3) & ~3;
#endif

#ifdef    BUG_FREE
    if (REFS(str) >= MAXREFS)
    return;
    REFS(str)--;
    if (REFS(str) > 0)
    return;
#endif                /* BUG_FREE */

    {
    int             align;
    align = (((int) str) - sizeof(int) - sizeof(REFTYPE)) & WORD_ALIGN_BIT;
    if (align)
        checked("Free string: improperly aligned string!", str);
    }

    s = findstring(str);    /* moves it to head of table if found */
    if (!s) {
    checked("Free string: not found in string table!", str);
    return;
    }
    if (s != str) {
    checked("Free string: string didnt hash to the same spot!", str);
    return;
    }
    if (REFS(s) >= MAXREFS)
    return;
    if (REFS(s) <= 0) {
    checked("Free String: String refs zero or -ve!", str);
    return;
    }
    REFS(s)--;
#if 0
fprintf(stderr, "-%5d refs: %s\n",  REFS(s), str);
    switch (REFS(s)) {
    case 50: fprintf(stderr, "-%5d refs: %s\n", 50, s); break;
    case 100: fprintf(stderr, "-%5d refs: %s\n", 100, s); break;
    case 250: fprintf(stderr, "-%5d refs: %s\n", 250, s); break;
    case 500: fprintf(stderr, "-%5d refs: %s\n", 500, s); break;
    case 1000: fprintf(stderr, "-%5d refs: %s\n", 1000, s); break;
    case 2000: fprintf(stderr, "-%5d refs: %s\n", 2000, s); break;
    case 2500: fprintf(stderr, "-%5d refs: %s\n", 2500, s); break;
    case 3000: fprintf(stderr, "-%5d refs: %s\n", 3000, s); break;
    case 3500: fprintf(stderr, "-%5d refs: %s\n", 3500, s); break;
    case 4000: fprintf(stderr, "-%5d refs: %s\n", 4000, s); break;
    case 4500: fprintf(stderr, "-%5d refs: %s\n", 4500, s); break;
    case 5000: fprintf(stderr, "-%5d refs: %s\n", 5000, s); break;
    case 10000: fprintf(stderr, "-%5d refs: %s\n", 10000, s); break;
    }
#endif
    if (REFS(s) > 0)
    return;
    /* It will be at the head of the hash chain */
/*    if (!base_table) init_strings(); */
    base_table[hashstr(str, MAXH, HTABLE_SIZE)] = NEXT(s);
    num_distinct_strings--;
    /* We know how much overhead malloc has */
    bytes_distinct_strings -= 4 + (strlen(s) + 3) & ~3;
    overhead_bytes -= sizeof(REFTYPE) + sizeof(char *);
    free(s - sizeof(REFTYPE) - sizeof(char *));

    return;
}

/*
 * you think this looks bad!  and we didn't even tell them about the GNU
 * malloc overhead!  tee hee!
 */

static char     stbuf[100];

int 
add_string_status()
{
    add_message("String space required: %5d (%10d bytes); ",
        num_distinct_strings, bytes_distinct_strings);
    add_message("asked for %5d (%d bytes)\n",
        allocd_strings, allocd_bytes);
    add_message("Hash overhead: %d; ", overhead_bytes);
#ifdef KEEP_STATS
    add_message("Space saved: %d%%\n", 100 -
        (bytes_distinct_strings + overhead_bytes) * 100 / allocd_bytes);
#endif
    add_message("Searches: %d;  ", num_searches);
    sprintf(stbuf, "%6.3f", (float) search_len / num_searches);
    add_message("average search length: %s\n", stbuf);
    return (bytes_distinct_strings + overhead_bytes);
}

/*
 * replaces old string_copy
 */

char           *
unshared_str_copy(char *s)
{
    char           *c = xalloc(strlen(s) + 1);
    return (strcpy(c, s));
}
