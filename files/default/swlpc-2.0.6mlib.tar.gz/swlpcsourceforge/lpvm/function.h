#ifndef _LNODE_H
#define _LNODE_H

#include "stralloc.h"

//
//  Function header defintion.
//
struct function_def 
{
    unsigned char   num_var;    // Number of local variables + arguments 
    unsigned char   num_arg;    // Number of arguments. 
    unsigned short  type;

    Shared          * name;
    unsigned char   * block;    // linearised code block 
    struct function_def * next;
    unsigned short  * linemap;  // a mapper from instructions to line #
    Shared          ** patch;   // used for list of strings while running
                                //  & for patch list while building
                                
    unsigned short  line;       // line we start at
    unsigned short  num_lines;  // number of lines 
    unsigned short  size;       // size of code block 
    unsigned short  current_I;
    unsigned short  num_str;
};

typedef struct function_def Func;

#endif

