

/*
** $Id: fatal.c,v 1.1.1.1 2001/09/11 04:12:12 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/fatal.c,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:12 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include "fatal.h"
#include "error.h"


/*
** Should be fixed to abort the stack machine execution
** and return an error to the calling program.
*/

void fatal(const char *fmt,...)
{
    static int in_fatal = 0;

    /* Prevent double fatal. */
    va_list args;

    if (in_fatal)
    {
        va_start(args, fmt);
        (void) fprintf(errstream, "FATAL: recursed\n");
        fclose(errstream);
        abort();
    }
    in_fatal = 1;
    
    outputbt();
    va_start(args, fmt);
    (void) vfprintf(errstream, fmt, args);
    va_end(args);

#if 0
    if (errstream && current_object)
    {
        fprintf(errstream, fmt, args);
        fprintf(errstream, "Current object was %s\n", current_object->name);
        fprintf(errstream, "Dump of variables:\n");
        if (current_object)
        {
            int  p;

            for (p = 0; p < current_object->num_variables; p++)
            {
                Val *v;

#if 1
                fprintf(errstream, "%20s: ",
                        currentO->global_table[p]->u.string);
                v = (&currentO->variables[p]);
#endif
                if (v == 0)
                {
                    fprintf(errstream, "<NULL>");
                    continue;
                }
                switch (v->type)
                {
                    case T_NUMBER:
                        fprintf(errstream, "%d", v->u.number);
                        break;
                    case T_REAL:
                        fprintf(errstream, "%f", v->u.real);
                        break;
                    case T_STRING:
                        fprintf(errstream, "\"%s\"", v->u.string);
                        break;
                    case T_POINTER:
                        fprintf(errstream, "Array(you want me to print it?");
                        break;
                    case T_OBJECT:
                        fprintf(errstream, "OBJ(%s)", v->u.ob->name);
                        break;
                    default:
                        fprintf(errstream, "<INVALID TYPE>\n");
                        return;
                }
                fprintf(errstream, "\n");
            }
        }
    }
#endif

#if 0
    ipc_remove();  /* Shut down the ipc communication. */
#endif

    fclose(errstream);
    abort();
    /*forced_ */ exit(0);
}

