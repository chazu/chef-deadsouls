
/*
** $Id: stack.h,v 1.3 2003/01/30 04:11:02 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/stack.h,v $
** $Revision: 1.3 $
** $Date: 2003/01/30 04:11:02 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _STACK_H
#define _STACK_H

#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <setjmp.h>
#include <signal.h>

#include "stralloc.h"
#include "smcodes.h"
#include "value.h"
#include "function.h"
#include "object.h"
#include "xalloc.h"
#include "fatal.h"
#include "error.h"


/* Stack conditions */
typedef enum
{
    SE_normal = 0,
    SE_timeout = 1,
    SE_overflow = 2,
    SE_fatal = 3,
    SE_handled = 4,
    SE_unhandled = 5
} Stack_code;


/* An execution block */
typedef struct EXEC_BLOCK
{
    Func * prog;
    int var_offset;
} Exec_block;

struct value * alloc_stack_value();

void Push(struct value *);
    /* Pushes a value onto the argument stack                */

void Pop(struct value *);
    /* Pop the top of the stack into the arg passed to Pop   */

int Pushc(int);
    /* Push an int onto the top of the control stack         */
    /* returns 0 for now                                     */

int  Popc();
    /* Pop the top of the control stack and return the value */

void SsetPC(byte *);
    /* Set the program counter at the start of an instruction */
    /* block. MUST be set before calling Sexecute()           */

byte * SgetPC();
    /* Get the current program counter after execution halts  */
    
/* General setup functions for the stack machine */

void Sinit_stack();
    /* Initialise the stack machine                          */
    /* MUST be set                                           */

void Sset_current(Obj *, const char *);
    /* Set the default operating object for the stack machine */
    /* MUST be set before calling Sexecute()                  */

Obj * Scurrent();
    /* Return the current object being operated upon by the   */
    /* virtual machine.                                       */

Obj * Scaller();
    /* Return the object which called the current object      */

void Sset_external_handler( void (*exh)(int) );
    /* Set the handler function for functions external to the */
    /* stack machine                                          */

void Sset_program_handler( Exec_block(*progh)(Obj *, Shared *) );
    /* Set the handler function to find program blocks given  */
    /* an object and function                                 */

void Serror_stream(FILE *);
    /* Set the error stream the VM outputs its errors to      */
    /* If not set errors go to stderr                         */

/* Actually run the stack machine */

Stack_code Sexecute();
    /* Actually run the stack machine                         */
    /* Returns an integer representing an error code (if +ve) */

#endif

