

/*
** $Id: stralloc.h,v 1.4 2003/06/03 13:43:26 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/stralloc.h,v $
** $Revision: 1.4 $
** $Date: 2003/06/03 13:43:26 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/


#ifndef _STRALLOC_H
#define _STRALLOC_H
#include <stdio.h>
#include <string.h> 
#include <stdarg.h>
#include "xalloc.h"
#include "prime.h"

#define REFTYPE unsigned short
#define MAXREFS ((1 << (sizeof(REFTYPE) << 3)) - 1)
#define SHMAGIC 

#ifdef SHMAGIC
#include "debug_malloc.h"
#endif

typedef struct _SHARED_STRING
{
#ifdef SHMAGIC
    void * magic[2];
#endif
    struct _SHARED_STRING * next;
    unsigned int length;
    REFTYPE refs;
    char str[1];
} Shared;

int 
    LPC_StrHash(Shared * s, unsigned int tsize),
    StrHash(char * s, unsigned int tsize),
    string_cmp(Shared * x, Shared * y),
    string_ncmp(Shared * x, Shared * y, int),
    stringcasecmp(const Shared * a, const char * b),
    string_ccmp(const Shared * a, const char * b),
    string_space_used()
    ;

void 
    free_Stable(),
    free_string(Shared * str),
    dump_all_strings(),
    init_strings()
    ;

Shared 
    * string_copy(const char * str),
    * string_ncopy(const void * str, unsigned int length),
    * shared_string_copy(Shared * s),
    * string_cat(Shared * a, Shared * b),
    * stringstr_cat(Shared * a, const char * b)
    ;

char 
    * unshared_str_copy(Shared * s),
    * add_string_status(),
    * str_copy(const char * s)
    ;

#define MAXH 64
#define HTABLE_SIZE 310019  /* 81919  there is a table of some primes too */

/* And a hacky definition */
void add_message (const char *, ...);


#endif
