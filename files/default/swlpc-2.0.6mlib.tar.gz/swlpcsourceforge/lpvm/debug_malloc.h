/*
 * Actually a debug free
 * Checks magic number to make sure we're not freeing the wrong thing..
 */

#ifndef DEBUG_MALLOC
#define DEBUG_MALLOC

#ifdef SHMAGIC
#define free(X) dfree(X, __FILE__, __LINE__)

void dfree(void * m, const char *, int);
void clean_free(void * m);

#endif

#endif
