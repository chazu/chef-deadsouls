

/*
** $Id: xalloc.c,v 1.1.1.1 2001/09/11 04:12:18 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/xalloc.c,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:18 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include "xalloc.h"
#include "fatal.h"
#include "error.h"


#ifdef DEBUG_XALLOC
#define XSIZE 12
int  xalloced = 0;
int  xsizes[XSIZE];

static void initxsizes()
{
    int  i;

    for (i = 0; i < XSIZE; i++)
        xsizes[i] = 0;
}

#endif

char *debug_stop_addr = NULL;

#ifndef FIND_LEAKS
#ifndef MALLOC_GCmalloc

#ifdef malloc
#undef malloc
#endif

char * xalloc(int size)
{
    char *p;
    static int out_of_mem = 0;  /* Prevent double call to *
                                 * remove_all_players() */

    if (out_of_mem) exit(3);

    if (size == 0) fatal("Tried to allocate 0 bytes.\n");

    p = (char *) malloc(size);
    if (p == 0)
    {
#ifdef RESERVED_AREA
        if (reserved_area)
        {
            free(reserved_area);
            p = "Temporary out of MEMORY. Freeing reserve.\n";
            write(1, p, strlen(p));
            reserved_area = 0;
            slow_shut_down(5);
            return xalloc(size);  /* Try again */
        }
#endif
        fprintf(errstream, "Totally out of memory chunk: %d.\n", size);
        if (out_of_mem)  /* forced_ */
            exit(2);
        fprintf(errstream, "Trying to save players... ");
        out_of_mem = 1;
#if 0
        remove_all_players();   /* FIX: external - mud should do xalloc.. */
        fprintf(errstream, "players saved; exiting.\n");
#endif
        /* forced_ */ exit(1);
    }
#ifdef DEBUG_XALLOC
    if (p == debug_stop_addr)
        debug_value(p);
    xalloced += size;
    if (size <= 8)
        xsizes[0]++;
    else if (size <= 16)
        xsizes[1]++;
    else if (size <= 32)
        xsizes[2]++;
    else if (size <= 64)
        xsizes[3]++;
    else if (size <= 128)
        xsizes[4]++;
    else if (size <= 256)
        xsizes[5]++;
    else if (size <= 512)
        xsizes[6]++;
    else if (size <= 1024)
        xsizes[7]++;
    else if (size <= 2048)
        xsizes[8]++;
    else if (size <= 4096)
        xsizes[9]++;
    else if (size <= 8192)
        xsizes[10]++;
    else
        xsizes[11]++;
#endif
    return (char *) p;
}

#endif 
#endif /* GCmalloc */

