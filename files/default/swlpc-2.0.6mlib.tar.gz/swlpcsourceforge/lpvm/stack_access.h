

/*
** $Id: stack_access.h,v 1.3 2002/01/24 00:29:29 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/stack_access.h,v $
** $Revision: 1.3 $
** $Date: 2002/01/24 00:29:29 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _STACK_ACCESS_H
#define _STACK_ACCESS_H

#include "value.h"

/* Instruction grabbing macros */

#define INST (char)(*sPC); INC_sPC

#ifdef ENDIAN
#define INST16 (sh[0]=sPC[0],sh[1]=sPC[1],*((short *)sh)); INC16_sPC
#define INST32 (lg[0]=sPC[0],lg[1]=sPC[1],lg[2]=sPC[2],lg[3]=sPC[3], \
    *((unsigned long *)lg)); INC32_sPC
#else
#define INST16 (sh[0]=sPC[1],sh[1]=sPC[0],*((short *)sh)); INC16_sPC
#define INST32 (lg[0]=sPC[3],lg[1]=sPC[2],lg[2]=sPC[1],lg[3]=sPC[0], \
    *((unsigned long *)lg)); INC32_sPC
#endif

#if 1
#define    DUMP_STATUS(_fun, _obj)
#else
#define    DUMP_STATUS(_fun, _obj)         dump_status(_fun, _obj); 
#endif

/* stack stuff */
#define PWIDTH    4  /* sizeof (Val *) */

#define MAX_STACK 65536
#define STACK_OFLOW 63000  /* must be less than MAX_STACK!! */

#define MAX_CONTROL_DEPTH 20000
#define CSTACK_OFLOW 19700 /* must be less than MAX_CONTROL_DEPTH */

#define MAXIMUM_STACK_VALUES 200000

#define STACK_CHECK if ((rSP-(int)stack) >= STACK_OFLOW * PWIDTH) {     \
            /* overflow_flag = 1;  */ \
            stack_error("Stack overflow.\n");\
            return;             \
        }

#define CSTACK_CHECK if ((rCT-(int)control) >= CSTACK_OFLOW * PWIDTH) {    \
            /* overflow_flag = 1;  */ \
            stack_error("Control Stack overflow.\n");\
            return;             \
        }

/* some yucky macros to make life easier */

/* Program counter macros */
#define INC_sPC sPC = (byte *)((int)sPC + 1)
#define INC16_sPC sPC = (byte *)((int)sPC + 2)
#define INC32_sPC sPC = (byte *)((int)sPC + 4)

#define INC(x) sPC = (byte *)((int)sPC + x)

/* some defines for accessing the stack */
#define STpush(_X)     *((Val **)(rSP))=_X; rSP+=PWIDTH; STACK_CHECK;
#define STpop         (*((Val **)(rSP-=PWIDTH)))
#define STtop         (*((Val **)(rSP-PWIDTH)))
#define STP(_X)       (*((Val **)(rSP+(_X) * PWIDTH)))
#define STA(_X)       (rSP = rSP + (_X) * PWIDTH)

#define STacc(_X,_Y)  (*((Val **)((_X)+(_Y)*PWIDTH)))
#define STbase(_X)    (*((Val **)(rBP+(_X)*PWIDTH)))

/* some stuff for the control stack */
extern int  control[];
extern int  rCT;       /* control stack pointer */
extern int  CATCHBP;   /* catch base pointer! */
extern int  CBP;       /* control frame pointer */

/* some defines for accessing the control stack */
#define CTpush(_X)    *((int *)(rCT))=_X; rCT+=PWIDTH; CSTACK_CHECK;
#define CTpop         (*((int *)(rCT-=PWIDTH)))
#define CTP(_X)       (*((int *)(rCT+(_X)*PWIDTH)))
#define CTA(_X)       (rCT = rCT + (_X) * PWIDTH)

#define CTacc(_X, _Y) (*((int *)((_X) + (_Y)*PWIDTH)))

/* some control stack defns in case the size changes :( */
#define CONTROL_NUM 8
#define CBP_ARGS      (CTacc(CBP,-CONTROL_NUM+0))
#define CBP_RA        (CTacc(CBP,-CONTROL_NUM+1))
#define CBP_OFFSET    (CTacc(CBP,-CONTROL_NUM+2))
#define CBP_OBJ       (CTacc(CBP,-CONTROL_NUM+3))
#define CBP_FUNC      (CTacc(CBP,-CONTROL_NUM+4))
#define CBP_FV        (CTacc(CBP,-CONTROL_NUM+5))
#define CBP_BP        (CTacc(CBP,-CONTROL_NUM+6))
#define CBP_CBP       (CTacc(CBP,-CONTROL_NUM+7))

#define CATCH_CATCH   (CTacc(CATCHBP,-6))

/* some debugging vars */
#define NON_VAR -256

/* Stack stuff */
extern Val * stack[]; 

extern int  rSP;     /* points to the next empty element in the stack */
extern int  rBP;     /* base(frame) pointer */

extern int  last_global;
extern int  last_local;

extern unsigned char sh[], lg[];

/* Random state stuff mostly */
extern int  
    total_offset, 
    FV,
    error_flag, 
    overflow_flag,
    terminate
    ;

extern Obj * currentO;

extern byte * sPC; /* program counter! */

extern char * last_fun;


#endif
