
/*
** $Id: stack.c,v 1.9 2003/06/02 05:50:46 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/stack.c,v $
** $Revision: 1.9 $
** $Date: 2003/06/02 05:50:46 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au (now mmcg@microsoft.com)
**
** See the file "Copying" distributed with this file.
*/

/*
 * Opcodes we need for a small, fast stack machine.
 * 
 * The Stack Machine        - Geoff Wong June 1994.
 * =================
 * 
 * Since I didn't write many comments in the actual stack machine code
 * I will attempt to give an overview here.
 * 
 * The stack machine consists of two stacks. Both stacks are
 * implemented in fixed size arrays.
 * 
 * One is the "value" stack which is a stack in which pointers to
 * values go. The other is the "control" stack in which frame pointer 
 * and error recovery information is stored.
 * 
 * The stack machine accepts two opcodes to support this: push and pushc.
 * The equivalents from within the driver are Push() and Pushc().
 * 
 * A typical function call might go something like this (stacks growing down):
 * 
 * Value stack.        Control stack.
 * -------------       --------------
 * invoking object     number of args
 * parameters          return addr
 *                     global var offset (multiple inheritance).
 * 
 * This information is accessed using the base (or frame) pointer (BP)
 * and (CBP) respectively.
 * 
 * A "catch" statement (from LPC or within the driver) will 
 * store the "recover" information on the control stack in the
 * following format:
 * 
 * Control Stack.
 * --------------
 * function pointer -
 * stack pointer (CT)    -
 * offset value - optional line to jump to 
 * garbage collection value (FV)
 * base pointer (BP)    -    frame info
 * control stack base pointer (CBP)
 * CATCHBP              -    old catch frame information
 * 
 * A new CATCHBP is set to this current frame.
 * 
 * If a stack_error (or efun_error occurs) this information is
 * then used to "recover" control without terminating.
 * A Catch() must be followed by a Popcatch() somewhere.
 * 
 * A series of macros are defined to manipulate the stacks :-
 * 
 * STpush(arg)  -    push a (Val *) on the stack.
 * STpop        -    return the top of stack and decrement it.
 * STtop        -    return the top of stack.
 * STP(arg)     -    access (top of stack + arg * pointer width)
 * STA(int x)   -    add x to the stack pointer.
 * 
 * STacc(X, Y)  -    access location (X + Y * pointer width)
 * 
 * CTpush, CTpop, CTP(int arg), CTA(int x), CTacc(X, Y)
 * are similarly defined operations on the control stack.
 * 
 * Freeing Values.
 * ----------------
 * 
 * As part of the frame information we remember a pointer
 * into the value space (really another stack).
 * When we clean up after finishing (or error) we retract the
 * value stack back to this location.
 * 
 * - It would be nice to have a "flat" value space so we didn't need
 * to free all those pointers while retracting.
 * 
 */

#include <assert.h>
#include "stack.h"
#include "stack_access.h"
#include "stack_alloc.h"

/* #define TESTING */
/* #define CBPSTUFF  */
/* #define DEBUG */
/* #define CATCHDEBUG   */
// #define SDEBUG 

#ifdef __WIN32__
#define sigjmp_buf jmp_buf
#define siglongjmp(X,Y) longjmp(X,Y)
#define sigsetjmp(X,Y) setjmp(X)
#endif

#define itype_check(zv,zt,zz,zn) { if (!(zv) || !((zv)->type & (zt))) \
{ stack_error("Arithmetic type error in %s (arg %d)\n", zz, (char*)zn); \
     return; } }

#define igetreal(v) ((v->type == T_REAL) ? v->u.real : v->u.number)

/* Functions local to stack.c */

void 
    copy_in_value(Val *, Val *), 
    close_frame(int), 
    clear_stack(),
    outputbt(),
    wipe(int a)
    ;

Val 
    * make_space(int n);

int 
    new_frame();

static int Callother(Shared *);

struct vector 
    * alloc_deep_array(int);

/* Memory used for instruction decoding */
unsigned char sh[4], lg[4];

/* Variables of stack.c */
char *last_fun;
    /* some "state" memory */

byte * sPC = NULL;
    /* program counter! */

Obj * currentO = NULL;
    /* current working object */

Stack_code error_code = SE_normal;
    /* execution return code */

void (*efun_handler)(int);
Exec_block (*prog_handler)(Obj *, Shared *);

/* Main Stack stuff */
Val * stack[MAX_STACK];
int  rSP = (int) stack;     /* points to the next empty element in the stack */
int  rBP = (int) stack;     /* base(frame) pointer */

/* Control Stack stuff */
int  control[MAX_CONTROL_DEPTH];
int  rCT = (int) control;       /* control stack pointer */
int  CATCHBP = (int) control;   /* catch base pointer! */
int  CBP = (int) control;       /* control frame pointer */

/* Random state stuff mostly */
int  
    total_offset = 0, 
    FV = 0,
/*    error_flag = 0,  */
    overflow_flag = 0,
    terminate = 0
    ;

/* some debugging vars */
int  last_global = -256;
int  last_local = -256;

struct smtable
{
    void (*func) ();
    int  numcalls;
};
static struct smtable jmptable[MAX_SMCODES];

static struct func_table
{
    int  opcode;
    void (*fun) ();
}
op_init[] =
{
    { S_END, my_end } ,
    { S_ADDIND, addind } ,
    { S_ADDSP, addsp } ,
    { S_AGGREGATE, aggregate } ,
    { S_AND, and } ,
    { S_CALL, calln } ,
    { S_CALLO, callo } ,
    { S_CATCH, catch } ,
    { S_COPY, copy } ,
    { S_DIVIDE, divide } ,
    { S_EFUN, efun } ,
    { S_EFUND, efun_direct } ,
    { S_ENTER, enter } ,
    { S_EQ, eq } ,
    { S_GE, ge } ,
    { S_GT, gt } ,
    { S_JNZERO, jnzero } ,
    { S_JUMP, jump } ,
    { S_JUMPU, undefined } ,
    { S_JZERO, jzero } ,
    { S_LAND, land } ,
    { S_LE, le } ,
    { S_LNOT, lnot } ,
    { S_LOR, lor } ,
    { S_LSH, lsh } ,
    { S_LT, lt } ,
    { S_MINUS, minus } ,
    { S_MOD, mod } ,
    { S_MULT, mult } ,
    { S_NE, ne } ,
    { S_NEGATE, negate } ,
    { S_NOT, not } ,
    { S_OR, or } ,
    { S_PUSH8, push8 } ,
    { S_POPCATCH, popcatch } ,
    { S_POPL, popl } ,
    { S_PUSH, push } ,
    { S_RETURN, _return } ,
    { S_RSH, rsh } ,
    { S_THROW, throw } ,
    { S_XOR, xor } ,
    { S_PUSHL, pushl } ,
    { S_PLUS, plus } ,
    { S_PUSHC, pushc } ,
    { S_PUSHG, pushg } ,
    { S_POPG, popg } ,
#if 0
    { S_EXTRACT, smextract } ,
#endif
    { S_POPI, popi } ,
    { S_PUSHi, pushi } ,
    { S_CALLOF, Callo } ,
    { S_POPO, popo } ,
    { S_PUSHr, pushr } ,
    { S_PUSHs, pushs } ,
    { S_ARR_ALLOC, stack_array } ,
    { S_OFLOW_CHECK, oflow_check } ,
    { S_PUSHCi, pushci } ,
    { S_SWITCH, my_switch } ,
    { 0, 0 }
};

void install_optable()
{
    int  i = 0;

    for (i = 0; i < MAX_SMCODES; i++)
    {
        jmptable[i].func = undefined;
    }
    i = 0;
    while ((op_init[i].opcode != 0 || op_init[i].fun != NULL)
           && i < MAX_SMCODES)
    {
/*        printf("Installing %s\n", codes[op_init[i].opcode]); */
        jmptable[op_init[i].opcode].func = op_init[i].fun;
        i++;
    }
    return;
}


/* debugging function */
void print20(byte * f)
{
    int  i = 0, x;
    if (!f)
        return;

    for (i = -20; i < 5; i++)
    {
        x = (int) (f[i]);
        printf("%d ", x);
    }
    printf("\n");
}


/*
 * Infinite loop timer set/reset
 *
 * Used to return control to the game from spastic coding
 * Cheaper than "eval_cost" incrementing all the time
 */

static sigjmp_buf   timeout_buf;

void timer_interrupt(int x)
{
#if 0
    debug_message("ALERT: TIMER INTERRUPT (co = %s).\n", currentO->name);
#endif
    siglongjmp(timeout_buf, 1);
}

void reset_timer()
{
#ifdef SIGALRM
    alarm(0);
#endif
}

int set_timer(int time)
{
    if (!sigsetjmp(timeout_buf, 1))
    {
#ifdef SIGALRM
        (void) signal(SIGALRM, timer_interrupt);
        alarm(time);
#endif
        return 1;
    }
    reset_timer();
    clear_stack();
    sPC = 0;
    terminate = 1;
    error_code = SE_timeout;
    return 0;
}

/*
 * We used setjmp()/longjmp() in this loop to avoid
 * an if condition each time around the loop
 *
 * Should only set_jmp once (remember execute() can be called recursively)
 * buf_set should stop that happening and allow longjmp() to return to
 * the correct stack frame.
 */


#define MAX_EXECUTE  255

static sigjmp_buf   jmp_stack[MAX_EXECUTE+1];
static int          jmp_ptr = 0;

void exec_halt()
{
    /* if jmp == 0; then we're not executing and somehow this */
    /* has been invoked outside the main Sexecute() loop      */
    if (jmp_ptr == 0) return;

    --jmp_ptr;
    siglongjmp(jmp_stack[jmp_ptr],1);  
}

void catchable_error()
{
    if (error_code == SE_normal) error_code = SE_handled;

#if 0
    /* If we can't keep executing don't jump back into loop     */
    /* we've popped the Catch() block so SE_handled is returned */
    if (sPC == 0) return;
#endif

    exec_halt();
}

void terminal_error()
{
    terminate = 1;
    sPC = 0;

    /* jump to the outer apply/execute? */
    jmp_ptr = 1;    
    error_code = SE_fatal;

    /* reset overflow flag */
    catchable_error();
}


/* Program counter manipulation functions */

void SsetPC(byte * newpc)
{
    sPC = newpc;
}

byte * SgetPC()
{
    return sPC;
}

/* Initialisation functions */

void Sset_current(Obj * CO, const char * from)
{
#ifdef SDEBUG
    if (CO) printf("Sset_current (%s): %s\n", from, CO->name->str);
    else printf("Sset_current (%s): 0\n", from);
#endif
    currentO = CO;
}

void Sset_external_handler( void (*exh)(int) )
{
    efun_handler = exh;
}

void Sset_program_handler( Exec_block(*progh)(Obj *, Shared *) )
{
    /* Set the handler function to find program blocks given  */
    /* an object and function                                 */
    prog_handler = progh;
}

/* Stack Info Functions */

Obj * Scurrent()
{
    return currentO;
}

void sdum() { }

Stack_code Sexecute()
{
    int  instr;

    error_code = SE_normal;
    if ((jmp_ptr) >= MAX_EXECUTE) 
    {
        stack_error("execute() depth exceeded.\n");
        terminal_error();
    }
    
    if (!sigsetjmp(jmp_stack[jmp_ptr++],1))
    {
        while (1)
        {
            instr = (int) INST;
            (jmptable[instr].func) ();

            instr = (int) INST;
            (jmptable[instr].func) ();

            instr = (int) INST;
            (jmptable[instr].func) ();

            instr = (int) INST;
            (jmptable[instr].func) ();

            instr = (int) INST;
            (jmptable[instr].func) ();

            instr = (int) INST;
            (jmptable[instr].func) ();

            instr = (int) INST;
            (jmptable[instr].func) ();

            instr = (int) INST;
            (jmptable[instr].func) ();
        }
    }
    else
    {
        /* clear stacks and do what GC we can? */
        /* sdum(); */

        if (terminate)
        {
            clear_stack();
            terminate = 0;
        }
    }
    return error_code;
}


#if 0

/* Possible multi threading executing driver? */

Sthread_execute()
{
    if (!sigsetjmp(jmp_stack[jmp_ptr++],1))
    {
        while (1)
        {
            curr_id = context->proc_id;

            (jmptable[memory[context->pc]])();
            (jmptable[memory[context->pc]])();
            /* ... 100 to 1000 repetitions, all unrolled */

            if (context->proc_id == curr_id)
                (jmptable[CONTEXT_SWITCH])();
        }
    }
}

#endif


void undefined()
{
    char *x;

/*    printf("Instruction %s undefined.\n", codes[instr]); */
    x = (char *) INST32;
    printf("next pointer (as string) %s\n", x);
    fatal("FATAL: Undefined opcode executed.\n");
}

void push()
{
    Val *x;

    x = (Val *) INST32;
    STpush(x);
}

void push8()
{
    char a;
#if 1
    a = INST;
    STpush(Const(a));
#else
    Val * ret = alloc_stack_value();
    a = INST;
    ret->type = T_NUMBER;
    ret->u.number = a;
    STpush(ret);
#endif
}

void Push(Val * arg)
{
    STpush(arg);
}

void pushl()
{
    int  x;

    x = INST;
    last_local = x;
    STpush(STbase(x));
}

void pushg()
{
    unsigned int x;
    Obj * CO;

    x = (byte) INST;

#ifdef CBPSTUFF
    CO = CBP_OBJ;
#else
    CO = currentO;
#endif

#ifdef TESTING
    if (CO == NULL)
    {
        outputbt();
        fatal("FATAL: Lost current object in stack.c:pushg! This should not happen\n");
        return;
    }
#endif

    if (total_offset+x > CO->code->num_variables)
    {
        outputbt();
        overflow_flag = 1;
        stack_error("Illegal global variable number %d\n", total_offset + x);
        // terminal_error();
        // assert(1 == 0);
    }

    last_global = x + total_offset;

    if (CO->variables[total_offset + x].type == T_OBJECT
        && CO->variables[total_offset + x].u.ob->destructed)
    {
#if 0
        // free_object(CO->variables[total_offset + x].u.ob, "pushg");
#endif
        CO->variables[total_offset + x].type = T_NUMBER;
        CO->variables[total_offset + x].u.number = 0;
    }

    STpush(&CO->variables[total_offset + x]);
}

void pushi()
{
    int  x;

    x = INST32;
    STpush(make_number(x));
}

void pushr()
{
    unsigned long r;
    float z;

    r = INST32;
    z = *((float *) &r);
    STpush(make_real(z));
}

void pushs()
{
    unsigned int x;

    x = INST32;
    if (!x)
    {
        STpush(make_string(""));
    }
    else
    {
#if 0
        printf("pushs: %s\n", ((Shared *)x)->str);
#endif
        STpush(share_string((Shared *) x));
    }
}

/* put a number on the control stack */
void pushc()
{
    int  x;

    x = (int) INST;
    CTpush(x);
}

/* a 32 bit version - sigh */
void pushci()
{
    int  x;

    x = (int) INST32;
    CTpush(x);
}

int  Pushc(int arg)
{
    CTpush(arg);
    return 0;
}

void popi()
{
    Val *x, *y;

    y = STpop;
    x = STtop;

#if 0
    printf("pop into tos type = %d\n", x->type);
#endif
    if (y == x) return;

    clear_assign(x, y);
}

void popo()
{
    Val *x, *y;

    y = STpop;
    x = STpop;

#if 0
    printf("popo into tos type = %d\n", x->type);
#endif

    if (y == x) return;

    clear_assign(x, y);
}

void Pop(Val * arg)
{
    Val *x;

    x = STpop;
    copy_in_value(arg, x);
}

int  Popc()
{
    int  n = CTpop;
    return n;
}

void popl()
{
    int  x;
    Val *t;

    /* pop the top of the stack into a specific local variable */
    x = (byte) INST;
    t = STpop;
    clear_assign(STbase(x), t);
}

void popg()
{
    int  x;
    Val *t;

    /* pop top of stack into a specific global variable */
    x = (byte) INST;
    t = STpop;
#if 0
    printf("Popping global %d : off = %d : val = %d\n", x, total_offset,
           t->u.number);
#endif
    clear_assign(&currentO->variables[total_offset + x], t);
}

void addsp()
{
    int  i, x;
    char t;

    /* add to the stack pointer */
    t = (char) INST;
    x = (int) t;
    if (x > 0)
        for (i = 0; i < x; i++)
        {
            STpush(make_space(0));
        }
    else
        STA(x);
#if 0
    printf("stack is %d (added %d).\n", (rSP - (int) stack), x);
#endif
}

void aggregate()
{
    int  n, i;
    Val *a;

    /* build arrays quickly from the top of the stack */
    n = CTpop;
    a = allocate_array(n);
    for (i = 0; i < n; i++)
    {
        assign_value(&a->u.vec->item[n - i - 1], STpop);
    }
    STpush(a);
}

void my_switch()
{
    int  x, i, sz, skip = -1, def = -1;
    Val *t, *sw;

    t = STpop;
    x = (byte) INST;
    if (total_offset + x > currentO->code->num_variables)
    {
        fatal("FATAL: Illegal global var %d+%d number (in switch()) in %s\n",
              total_offset, x, currentO->name);
        return;
    }
    sw = &(currentO->variables[total_offset + x]);
    if (sw->type != T_POINTER)
    {  /* huh ? */
        stack_error("Illegal switch block\n");
        return;
    }
    sz = sw->u.vec->size - 2;
    for (i = 0; i < sz; i += 2)
    {
        if ((sw->u.vec->item[i].u.number == t->u.number)
            && (sw->u.vec->item[i].type == t->type))
        {
            /* we have a match */
            skip = sw->u.vec->item[i + 1].u.number;
            INC(skip);
            def = 0;
            break;
        }
        else if (sw->u.vec->item[i].u.number == -1 &&  /* default case */
                 sw->u.vec->item[i + 1].u.number < 0)
        {
            def = -sw->u.vec->item[i + 1].u.number - 1;
            /* -1 for 0 offset adjustment */
        }
    }
    if (def > -1)
    {  /* do default */
        INC(def);
    }
    else
    {  /* skip */
        skip = sw->u.vec->item[sz + 1].u.number;
        INC(skip);
    }

}

#if 0
void line(int x)
{
    extern int current_line;
    current_line = x;
}
#endif

void copy()
{
    int  x, i;

    /* Copies the top <x> elements of the stack */
    x = (int) INST;
    for (i = 0; i < x; i++)
    {
        STP(0) = STP(-x);
        STA(1);
    }
}

void callu()
{
    Val *x;

    /* If we get here then it's really a big fuck up! */
    printf("******** CALLU executed with arg: ");
    x = (Val *) INST32;
    if (!x)
        printf("0\n");
    else
        printf("type %d\n", x->type);
}

/*
 * This may be compiled away later but for now
 * we need to keep track of what program object
 * we are within - sigh
 * (thank god - much easier to add debug shit :)
 */

void calln()
{
    Obj *o;
    int  to, a;
    Func *x;

    x = (Func *) INST32;
    // o = STbase(-CBP_ARGS - 1);
    o = (Obj *)CBP_OBJ;

    DUMP_STATUS("\tcalln", o);

    STACK_CHECK;
    CSTACK_CHECK;

    /* newly on the control stack - no of args & global offset */
    a = CTP(-2);  /* no args */
    STP(-a - 1) = make_object(o);

    to = total_offset;
    total_offset += CTpop;
    CTpush((int) sPC);
    CTpush(total_offset);
    CTpush((int) o);
    CTpush((int) x);

    if (!x)
    {
        /* should be detected at compile time really! */
        stack_error("Local function not found.\n");
        return;
    }
    else
    {
        last_fun = x->name->str;
#if 0
        printf("calln: local %s\n", last_fun);
#endif
        /* type checked at compile time! */
        sPC = (byte *) ((int) (x->block) + a * 3);
    }
}

extern Shared * backtrace(int);

void outputbt()
{
    Func * prog;
    Shared * bt;

    prog = (Func *)CBP_FUNC;
    if (sPC != NULL && prog != NULL)
    {
        bt = backtrace((int)(sPC - (int) (prog->block)));
        printf("%s\n", bt->str);
    }
    else
    {
        printf("No backtrace available\n");
    }
}

/* really leave & return */
void _return()
{
    int  noargs, n, fv;
    Val tmp;

    assign_value(&tmp, STpop);

    last_global = NON_VAR;
    last_local = NON_VAR;
    rSP = rBP;  /* nuke locals */
    rCT = CBP - 1 * PWIDTH;  /* fix control stack */

    /* what if somehow CATCHBP > CT now? need to fix it.. */
    while (CATCHBP > rCT)
    {
        /* this should be fatal? */
        /* what if someone does "catch return;;"?? */
#if 0
        printf("W: %s: return() inside a catch() without enter()??.\n", ((Obj *)CBP_OBJ)->name->str);
        outputbt();
#endif
        /* -6 being the # of catch items on control stack */
        CATCHBP = CTacc(CATCHBP, -6);
#ifdef CATCHDEBUG
        printf("CATCHBP (set:return) = %d (rCT=%d)\n", (int)(CATCHBP - (int)control)/PWIDTH, (rCT-(int)control)/PWIDTH);
#endif
    }


    CBP = CBP_CBP;  /* restore old control CBP */
    rBP = CTpop;    /* restore old BP */
    fv = CTpop;     /* restore memory */
    if (CBP >= (int) control + CONTROL_NUM * PWIDTH)
    {
        (void) CTpop;
        total_offset = CBP_OFFSET;
    }
    else
    {
        (void) CTpop;
    }
    (void) CTpop;           /* function */
    (void) CTpop;           /* object   */
    sPC = (byte *) CTpop;  /* fix return address */
    noargs = CTpop;  /* how many var args? */

    STA(-noargs - 1);  /* nuke arguments & current obj */

#if 0
    printf("return to = %d(%s)\n", (int) sPC, currentO->name);
#endif

    if (!sPC)
    {  
        /* return to game driver control ? */
        currentO = (Obj *) CBP_OBJ;
#ifdef SDEBUG
    if (currentO) printf("Sset_current (_return): %s\n", currentO->name->str);
    else printf("Sset_current (_return): 0\n");
#endif
#if 0
        if (CBP >= (int) control + CONTROL_NUM * PWIDTH)
        {
            currentO = CBP_OBJ;
#if 0
            Obj * oldco;
            n = CBP_ARGS;
            oldco = currentO;
            if (((rBP - (int) stack)) > n * PWIDTH)
            {
                currentO = (STbase(-n - 1))->u.ob;
            }
            else
            {
                debug_message("Current_object fuck up in %s\n",
                              oldco->name);
            }
#endif
        }
#endif
        close_frame(fv);  /* free up previous frame */
        STpush(make_space(0));
        assign_value(STtop, &tmp);
        free_value(&tmp);   // MAYBE
#if 0
        printf("sPC:0: after return CT = %d, SP = %d, CBP = %d, BP = %d, off = %d\n",
               rCT, rSP, CBP, rBP, total_offset);
#endif
        DUMP_STATUS("RETURN: halt", 0);
        exec_halt();
        return;
    }

#if 0
    if (CBP >= (int) control + CONTROL_NUM * PWIDTH)
    {
#endif
#ifdef CBPSTUFF
        currentO = CBP_OBJ;
#else
        n = CBP_ARGS;
        currentO = (STbase(-n - 1))->u.ob;
#ifdef SDEBUG
    if (currentO) printf("Sset_current (_return 2): %s\n", currentO->name->str);
    else printf("Sset_current (_return 2): 0\n");
#endif
#endif
#if 0
    }
#endif

#ifdef CATCHDEBUG
    if (currentO)
        printf("Return control to %s\n", currentO->name->str);
    else
        printf("Return control no currentO.\n");
#endif

    /* Pop result into top of stack (should we need one) */
    close_frame(fv);  /* free up previous frame */
    STpush(make_space(0));
    assign_value(STtop, &tmp);
    free_value(&tmp);       // MAYBE

    DUMP_STATUS("RETURN: normal completion", 0);
}

void enter()
{
    int  x, i, n;
    Val *t;

    x = (int) INST;

    last_global = NON_VAR;
    last_local = NON_VAR;
#if 0
    // DUMP_STATUS("begin return", 0);
    printf("ENTER (%d params).\n", x);
    //printf("Entering with %d (stack), %d (rSP).\n", (int) stack, rSP);
#endif
    n = CTP(-5); /* get the # of params */
    CTpush(FV);  /* new frame for memory */
    CTpush(rBP);  /* control frame */
    CTpush(CBP);
    CBP = rCT;

    rBP = rSP;  /* value base pointer */
    /* hmm - since we only keep references on that stack */
    /* we need to make copies so it is pass by value (naughty!) */
    if (n > 0)
        for (i = 0; i < n; i++)
        {
            t = make_space(0);
            assign_value(t, STP(-i - 1));
            STP(-i - 1) = t;
        }

    /* space for locals */
/*    if (new_frame()) return; */
    if (x > 0)
        for (i = 0; i < x; i++)
        {
            STpush(make_space(0));
        }

#if 1
    currentO = (Obj *) CBP_OBJ;
#ifdef SDEBUG
    if (currentO) printf("Sset_current (enter): %s\n", currentO->name->str);
    else printf("Sset_current (enter): 0\n");
#endif
#else
    oldco = currentO;
    currentO = (STbase(-n - 1))->u.ob;
#endif

#if 0
    Obj *oldco;
    Shared * bt;
    Func * prog;
    prog = CBP_FUNC;

    if (sPC != NULL && prog != NULL)
    {
        bt = backtrace(sPC - (int) (prog->block));
        printf("%s\n", bt->str);
    }
    else
    {
        printf("No backtrace available\n");
    }

    if (!currentO)
    {
        if (oldco)
        {
#if 0
            debug_message("Current_object fuckup in enter(): %s\n",
                          oldco->name);
#endif
            currentO = oldco;
        }
        else
        {
#if 1
            debug_message("Current_object fuckup in enter()\n");
#endif
        }
    }
#endif
}

void catch()
{
    int  x;

    DUMP_STATUS("\tcatch", NULL);

    x = (int) INST16;
    CTpush(CATCHBP);
    CTpush(rSP);
    CTpush(rBP);
    CTpush(CBP);
/* printf("Catch %d lines ahead.\n", x); */
    CTpush((int) sPC + x);  /* line to jump to on error! */
    CTpush(FV);
    CATCHBP = rCT;
#ifdef CATCHDEBUG
    printf("CATCHBP (set:catch) = %d\n", (int)(CATCHBP - (int)control)/PWIDTH);
#endif
}

void Catch(void *x)
{
    /* Game driver Catch() */
    DUMP_STATUS("\nCATCH", NULL);
    CTpush(CATCHBP);
    CTpush(rSP);
    CTpush(rBP);
    CTpush(CBP);
    CTpush(0);  /* (int)x;   line to jump to on error! */
    CTpush(FV);
    CATCHBP = rCT;
#ifdef CATCHDEBUG
    printf("CATCHBP (set:Catch) = %d\n", (int)(CATCHBP - (int)control)/PWIDTH);
#endif
}

void popcatch()
{
    /* pop catch information off the stack */
#ifdef CATCHDEBUG
    CATCHBP = CATCH_CATCH;
    return;
    printf("CATCHBP (set:popcatch) = %d\n", (int)(CATCHBP -(int) control)/PWIDTH);
#endif
    if (CATCHBP > (int) control)
    {
        rCT = CATCHBP;
        CTA(-4);
        rSP = CTpop;
        CATCHBP = CTpop;
        STpush(Const(0));
    }
}

void Popcatch()
{
    /* Game driver popcatch() */
    DUMP_STATUS("POPCATCH", 0);
#ifdef CATCHDEBUG
    CATCHBP = CATCH_CATCH;
    return;
    printf("CATCHBP (set:Popcatch) = %d\n", (int)(CATCHBP - (int)control)/PWIDTH);
#endif
    if (CATCHBP > (int) control)
    {
        rCT = CATCHBP;
        CTA(-5);
        CATCHBP = CTpop;
    }
}

int  Execcatch()
{
    int  fv;

    /* should we also restore total_offset in here?? */
    rCT = CATCHBP;
    fv = CTpop;
    sPC = (byte *) CTpop;
    CBP = CTpop;
    rBP = CTpop;
    rSP = CTpop;
    if (CBP >= (int) control + CONTROL_NUM * PWIDTH)
    {
        total_offset = CBP_OFFSET;  /* ick - wrong? */
    }
    else
    {
        total_offset = 0;
    }
    CATCHBP = CTpop;
#ifdef CATCHDEBUG
    printf("CATCHBP (set:Execcatch) = %d\n", (int)(CATCHBP - (int)control)/PWIDTH);
#endif
#if 1
    /* this shouldn't happen! */
    if ((CATCHBP - (int) control) > CSTACK_OFLOW * 4)
    {
        printf("New CATCHBP FUCKED!!\n");
        CATCHBP = (int) control;
    }
#endif

    currentO = (Obj *)CBP_OBJ;
#ifdef SDEBUG
    if (currentO) printf("Sset_current (Execcatch): %s\n", currentO->name->str);
    else printf("Sset_current (Execcatch): 0\n");
#endif
    close_frame(fv);

#if 0
    STpush(make_space(0));    /* necessary? */
#endif

    if (sPC)
        return 1;
    else
        return 0;
}

void throw()
{
    Val *x;

    x = STpop;
    if (CATCHBP == 0 || CATCHBP == (int) control)
    {
        stack_error("Throw without a catch.\n");
    }
    else if (x->type != T_STRING)
    {
        stack_error("Unknown error - throw() with no string.\n");
    }
    else
    {
        stack_error(x->u.string->str);
    }

    (void) STpop;

#if 0
    /* should this occur? */
    if (sPC == 0) exec_halt();
#endif
}

/*
 * Arithmetic
 * 
 * o these could be quicker (no type checks) if I compiled
 * more carefully (type checking in there).
 */
#define MAX_NUM_WIDTH 32
Shared * to_string(Val * s)
{
    char * t;
    Shared * ret;

    if (s->type == T_NUMBER)
    {
        t = malloc(MAX_NUM_WIDTH);
        sprintf(t, "%d", s->u.number);
        ret = string_copy(t);
        free(t);
        return ret;
    }
    else if (s->type == T_REAL)
    {
        t = malloc(MAX_NUM_WIDTH);
        sprintf(t, "%6.3f", s->u.real);
        ret = string_copy(t);
        free(t);
        return ret;
    }
    else if (s->type == T_POINTER)
    {
        stack_error("Array in string addition.\n");
        return 0;
    }
    else if (s->type == T_OBJECT)
    {
        /* FIX: should be an error.. */
        printf("Object in string addition!\n");
        return shared_string_copy(s->u.ob->name);
    }
    else if (s->type == T_STRING)
    {
        return shared_string_copy(s->u.string);
    }

    stack_error("Unknown type in to_string().\n");
    return 0;
}


#define MAX_PLUS 65536
void plus()
{
    Val *x, *y, *z;

    x = STpop;
    y = STpop;
    if ((x->type == T_NUMBER) && (y->type == T_NUMBER))
    {
        z = make_number(y->u.number + x->u.number);
    }
    else if ((x->type == T_POINTER) && (y->type == T_POINTER))
    {
        z = concatenate(y, x);
    }
    else if ((x->type == T_STRING) || (y->type == T_STRING))
    {
        Shared * p1, * p2, * ss;

        /* string addition - blah */
        if (y->type & T_STRING)
            p1 = shared_string_copy(y->u.string);
        else
            p1 = to_string(y);

        if (x->type & T_STRING)
            p2 = shared_string_copy(x->u.string);
        else
            p2 = to_string(x);

        if (p2 == NULL) 
        {
            //stack_error("Unable to convert arg into string (string + <arg>)\n");
            return;
        }
        z = share_string(ss = string_cat(p1, p2));
        free_string(ss);
        free_string(p1);
        free_string(p2);
    }
    else
    {
        float a, b;
        itype_check(y, T_NUMBER | T_REAL, "plus", 1);
        itype_check(x, T_NUMBER | T_REAL, "plus", 2);
        a = igetreal(y);
        b = igetreal(x);
        z = make_real(a + b);
    }

    STpush(z);
}


void minus()
{
    Val *x, *y, *z;

    x = STpop;
    y = STpop;
    if ((x->type & T_NUMBER) && (y->type & T_NUMBER))
    {
#if 0
        printf("integer minus.\n");
#endif
        z = make_number(y->u.number - x->u.number);
    }
    else
    {
        float a, b;
        itype_check(y, T_NUMBER | T_REAL, "minus", 1);
        itype_check(x, T_NUMBER | T_REAL, "minus", 2);
        a = igetreal(y);
        b = igetreal(x);
        z = make_real(a - b);
    }
    STpush(z);
}

void mult()
{
    Val *x, *y, *z;

    x = STpop;
    y = STpop;
    if ((x->type & T_NUMBER) && (y->type & T_NUMBER))
        z = make_number(y->u.number * x->u.number);
    else
    {
        float a, b;
        itype_check(y, T_NUMBER | T_REAL, "multiply", 1);
        itype_check(x, T_NUMBER | T_REAL, "multiply", 2);
        a = igetreal(y);
        b = igetreal(x);
        z = make_real(a * b);
    }
    STpush(z);
}

void divide()
{
    Val *x, *y, *z;

    x = STpop;
    y = STpop;
    if (x->u.number == 0)
    {
        stack_error("Division by zero error.\n");
        return;
    }
    if ((x->type & T_NUMBER) && (y->type & T_NUMBER))
        z = make_number(y->u.number / x->u.number);
    else
    {
        float a, b;
        itype_check(y, T_NUMBER | T_REAL, "divide", 1);
        itype_check(x, T_NUMBER | T_REAL, "divide", 2);
        a = igetreal(y);
        b = igetreal(x);
        z = make_real(a / b);
    }
    STpush(z);
}

void mod()
{
    Val *x, *y, *z;

    x = STpop;
    y = STpop;
    if (x->u.number == 0)
    {
        stack_error("Modulo by zero error.\n");
        return;
    }
    if ((x->type & T_NUMBER) && (y->type & T_NUMBER))
        z = make_number(y->u.number % x->u.number);
    else
    {
        stack_error("Illegal type to modulo.\n");
        return;
    }
    STpush(z);
}

/*
 * Comparitors 
 */
void eq()
{
    Val *x, *y;

    x = STpop;
    y = STpop;
    if ( /*x->type == y->type && */ x->u.number == y->u.number)
    {
        STpush(Const(1));
    }
    else
    {
        STpush(Const(0));
    }
}

void ne()
{
    Val *x, *y;

    x = STpop;
    y = STpop;
    if ( /*x->type == y->type && */ x->u.number == y->u.number)
    {
        STpush(Const(0));
    }
    else
    {
        STpush(Const(1));
    }

}

void gt()
{
    Val *x, *y;

    int  r = 0;
    x = STpop;
    y = STpop;

    if (!(x->type & y->type & T_ANY))
    {
        stack_error("Illegal types compared in > operator.\n");
        return;
    }

    switch (x->type & T_ANY)
    {
        case T_NUMBER:
            if (y->u.number > x->u.number) r = 1;
            break;
        case T_STRING:
            if (string_cmp(y->u.string, x->u.string) > 0) r = 1;
            break;
        case T_REAL:
            if (y->u.real > x->u.real) r = 1;
            break;
        default:
            stack_error("Illegal types compared in > operator.\n");
    }

    STpush(Const(r));
}

void ge()
{
    Val *x, *y;

    int  r = 0;
    x = STpop;
    y = STpop;

    if (!(x->type & y->type & T_ANY))
    {
        stack_error("Illegal types compared in >= operator.\n");
        return;
    }


    switch (x->type & T_ANY)
    {
        case T_NUMBER:
            if (y->u.number >= x->u.number) r = 1;
            break;
        case T_STRING:
            if (string_cmp(y->u.string, x->u.string) >= 0) r = 1;
            break;
        case T_REAL:
            if (y->u.real >= x->u.real) r = 1;
            break;
        default:
            stack_error("Illegal types compared in >= operator.\n");
            return;
    }

    STpush(Const(r));
}

void le()
{
    Val *x, *y;
    int  r = 0;

    x = STpop;
    y = STpop;

    if (!(x->type & y->type & T_ANY))
    {
        stack_error("Illegal types compared in <= operator.\n");
        return;
    }

    switch (x->type & T_ANY)
    {
        case T_NUMBER:
            if (y->u.number <= x->u.number) r = 1;
            break;
        case T_STRING:
            if (string_cmp(y->u.string, x->u.string) <= 0) r = 1;
            break;
        case T_REAL:
            if (y->u.real <= x->u.real) r = 1;
            break;
        default:
            stack_error("Illegal types compared in <= operator.\n");
            return;
    }

    STpush(Const(r));
}

void lt()
{
    Val *x, *y;
    int  r = 0;

    x = STpop;
    y = STpop;

    if (!(x->type & y->type & T_ANY))
    {
        stack_error("Illegal types compared in < operator.\n");
        return;
    }

    switch (x->type & T_ANY)
    {
        case T_NUMBER:
            if (y->u.number < x->u.number) r = 1;
            break;
        case T_STRING:
            if (string_cmp(y->u.string, x->u.string) < 0) r = 1;
            break;
        case T_REAL:
            if (y->u.real < x->u.real) r = 1;
            break;
        default:
            stack_error("Illegal types compared in < operator.\n");
            return;
    }

    STpush(Const(r));
}

/*
 * Arithmetic operators
 */
void and()
{
    Val *x, *y, *z;

    x = STpop;
    y = STpop;
    z = make_number(x->u.number & y->u.number);
    STpush(z);
}

void lsh()
{
    Val *x, *y, *z;

    x = STpop;
    y = STpop;
    itype_check(y, T_NUMBER, "lsh", 1);
    itype_check(x, T_NUMBER, "lsh", 2);
    z = make_number(y->u.number << x->u.number);
    STpush(z);
}

void rsh()
{
    Val *x, *y, *z;

    x = STpop;
    y = STpop;
    itype_check(y, T_NUMBER, "rsh", 1);
    itype_check(x, T_NUMBER, "rsh", 2);
    z = make_number(y->u.number >> x->u.number);
    STpush(z);
}

void not()
{
    Val *x, *y;

    x = STpop;
    itype_check(x, T_NUMBER, "arithmetic not", 1);
    y = make_number(~x->u.number);
    STpush(y);
}

/* tos should be a number! */
void addind()
{
    Val *x, *y;

    x = STpop;
    if (!(x->type & T_NUMBER))
    {
        stack_error("Illegal type in subscript expression.\n");
        return;
    }
    y = STpop;
    if (y->type & T_POINTER)
    {
        if (x->u.number >= y->u.vec->size ||
            x->u.number < 0)
        {
            stack_error("Subscript out of range.\n");
            return;
        }

        if (y->u.vec->item[x->u.number].type == T_OBJECT
            && y->u.vec->item[x->u.number].u.ob->destructed)
        {
#if 0
            /* this is an ugly way of freeing up references! */
            // free_object(y->u.vec->item[x->u.number].u.ob, "addind");
#endif
            y->u.vec->item[x->u.number].type = T_NUMBER;
            y->u.vec->item[x->u.number].u.number = 0;
        }

        // FIX: should this really be a full copy??
        STpush(&(y->u.vec->item[x->u.number]));
        return;
    }
    else if (y->type & T_STRING)
    {
        if (x->u.number >= y->u.string->length ||
            x->u.number < 0)
        {
/*            stack_error("Subscript out of range on string.\n"); */
            /* ok - ugly compat hack :-( */
            STpush(make_space(0));
            return;
        }
        STpush(make_number(*(y->u.string->str + x->u.number)));
        return;
    }
#if 0
    printf("Addind: num val %d of type %d\n", y->u.number, y->type);
    printf("Addind: subscript val %d\n", x->u.number);
#endif
    stack_error("Illegal type in expression being subscripted.\n");
    return;
}

/*
 * on stack obj, args
 * next_inst is function to call.
 */

void callo()
{
    Shared * x;
    int r;

    x = (Shared *) INST32;

    sdum();
#if 1
    DUMP_STATUS("\tcallo", 0);
#else
    printf("\tcallo: %s:%s\n", currentO->name->str, x->str);
#endif

    /* stack safety checks! */
    STACK_CHECK;
    CSTACK_CHECK;

    r = Callother(x);

#if 0
    /* This occurs because sPC == 0 and it trying to return */
    /* control to the GD (after a failed load?); force      */
    /* an exec_halt() to get back to GD.                    */
    if (r == 0 && sPC == 0)  
    {
        exec_halt();
    }
#endif
}

/*
 * Emulated efuns and old call_other()  calls
 *
 * stack: obj, func name, args
 */

void Callo()
{
    Val *fun_name;
    int  n, i, r;

    /* find no of arguments */
    n = CTP(-1);  
    /* get the function name */
    fun_name = STP(-n - 1);  

    /* move args down 1 and trim name from stack 
     * cause we don't want it there (perhaps this'll change). */
    for (i = n; i > 0; i--)
    {
        STP(-i - 1) = STP(-i);
    }
    STA(-1);

    /* stack[SP-n-1] is the object being called */
    // DUMP_STATUS("Callo", STP(-n - 1)->u.ob);
#if 1
    DUMP_STATUS("\tCallo", 0);
#else
    if (fun_name->u.string)
        printf("\tCallo: %s:%s\n", currentO->name->str, fun_name->u.string->str);
    else
        printf("\tCallo: %s/%d:(NO FUNCTION PROBLEM)\n", currentO->name->str, n);
#endif

    /* stack safety checks! */
    STACK_CHECK;
    CSTACK_CHECK;
    r = Callother(fun_name->u.string);

#if 0
    /* This occurs because sPC == 0 and it trying to return */
    /* control to the GD (after a failed load?); force      */
    /* an exec_halt() to get back to GD.                    */
    if (r == 0 && sPC == 0) 
    {
        exec_halt();
    }
#endif

}

static int Callother(Shared * funstr)
{
    Val *o;
    byte *tpc = 0;
    Obj  *obj;
    Func *prog;
    Exec_block progb;
    int prog_arg;
    int  n;

    if (funstr == NULL)
    {
        //outputbt();
        stack_error("No function (!!) in Callother()\n");
        return 0;
    }

    n = CTP(-1);
    o = STP(-n - 1);

    /* get a copy of the object on the stack */
    if (o->type & T_OBJECT)
    {
        obj = o->u.ob;
        o = make_object(obj);
        STP(-n - 1) = o;
    }
#if 1
    else if (o->type & T_STRING)
    {
#if 0
        void *oldsPC;
        oldsPC = sPC;
        sPC = 0; 
#endif
        /* FIX: this may invoke load_object */
        /* Note: stack currently has a string on it - instead */
        /* of an object - error report problems? */

        obj = find_object(o->u.string);

#if 0
        sPC = oldsPC; 
#endif
        if (!obj)
        {

            stack_error("Failed to load %s.\n", o->u.string->str);

#if 0
            else
            {
                /* quick hack to fix callo so it works with */
                /* the efun() and direct */

                Val *t;
                efun_error("Failed to load %s.\n", o->u.string->str);
                /* fix top of stack (see efun invocation) */
                t = STpop;
                STA(-1);
                STpush(t);
            }
#endif
            return 0;
        }

        currentO = (Obj *)CBP_OBJ;
#ifdef SDEBUG
        if (currentO) printf("Sset_current (Callother): %s\n", currentO->name->str);
        else printf("Sset_current (Callother): 0\n");
#endif
        o = make_object(obj);

        /* this is bad! - we lose the string after the call_other.. */
        /* probably don't free the string either ? */
        STP(-n - 1) = o;  /* can we get away without it? */
    }
#endif
    else
    {
        stack_error("Illegal object in call_other() - function %s\n", funstr->str);
        return 0;
    }

    /* problem checks */
    if (!obj)
    {
        stack_error("No object in call_other()\n");
        return 0;
    }

    if (obj->destructed)
    {
/*      stack_error("Executing %s in destructed object.\n", x->u.string); */
        return 0;
    }

    progb = (prog_handler)(obj, funstr);

    prog = progb.prog;
    if (prog)
    {
        tpc = prog->block;
        prog_arg = prog->num_arg;
    }
    else
    {
        tpc = 0;
        prog_arg = 0;
    }

    /* fix up number of parameters; clear if tpc not found */
    while (n < prog_arg)
    {
        STpush(make_space(0));
        n++;
    }
    while (n > prog_arg)
    {
        STA(-1);
        n--;
    }
    CTP(-1) = n;

    CTpush((int) sPC);

    /* either we set up to go or we clean up */
    if (tpc)
    {
        if (!stype_check(tpc, prog_arg, obj->name->str, prog->name->str))
            return 0;

        total_offset = progb.var_offset;  /* set in find_program - ugly */
        CTpush(total_offset);
        CTpush((int)obj);
        CTpush((int)prog);
        last_fun = funstr->str;
        sPC = (void *) ((unsigned int) tpc + prog_arg * 3);
    }
    else
    {
        /* we didn't find the function */
        CTA(-2);
        STA(-n - 1);  /* correct? */
        STpush(Const(0));
        return 0;
    }
    return 1;
}

#ifdef DEBUG
static int last_efun = 0;
#endif
void efun()
{
    byte tt;
    int  x;
    Val *t;

    tt = (byte) INST;
    x = (int) tt;
#ifdef DEBUG
    last_efun = x;
#endif
    (efun_handler)(x);

    /* Because stack was set up as a normal function call  */
    t = STpop;
    STA(-1);
    STpush(t);

#if 0
    /* An error in the efun which should return to GD   */
    if (sPC == 0) exec_halt();
#endif
}

void efun_direct()
{
    byte tt;
    int  x;

    tt = (byte) INST;
    x = (int) tt;
#ifdef DEBUG
    last_efun = x;
#endif
    (efun_handler)(x);

#if 0
    /* An error in the efun which should return to GD   */
    if (sPC == 0) exec_halt();
#endif
}

void jnzero()
{
    int  x;
    short tt;
    Val  t;

    tt = (short) INST16;
    x = (int) tt;
    Pop(&t);
    if (t.u.number)
        INC(x);
    /* should this leave something on the stack?? */
}

void jump()
{
    int  x;
    short t;

    t = (short) INST16;
    x = (int) t;
#if 0
    printf("Jumping %d\n", x);
#endif
    INC(x);
}

void jzero()
{
    int  x;
    short tt;
    Val  t;

    tt = (short) INST16;
    x = (int) tt;
    Pop(&t);
#if 0
    printf("jzero finds %d : loc = %d\n", t.u.number, x);
#endif
    if (!t.u.number)
        INC(x);
}

void land()
{
    Val *x, *y;

    x = STpop;
    y = STpop;
    if (x->u.number && y->u.number)
    {
        STpush(Const(1));
    }
    else
    {
        STpush(Const(0));
    }
}

void lnot()
{
    Val *x;

    x = STpop;
    if (x->u.number == 0)
    {
        STpush(Const(1));
    }
    else
    {
        STpush(Const(0));
    }
}

void lor()
{
    Val *x, *y;

    x = STpop;
    y = STpop;
    if (x->u.number || y->u.number)
    {
        STpush(Const(1));
    }
    else
    {
        STpush(Const(0));
    }
}

void negate()
{
    int  y;
    float z;
    Val *x;

    x = STpop;
    if (x->type == T_REAL)
    {
        z = -x->u.real;
        STpush(make_real(z));
    }
    else
    {
        y = -x->u.number;
        STpush(make_number(y));
    }
}

void or()
{
    Val *x, *y;
    int  r;

    x = STpop;
    y = STpop;
    r = x->u.number | y->u.number;
    STpush(make_number(r));
}

void xor()
{
    Val *x, *y;
    int  r;

    x = STpop;
    y = STpop;
    r = x->u.number ^ y->u.number;
    STpush(make_number(r));
}

#if 0
void smextract()
{
#if 0
    printf("extract()\n");
#endif
    EXTRACT();
}
#endif

/* compiled in check for stack overflow! */
void oflow_check()
{
    STACK_CHECK;
}

int dump_status(char *fun, Obj * obj)
{
    char * unknown = "(unknown)";
    if (fun == NULL) fun = unknown;
    printf("%s with CT=%d, SP=%d, CBP=%d, BP=%d, CATCH=%d, off=%d, ",
           fun, (rCT - (int) control) / PWIDTH,
           (rSP - (int) stack) / PWIDTH,
           (CBP - (int) control) / PWIDTH,
           (rBP - (int) stack) / PWIDTH, 
           (CATCHBP - (int) control) / PWIDTH,
           total_offset);
#if 0
    if (obj == NULL)
    {
        printf("CO=");
        obj = CBP_OBJ;
    }
#endif
    if (obj && obj->name)
        printf("%s.\n", obj->name->str);
    else
        printf("\n");
    return 0;
}


// XXXX: ugly - relies on a runtime var.
extern int in_save_object;

void clear_stack()
{
#ifdef DEBUG
    printf("CLEARING STACK.\n");
#if 0
    debug_message("CLEARING STACKS.\n");
#endif
#endif
    in_save_object = 0;
    overflow_flag = 0;
    total_offset = 0;
    rSP = (int) stack;  /* quite often the driver will clear off 1 more arg */
    rBP = (int) stack;
    rCT = (int) control;
    CBP = (int) control;
    CATCHBP = (int) control;
#ifdef CATCHDEBUG
    printf("CATCHBP (set:clear_stack) = %d\n", (int)(CATCHBP - (int)control)/PWIDTH);
#endif
    close_frame(0);
    Catch(0);
    initfixedints();
}

void my_end()
{
/*    clear_stack(); */
    stack_error("Premature End\n");
}

/* both must be allocated! */
void copy_in_value(Val * dst, Val * src)
{

    dst->type = src->type;
    switch (src->type)
    {
        case T_STRING:
            dst->u.string = src->u.string;
            return;
        case T_OBJECT:
            dst->u.ob = src->u.ob;
            return;
        case T_NUMBER:
            dst->u.number = src->u.number;
            return;
        case T_REAL:
            dst->u.real = src->u.real;
            return;
        case T_POINTER:
            dst->u.vec = src->u.vec;
            return;
    }
    fatal("FATAL: Copy_in_value() - type is buggered (was %d)\n", dst->type);
}

/*
 * these are ugly; primarily caused by LPCs poor capability handling
 */
#if 0
void caller()
{
    Val * x;
    int  a, oBP, 

    oCBP = CBP;

    // is the stack deep enough?
    if ((CBP - (int) control) < CONTROL_NUM * 2 - 1)
    {
        STpush(Const(0));
        return;
    }

    oBP = CBP_BP;
    CBP = CBP_CBP;
    a = CBP_ARGS;
    if (oBP - a - 1 - (int) stack >= 0)
    {
        x = STacc(oBP, -(a + 1));
        if (x->type == T_OBJECT)
        {
            STpush(make_object(x->u.ob));
        }
        else
        {
            STpush(Const(0));
        }
        //STpush(STacc(oBP, -(a + 1)));
    }
    else
    {
        STpush(Const(0));
    }
    CBP = oCBP;
}
#endif

Obj * Scaller()
{
    Val * x;
    Obj * ret = NULL;
    int  a, oBP, 

    oCBP = CBP;

    // is the stack deep enough?
    if ((CBP - (int) control) < CONTROL_NUM * 2 - 1)
    {
        return NULL;
    }

    oBP = CBP_BP;
    CBP = CBP_CBP;
    a = CBP_ARGS;
    if (oBP - a - 1 - (int) stack >= 0)
    {
        x = STacc(oBP, -(a + 1));
        if (x->type == T_OBJECT)
        {
            ret = x->u.ob;
        }
    }

    CBP = oCBP;
    return ret;
}

void caller()
{
    Obj * o = Scaller();

    if (o == NULL)
    {
        STpush(Const(0));
    }
    else
    {
        STpush(make_object(o));
    }
}

void previous_object()
{
    Val * x;
    int  a, 
        oBP, 
        oCBP = CBP;
    Obj * top;

    a = CBP_ARGS;
    x = STacc(CBP_BP, -(a + 1));
    if (x) top = x->u.ob;
    else top = currentO;

    while (1)
    {
        if ((CBP - (int) control) < CONTROL_NUM * 2 - 1)
        {
            STpush(Const(0));
            break;
        }
        oBP = CBP_BP;
        CBP = CBP_CBP;
        a = CBP_ARGS;
        if (oBP - a - 1 - (int) stack >= 0)
        {
            x = STacc(oBP, -(a + 1));
            if (x->type == T_OBJECT && x->u.ob != top)
            {
                STpush(make_object(x->u.ob));
                break;
            } 
        }
        else
        {
            STpush(Const(0));
            break;
        }
    }

    CBP = oCBP;
    return;
}

