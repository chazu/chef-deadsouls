/*
** $Id: value.h,v 1.3 2003/05/24 07:47:09 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpvm/value.h,v $
** $Revision: 1.3 $
** $Date: 2003/05/24 07:47:09 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _VALUE_H
#define _VALUE_H

#include "stack.h"
#include "stralloc.h"
#include "object.h"

#if 0
union u 
{
    Shared * string;
    int number;
    float real; /* check that it fits :) */
    struct object * ob;
    struct vector * vec;
    struct vector_regexp * reg;
};

/*
 * The definition of a value node.  It is used for all computations.
 * Strings can NOT be constant!  All strings (in values) should be created
 * with string_copy (since constant strings might be inside other strings which
 * could be freed anyway).
 */

struct value 
{
    union u u;
    int type;
};
typedef struct value Val;
#endif

/*
 * Definition for constant values in the object global table.
 * Really a hack-on. GW.
 */
struct constval 
{
	struct value * val;
	Shared * name;
	int type;
};
typedef struct constval CVal;

#define NullValue	(struct value *)0

/*
 * Use bitflags for type checking
 */

#define T_INVALID	0
#define T_VOID      0
#define T_NUMBER	1	/* bit 0 */
#define T_REAL		2
#define T_STRING	4
#define T_OBJECT	8
#define T_POINTER	16
#define T_IMAGE		32
#define TY_STATIC	128
#define TY_UNDEFC	256
#define TY_PRIVATE	512
#define TY_CONSTANT     1024

#ifdef GRAPHICS
#define T_NUM		7
#else
#define	T_NUM		6	/* left shift to get past types */
#endif

#define T_ANY		((1<<T_NUM)-1)

extern struct value *alloc_value();

#define ARRAY_STATS

#ifdef ARRAY_STATS
extern unsigned int total_array_size, num_arrays;
#endif


typedef struct vector 
{
    short size;
    short ref;
    struct value item[1];
} Vec;

#define ALLOC_VECTOR(nelem) \
    (struct vector *)malloc(sizeof (struct vector) + \
                          sizeof(struct value) * (nelem - 1))

/*
 * regexp compiled code is stored in vector of size -1.
 * This is not implemented yet.
 */
struct vector_regexp 
{
    Vec vector;
    struct regexp *regexp;
};

#define MINFIXEDINT (-128)
#define MAXFIXEDINT (127)
#define Const(x) (&staticints[x-MINFIXEDINT])

/*
 * This is the maximum array size allowed for a single array.
 */
#define MAX_ARRAY_SIZE      50000

extern Val staticints[];

void 
    assign_value(Val * dest, Val * v),
    clear_assign(Val * dest, Val * v),
    free_value(Val * v),
    free_vector(Vec * p)
    ;

Val 
    * alloc_value(),
    * allocate_array(int n),
    * copy_value(Val * arg),
    * make_number(int n),
    * make_object(struct object * n),
    * make_real(float n),
    * make_string(const char * str),
    * make_nstring(const char * str, int n),
    * make_vector(Vec * p),
    * share_string(Shared * str)
    ;

char 
    * typename(int)
    ;

int 
    copy_in_vector(struct vector *a, struct vector *b, int, int, int)
    ;

/* Vector stuff */
Vec * create_vector(int n, const char * from);
Val * concatenate(Val * a, Val * b);

int initfixedints();

#endif

