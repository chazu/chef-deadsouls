/**************************************************************************
 * bitmap.c                                                               *
 * written by David Brackeen                                              *
 * http://www.brackeen.com/home/vga/                                      *
 *                                                                        *
 * This is a 16-bit program.                                              *
 * Tab stops are set to 2.                                                *
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned long  dword;

void main()
{
  printf("%x",16);
  return;
}

