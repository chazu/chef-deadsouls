/* config.h.  Generated automatically by configure.  */
#ifndef CONFIG_H

/* find out the machine and OS */
#define CPU_VENDOR_OS "i686-pc-linux-gnu"
#define TARGET_CPU "i686"
#define TARGET_VENDOR "pc"
#define TARGET_OS "linux-gnu"

/* paths */

/* #undef IFCONFIG */
#define ROUTE "/sbin/route"

/* host defines */
/* #undef BSD */
#define LINUX 1
/* #undef SOLARIS */

/* #undef HAVE_MSGHDR_MSG_CONTROL */

/* the following may have to be defined (for some Linuxes) */
#define BROKEN_CMSG_FIELDS 1

/* host properties */
#define USE_IFALIAS 1
/* #undef USE_BPF */
/* #undef USE_DLPI */
#define USE_SOCKET 1
/* #undef USE_GC */
/* #undef USE_ZLIB */

/* sort out some basic header files */
#define STDC_HEADERS 1
#define HAVE_MALLOC_H 1 
#define HAVE_VARARGS_H 1 
#define HAVE_STRINGS_H 1
#define HAVE_FCNTL_H 1
#define HAVE_SYS_FCNTL_H 1
/* #undef HAVE_SYS_DLPI_H */
#define HAVE_NET_IF_PACKET_H 1
#define HAVE_NETINET_IF_ETHER_H 1
#define HAVE_NET_IF_ARP_H 1
/* #undef HAVE_NET_BPF_H*/

/*#undef HAVE_CRYPT_H*/
#define HAVE_CRYPT_H 1
#define HAVE_ZLIB_H 1

/* check for functions in certain headers */
#define STDLIB_MALLOC 1

/* check for certain declarations */
#define HAVE_SYS_ERRLIST 1

/* check for srandom()/random() */
#define HAVE_SRANDOM 1

/* check for strcspn() */
#define HAVE_STRING_STRCSPN 1

/* figure out basic integers and appropriate header files if available */
#define HAVE_int8_t 1
#define HAVE_u_int8_t 1
#define HAVE_int16_t 1
#define HAVE_u_int16_t 1
#define HAVE_int32_t 1
#define HAVE_u_int32_t 1
#define HAVE_int64_t 1
#define HAVE_u_int64_t 1

#define SIZEOF_CHAR 1
#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
#define SIZEOF_LONG 4
#define SIZEOF_LONG_LONG 8

#define BIT8 char
#define BIT16 short
#define BIT32 long
#define BIT64 long long

/* structures */
/* #undef HAVE_sockaddr_dl */ 
#define HAVE_arpreq 1 
#define HAVE_ether_header 1
#define HAVE_caddr_t 1
#define HAVE_ethhdr 1
#define HAVE_in_addr 1
#define HAVE_sockaddr 1
#define HAVE_sockaddr_in 1

/* defines */
#define HAVE_SIOCGIFHWADDR 1
/* #undef HAVE_SIOCGIFCONF */
/* #undef HAVE_SIOCGARP */
/* #undef HAVE_DLIOCRAW */
#define HAVE_ETHER_ADDR_LEN 1
/* #undef HAVE_ETHERADDRL */
/* #undef HAVE_ETH_ALEN */

/* define fields in structures */
/* #undef SA_LEN_IN_SOCKADDR */
/* #undef ETHER_HEADER_USES_ETHER_ADDR */

/* header files we need for things we found */
#define NEED_NET_ETHERNET_H 1
/* #undef NEED_NET_IF_DL_H */
/* #undef NEED_SYS_ETHERNET_H */
/* #undef NEED_SYS_SOCKIO_H */
/* #undef NEED_SYS_SOCKETIO_H */
#define NEED_SYS_SOCKET_H 1
#define NEED_NET_IF_ARP_H 1
#define NEED_NETINET_IN_H 1
#define NEED_SYS_BITYPES_H 1
#define NEED_SYS_TYPES_H 1
#define NEED_LINUX_SOCKIOS_H 1
#define NEED_NETINET_IF_ETHER_H 1

/* uid for setuid programs which manipulate interfaces */ 
#define EDDIE_UID 0

#define CONFIG_H 1
#endif
