/* A Bison parser, made by GNU Bison 1.875a.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_STATIC = 258,
     TOK_PRIVATE = 259,
     TOK_TYPE = 260,
     TOK_CLASS = 261,
     TOK_SELF = 262,
     TOK_ARRAY = 263,
     TOK_OBJECT = 264,
     TOK_STRING_DECL = 265,
     TOK_REALT = 266,
     TOK_INT = 267,
     TOK_NUMBER = 268,
     TOK_STRING = 269,
     TOK_REAL = 270,
     TOK_SWITCH = 271,
     TOK_CASE = 272,
     TOK_DEFAULT = 273,
     TOK_IDENTIFIER = 274,
     TOK_TYNAME = 275,
     TOK_NEW = 276,
     TOK_VOID = 277,
     TOK_INHERIT = 278,
     TOK_COLON_COLON = 279,
     TOK_ENUM = 280,
     TOK_AS = 281,
     TOK_IMPORT = 282,
     TOK_END = 283,
     TOK_MODULE = 284,
     TOK_CATCH = 285,
     TOK_THROW = 286,
     TOK_GENERIC = 287,
     TOK_ABSTRACT = 288,
     TOK_DOTDOT = 289,
     TOK_LEFT_ARR = 290,
     TOK_RIGHT_ARR = 291,
     TOK_IF = 292,
     TOK_THEN = 293,
     TOK_ELSE = 294,
     TOK_WHILE = 295,
     TOK_DO = 296,
     TOK_FOR = 297,
     TOK_BREAK = 298,
     TOK_CONTINUE = 299,
     TOK_RETURN = 300,
     TOK_CONST = 301,
     TOK_LSH_EQ = 302,
     TOK_RSH_EQ = 303,
     TOK_LARROW = 304,
     TOK_AND_EQ = 305,
     TOK_OR_EQ = 306,
     TOK_XOR_EQ = 307,
     TOK_ADD_EQ = 308,
     TOK_SUB_EQ = 309,
     TOK_MULT_EQ = 310,
     TOK_DIV_EQ = 311,
     TOK_MOD_EQ = 312,
     OPASSIGN = 313,
     TOK_LOR = 314,
     TOK_LAND = 315,
     TOK_NE = 316,
     TOK_EQ = 317,
     TOK_LE = 318,
     TOK_GE = 319,
     TOK_RSH = 320,
     TOK_LSH = 321,
     POSTDEC = 322,
     POSTINC = 323,
     TOK_DEC = 324,
     TOK_INC = 325,
     UMINUS = 326,
     TOK_ARROW = 327
   };
#endif
#define TOK_STATIC 258
#define TOK_PRIVATE 259
#define TOK_TYPE 260
#define TOK_CLASS 261
#define TOK_SELF 262
#define TOK_ARRAY 263
#define TOK_OBJECT 264
#define TOK_STRING_DECL 265
#define TOK_REALT 266
#define TOK_INT 267
#define TOK_NUMBER 268
#define TOK_STRING 269
#define TOK_REAL 270
#define TOK_SWITCH 271
#define TOK_CASE 272
#define TOK_DEFAULT 273
#define TOK_IDENTIFIER 274
#define TOK_TYNAME 275
#define TOK_NEW 276
#define TOK_VOID 277
#define TOK_INHERIT 278
#define TOK_COLON_COLON 279
#define TOK_ENUM 280
#define TOK_AS 281
#define TOK_IMPORT 282
#define TOK_END 283
#define TOK_MODULE 284
#define TOK_CATCH 285
#define TOK_THROW 286
#define TOK_GENERIC 287
#define TOK_ABSTRACT 288
#define TOK_DOTDOT 289
#define TOK_LEFT_ARR 290
#define TOK_RIGHT_ARR 291
#define TOK_IF 292
#define TOK_THEN 293
#define TOK_ELSE 294
#define TOK_WHILE 295
#define TOK_DO 296
#define TOK_FOR 297
#define TOK_BREAK 298
#define TOK_CONTINUE 299
#define TOK_RETURN 300
#define TOK_CONST 301
#define TOK_LSH_EQ 302
#define TOK_RSH_EQ 303
#define TOK_LARROW 304
#define TOK_AND_EQ 305
#define TOK_OR_EQ 306
#define TOK_XOR_EQ 307
#define TOK_ADD_EQ 308
#define TOK_SUB_EQ 309
#define TOK_MULT_EQ 310
#define TOK_DIV_EQ 311
#define TOK_MOD_EQ 312
#define OPASSIGN 313
#define TOK_LOR 314
#define TOK_LAND 315
#define TOK_NE 316
#define TOK_EQ 317
#define TOK_LE 318
#define TOK_GE 319
#define TOK_RSH 320
#define TOK_LSH 321
#define POSTDEC 322
#define POSTINC 323
#define TOK_DEC 324
#define TOK_INC 325
#define UMINUS 326
#define TOK_ARROW 327




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 144 "mud.y"
typedef union YYSTYPE {
    Func *lnode;
    int number;
    char *string;
    Shared * shared;
    float real;
    lexar *lexstr;
    Val * val;
} YYSTYPE;
/* Line 1240 of yacc.c.  */
#line 191 "y.tab.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



