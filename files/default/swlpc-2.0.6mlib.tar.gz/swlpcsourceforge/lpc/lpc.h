

/*
** $Id: lpc.h,v 1.5 2003/05/28 08:20:06 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpc/lpc.h,v $
** $Revision: 1.5 $
** $Date: 2003/05/28 08:20:06 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _LPC_H
#define _LPC_H

#include <stdio.h>
#include "stack.h"
#include "lang.h"
#include "build.h"
#include "opcodes.h"
#include "class.h"

extern int LPC_parse_errors;

#define MAX_COMPILE_ERRORS 6

void 
    yyerror(const char *),
    yyerrord(const char *, int),
    yyerrorf(const char *, ...),
    LPC_clear_errors(),
    LPC_set_line(int),
    LPC_set_file(char * n),
    end_of_statement(),
    add_type_list(Shared * name, Class * code),
    free_global_tables(Class * code),
    free_locals(),
    init_globals(),
    make_global_tables(),
    print_type(int x)
    ;

int
    show_prog_status(),
    free_prog(Func * p),
        /* both shouldn't be here probably */
    LPC_errors(),
        /* return the number of LPC parse errors */
    add_argument(Shared * s, int type),
    add_global_variable(Shared * s, int type, Val * val),
    add_local_variable(Shared * s, int type),
    type_check(int a, int b, int c, char * where),
    constant_fold(int type),
    find_global_variable(Shared * s),
    find_local_block(Shared * s),
    find_local_variable(Shared * s),
    find_argument(Shared *s)
    ;

float 
    LPC_compile_av()
        /* returns the current compile speed average .. */
    ;

Shared **
    LPC_compile_errors()
        /* returns an array of compile errors (each allocated) */
    ;

Class
    * LPC_compile(Shared * name, FILE *, int enter)
        /*  compile given a name and file pointer */
    ;

Val 
    * find_constant(Shared * s);

struct field 
    * find_type(Shared * name),
    * find_type_info(unsigned int typestuff, Shared * fieldname)
    ;

struct keyword 
    * lookup_emulate(Shared * fun)
    ;

#endif


//find_type(Shared * name);
//find_type_info(unsigned int typestuff, Shared * fieldname);
//lookup_emulate(Shared * fun);
