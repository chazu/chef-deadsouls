

/*
** $Id: lang.h,v 1.1.1.1 2001/09/11 04:12:04 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpc/lang.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:04 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _LANG_H
#define _LANG_H

/* Some Compile definitions */

#define MAX_INHERIT  16

#define EMULATE_EFUN "RO/emulate"

#endif
