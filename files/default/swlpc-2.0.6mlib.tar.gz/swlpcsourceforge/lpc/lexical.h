
#ifndef _LEXICAL_H
#define _LEXICAL_H

struct keyword 
    * lookup_predef(char *s),
    * lookup_define(char *s)
    ;

int lookup_warnword(char *s),
    yylex()
    ;

char * predef_by_num(int op) 
    ;

void 
    refill(),
    start_new_file(FILE *f)
    ;

#endif
