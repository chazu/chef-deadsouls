/*
 * Written by Lennart Augustsson
 */
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "lpc.h"
#include "opcodes.h"
#include "lexer.h"
#include "rhash.h"
#include "function.h"

#ifdef GO32
#include "y_tab.h"
#else
#include "y.tab.h"
#endif

#if defined(__GNUC__) && !defined(lint)
#define INLINE 	 	inline 
#else
#define INLINE
#endif

#define isalunum(c) (isalnum(c) || (c) == '_')

int current_line;
int total_lines;	/* Used to compute average compiled lines/s */
char * current_file = NULL;

extern Func * CPD;
extern char *argument_name;
extern char *lex_Cstr_copy(char * s);

static int number (char *), ident (char *), string (char *);
static void handle_define (char *);
static void free_defines (void), add_define (char *, int, char *);
static int expand_define (void);
static void add_input (char *);
static void myungetc (int);
static int lookup_resword (char *);
static int numreal(char *);
static int numhex(char *);
static void skip_comment();
static void skip_ccomment();
int lookup_warnword (char *);
static FILE *yyin;
static int lex_fatal;

extern char *local_names[];
extern int current_number_of_locals;

void yyerror(), error(); 

#define MAXLINE 1024
char yytext[MAXLINE];
static int slast, lastchar;

struct defn {
    struct defn *next;
    char *name;
    int undef;
    char *exps;
    int nargs;
};
struct defn *lookup_define();

static struct ifstate {
    struct ifstate *next;
    int state;
} *iftop = 0;
#define EXPECT_ELSE 1
#define EXPECT_ENDIF 2

static struct incstate {
    struct incstate *next;
    FILE *yyin;
    int line;
    char *file;
    int slast, lastchar;
} *inctop = 0;

#define DEFMAX 4096
static char defbuf[DEFMAX];
static int nbuf;
static char *outp;

static INLINE void
myungetc(int c)
{
    *--outp = c;
    nbuf++;
}

static void inc_linemap()
{
    int off;

    if (CPD != NULL)
    {
        off = current_line - CPD->line - 1;
        while (off >= CPD->num_lines)
        {
            CPD->num_lines *= 2;
            CPD->linemap = (unsigned short *)
                        realloc(CPD->linemap, CPD->num_lines * sizeof(short));
        }
        if (off >= 0 && off <= CPD->num_lines)  
            CPD->linemap[off] = CPD->current_I;
    }
}

static INLINE int
mygetc()
{
    int c;

    if (nbuf) {
	nbuf--;
	c = *outp++;
    } else {
	    c = getc(yyin);   
	    if (c == '\n') 
        {
	        current_line++;
	        total_lines++;
            inc_linemap();
	    }
    }
    lastchar = slast;
    slast = c;
/*fprintf(stderr, "c='%c'", c);*/
    return c;
}

static INLINE int
gobble(int c)
{
    int d;
    d = mygetc();
    if (c == d)
	return 1;
    *--outp = d;
    nbuf++;
    return 0;
}

static INLINE int
cmygetc()
{
    int c;

    for(;;) {
	c = mygetc();
	if (c == '/') {
	    if (gobble('*')) skip_comment();
	    else if (gobble('/')) skip_ccomment();
		else return c;
	} else
	    return c;
    }
}

static void
lexerror(char *s)
{
    yyerror(s);
    lex_fatal++;
}

static int
skip_to(char *token, char *atoken)
{
    char b[20], *p;
    int c;
    int nest;

    for(nest = 0;;) {
	c = mygetc();
	if (c == '#') {
	    do {
		c = mygetc();
	    } while(isspace(c));
	    for(p = b; c != '\n' && c != EOF; ) {
		if (p < b+sizeof b-1)
		    *p++ = c;
		c = mygetc();
	    }
	    *p++ = 0;
	    for(p = b; *p && !isspace(*p); p++)
		;
	    *p = 0;
/*fprintf(stderr, "skip checks %s\n", b);*/
	    if (nest > 0) {
		if (strcmp(b, "endif") == 0)
		    nest--;
	    } else if (strcmp(b, "if") == 0 || strcmp(b, "ifdef") == 0 ||
		       strcmp(b, "ifndef") == 0) {
		nest++;
	    } else {
		if (strcmp(b, token) == 0)
		    return 1;
		else if (atoken && strcmp(b, atoken) == 0)
		    return 0;
	    }
	} else {
/*fprintf(stderr, "skipping (%d) %c", c, c);*/
            while (c != '\n' && c != EOF) {
		c = mygetc();
/*fprintf(stderr, "%c", c);*/
	    } 
	    if (c == EOF) {
		lexerror("Unexpected end of file while skipping");
		return 1;
	    }
	}
/*	if (inctop == 0)
	    store_line_number_info();*/
    }
}

static void
handle_cond(int c)
{
    struct ifstate *p;

/*fprintf(stderr, "cond %d\n", c);*/
    if (c || skip_to("else", "endif")) {
	p = (struct ifstate *)malloc(sizeof(struct ifstate));
	p->next = iftop;
	iftop = p;
	p->state = c ? EXPECT_ELSE : EXPECT_ENDIF;
    }
}

static FILE *
inc_open(char *buf, char *name, int stdplace)
{
    FILE *f;
    char *p;
    char * l;

    if (*name == '/') {
	strcpy(buf, name+1);
	return fopen(buf, "r");
    }
    if (!stdplace) { /* filename in "" - check our dirs first */
	l = current_file + strlen(current_file); /* get the 0 */
	while (l) {
	    char c = *l;
	    *l = 0;
            if ( (p = strrchr(current_file, '/')) ) {
	        *p = 0;
	        sprintf(buf, "%s/%s", current_file, name);
	        *p = '/';
		}
	    *l = c;
	    l = p;
    	    if ((f = fopen(buf, "r")) != NULL) return f;
	    }
        }

/* not in our directory tree - look in standard places */

    sprintf(buf, "../secure/%s", name);
    if ((f = fopen(buf, "r")) != NULL) return f;
    sprintf(buf, "secure/%s", name);
    if ((f = fopen(buf, "r")) != NULL) return f;
    sprintf(buf, "RO/%s", name);
    if ((f = fopen(buf, "r")) != NULL) return f;
    sprintf(buf, "include/%s", name);
#if 0
    if ((f = fopen(buf, "r")) != NULL) return f;
    sprintf(buf, "std/%s", name);
#endif
    return fopen(buf, "r");
}

static void
handle_include(char *name)
{
    char *p;
    char buf[1024];
    FILE *f;
    struct incstate *is;
    int delim;

/*fprintf(stderr, "handle include '%s'\n", name);*/
    if (nbuf) {
	lexerror("Internal preprocessor error");
	return;
    }
    if (*name != '"' && *name != '<') {
	struct defn *d;
	if ((d = lookup_define(name)) && d->nargs == -1) {
	    char *q;
	    q = d->exps;
	    while(isspace(*q))
		q++;
	    handle_include(q);
	} else {
	    yyerror("Missing leading \" or < in #include");
	}
	return;
    }
    delim = *name++ == '"' ? '"' : '>';
    for(p = name; *p && *p != delim; p++)
	;
    if (!*p) {
	yyerror("Missing trailing \" or > in #include");
	return;
    }
    if (strlen(name) > 900) {
	yyerror("Include name too long.");
	return;
    }
    *p = 0;
    sprintf(buf, "room/%s", name); /* redundant? */
    if ((f = inc_open(buf, name, delim == '>')) != NULL) {
	is = (struct incstate *)malloc(sizeof(struct incstate));
	is->yyin = yyin;
	is->line = current_line;
	is->file = str_copy(current_file);
	is->slast = slast;
	is->lastchar = lastchar;
	is->next = inctop;
	inctop = is;
	current_line = 1;
    LPC_set_file(buf);
	//current_file = malloc(strlen(buf)+1);
	//strcpy(current_file, buf);
	slast = lastchar = '\n';
	yyin = f;
/*fprintf(stderr, "pushed to %s\n", buf);*/
    } else {
	sprintf(buf, "Cannot #include %s\n", name);
	yyerror(buf);
    }
}

static void skip_to_eol()
{
    int c;

    while((c = mygetc()) != '\n') 
    {
        if (c == EOF) 
        {
            lexerror("End of file in a comment");
            return;
        }
    }
}

static void skip_comment()
{
    int c;

    for(;;) {
	while((c = mygetc()) != '*') {
	    if (c == EOF) {
	        lexerror("End of file in a comment");
		return;
	    }
	    if (c == '\n') {
/*		if (inctop == 0)
		    store_line_number_info(); */
	    }
	}
	do {
	    if ((c = mygetc()) == '/')
		return;
	} while(c == '*');
    }
}

static void skip_ccomment()
{
    int c;

	while((c = mygetc()))
    {
        if (c == '\n') break;
	    if (c == EOF)  break;
	}
}

#define TRY(c, t) if (gobble(c)) return t

static void
deltrail(char *sp)
{
    char *p;
    p = sp;
    if (!*p) {
	lexerror("Illegal # command");
    } else {
	while(*p && !isspace(*p))
	    p++;
	*p = 0;
    }
}

#define SHOWC
/* #define SHOWC putchar(c); */

#define SAVEC \
    if (yyp < yytext+MAXLINE-5) {\
       *yyp++ = c;\
       SHOWC \
    } else {\
       lexerror("Line too long (SAVEC)");\
       break;\
    }

static void deallocate_local() {
    while (inctop != NULL) {
	struct incstate *p;

	p = inctop;
	fclose(yyin);
	free(p->file);
	yyin = p->yyin;
	inctop = p->next;
	free((char *)p);
    }
    while(iftop != NULL) {
	struct ifstate *p;
	
	p = iftop;
	iftop = p->next;
	free((char *)p);
    }
}

static int
yylex1()
{
  register int c;
  register char *yyp;

  for(;;) {
    if (lex_fatal) {
/*fprintf(stderr, "lexfatal set\n");*/
	while (inctop) {
	    struct incstate *p;
	    p = inctop;
	    fclose(yyin);
        LPC_set_file(p->file);
        free(p->file);
	    yyin = p->yyin;
	    inctop = p->next;
	    free((char *)p);
	}
	while(iftop) {
	    struct ifstate *p;
	    
	    p = iftop;
	    iftop = p->next;
	    free((char *)p);
	}
	return -1;
    }
    switch(c = mygetc()) {
    case EOF:
	if (inctop) {
	    struct incstate *p;
	    p = inctop;
	    fclose(yyin);
/*fprintf(stderr, "popping to %s\n", p->file);*/
        LPC_set_file(p->file);
	    current_line = p->line;
	    yyin = p->yyin;
	    slast = p->slast;
	    lastchar = p->lastchar;
	    inctop = p->next;
        free(p->file);
	    free((char *)p);
	    break;
	}
	if (iftop) {
	    struct ifstate *p = iftop;
	    yyerror(p->state == EXPECT_ENDIF ? "Missing #endif" : "Missing #else");
	    while(iftop) {
		p = iftop;
		iftop = p->next;
		free((char *)p);
	    }
	}
	return -1;
    case '\n':
	{
/*	    if (inctop == 0)
		store_line_number_info(); */
	}
    case ' ':
    case '\t':
    case '\f':
    case '\v':
	break;
    case '+':
	TRY('+', TOK_INC);
	TRY('=', TOK_ADD_EQ);
	return c;
    case '-':
	TRY('>', TOK_ARROW);
	TRY('-', TOK_DEC);
	TRY('=', TOK_SUB_EQ);
	return c;
    case '&':
	TRY('&', TOK_LAND);
	TRY('=', TOK_AND_EQ);
	return c;
    case '|':
	TRY('|', TOK_LOR);
	TRY('=', TOK_OR_EQ);
	return c;
    case '^':
	TRY('=', TOK_XOR_EQ);
	return c;
    case '<':
	TRY('-', TOK_LARROW);
	if (gobble('<')) {
	    TRY('=', TOK_LSH_EQ);
	    return TOK_LSH;
	}
	TRY('=', TOK_LE);
	return c;
    case '>':
	if (gobble('>')) {
	    TRY('=', TOK_RSH_EQ);
	    return TOK_RSH;
	}
	TRY('=', TOK_GE);
	return c;
    case '*':
	TRY('=', TOK_MULT_EQ);
	return c;
    case '%':
	TRY('=', TOK_MOD_EQ);
	return c;
    case '/':
	if (gobble('*')) {
	    skip_comment();
	    break;
        }
    if (gobble('/')) {
	    skip_ccomment();
	    break;
    }
	TRY('=', TOK_DIV_EQ);
	return c;
    case '=':
	TRY('=', TOK_EQ);
	return c;
    case '.':
	TRY('.', TOK_DOTDOT);
	return c;
    case '(':
#if 0
    TRY('{', TOK_LEFT_ARR);
	return c;
#endif
    case '}':
#if 0
    TRY(')', TOK_RIGHT_ARR);
	return c;
#endif
    case ';':
    case ')':
    case ',':
    case '{':
    case '~':
    case '[':
    case ']':
    case '?':
    case '@':
	return c;
    case '!':
	TRY('=', TOK_NE);
	return '!';
    case ':':
	TRY(':', TOK_COLON_COLON);
	return ':';
    case '#':
	if (lastchar == '\n') 
        {
	    char *sp = 0;
	    yyp = yytext;
	    do {
		c = mygetc();
	    } while (isspace(c));
	    for(;;) {
		if (!sp && isspace(c))
		    sp = yyp;
		if (c == '\n' || c == EOF)
		    break;
		SAVEC;
		c = mygetc();
	    }
	    if (sp) {
		*sp++ = 0;
		while(isspace(*sp))
		    sp++;
	    } else {
		sp = yyp;
	    }
	    *yyp = 0;
	    if (strcmp("define", yytext) == 0) {
		handle_define(sp);
	    } else if (strcmp("if", yytext) == 0) {
		if (isdigit(*sp)) {
		    char *p;
		    long l;
		    l = strtol(sp, &p, 10);
		    while(isspace(*p))
			p++;
		    if (*p)
			yyerror("Condition too complex in #if");
		    else
			handle_cond((int)l);
		} else if (isalunum(*sp)) {
		    char *p = sp;
		    while(isalunum(*p))
			p++;
		    if (*p) {
			*p++ = 0;
			while(isspace(*p))
			    p++;
		    }
		    if (*p)
			yyerror("Condition too complex in #if");
		    else {
			struct defn *d;
			d = lookup_define(sp);
			if (d) {
			    handle_cond(atoi(d->exps));/* a hack! */
			} else {
			    handle_cond(0);
			}
		    }
		} else
		    yyerror("Condition too complex in #if");
	    } else if (strcmp("ifdef", yytext) == 0) {
		deltrail(sp);
		handle_cond(lookup_define(sp) != 0);
	    } else if (strcmp("ifndef", yytext) == 0) {
		deltrail(sp);
		handle_cond(lookup_define(sp) == 0);
	    } else if (strcmp("else", yytext) == 0) {
		if (iftop && iftop->state == EXPECT_ELSE) {
		    struct ifstate *p = iftop;

/*fprintf(stderr, "found else\n");*/
		    iftop = p->next;
		    free((char *)p);
		    skip_to("endif", (char *)0);
		} else {
		    yyerror("Unexpected #else");
		}
	    } else if (strcmp("endif", yytext) == 0) {
		if (iftop && (iftop->state == EXPECT_ENDIF ||
			      iftop->state == EXPECT_ELSE)) {
		    struct ifstate *p = iftop;

/*fprintf(stderr, "found endif\n");*/
		    iftop = p->next;
		    free((char *)p);
		} else {
		    yyerror("Unexpected #endif");
		}
	    } 
            else if (strcmp("undef", yytext) == 0)
            {
		struct defn *d;

		deltrail(sp);
		if ( (d = lookup_define(sp)) )
		    d->undef++;
	    } 
            else if (strcmp("echo", yytext) == 0) 
            {
		fprintf(stderr, "%s\n", sp);
	    } 
        else if (strcmp("include", yytext) == 0) 
        {
/*fprintf(stderr, "including %s\n", sp);		*/
                handle_include(sp);
	    } 
        else 
        {
		/* yyerror("Unrecognised # directive"); */
		skip_to_eol();
	    }
	    myungetc('\n');
	    break;
	} 
        else
	    goto badlex;
    case '\'':
        /* FIX: should handle \r, \n, \xHH, etc - same as strings */
        yylval.number = mygetc();
	    if (!gobble('\'')) yyerror("Illegal character constant");
	    return TOK_NUMBER;
    case '"':
	yyp = yytext;
	*yyp++ = c;
	for(;;) {
	    c = mygetc();
	    if (c == EOF) {
 		lexerror("End of file in string");
		break;
	    } else if (c == '\n') {
 		lexerror("Newline in string");
		break;
	    }
	    SAVEC;
	    if (c == '"')
		break;
	    if (c == '\\')
		*yyp++ = mygetc();
	}
	*yyp = 0;
	return string(yytext);

    case '0': case '1':case '2':case '3':case '4':
    case '5':case '6':case '7':case '8':case '9':
	{ char wasfloat = 0, hexa = 0;
	yyp = yytext;
	*yyp++ = c;
	if (c == '0') hexa = 1;	/* possibly hexadecimal */
	c = mygetc();
	if (hexa && (c == 'x')) {
		SAVEC;
		for(;;) {
		    	c = mygetc();
	    		if (!isxdigit(c)) break;
	    		SAVEC;
		}
		myungetc(c);
		*yyp = 0;
		return numhex(yytext);
	}
	for(;;) {
	    if (!isdigit(c)) break;
	    SAVEC;
	    c = mygetc();
	}
	if (c == '.') {
	    char d;
	    d = mygetc();
	    if (d < '0' || d > '9') {
		myungetc(d);
		}
	    else {
	        SAVEC;
		c = d;
		SAVEC;
	        wasfloat = 1;
	        for(;;) {
	            c = mygetc();
	            if (!isdigit(c))
		        break;
	            SAVEC;
	            }
		}
	    }
	myungetc(c);
	*yyp = 0;
	if (!wasfloat)
	    return number(yytext);
	else
	    return numreal(yytext);
	}
    default:
	if (isalpha(c) || c == '_') {
	    int r;

	    yyp = yytext;
	    *yyp++ = c;
	    for(;;) {
		c = mygetc();
		if (!isalunum(c))
		    break;
		SAVEC;
	    }
	    *yyp = 0;

	    myungetc(c);
	    if (!expand_define()) {
		r = lookup_resword(yytext);
		if (r >= 0) {
		    return r;
		} else
		    return ident(yytext);
	    }
	    break;
        }
	goto badlex;
    }
  }
 badlex:
  { char buff[100]; sprintf(buff, "Illegal character (hex %02x) '%c'", c, c);
    yyerror(buff); return ' '; }
}

int
yylex()
{
    int r;

    yytext[0] = 0;
    r = yylex1();
/*    fprintf(stderr, "lex=%d(%s) ", r, yytext);*/
    return r;
}

extern YYSTYPE yylval;

static int ident(char *str)
{
    yylval.string = lex_Cstr_copy(str);
#if 1
    if (lookup_warnword(str) >= 0) {
	    char ebuf[1000];
	    sprintf(ebuf, "Warning: word '%s' is soon to be a reserved word.", str);
	    yyerrorf("%s (%d): %s\n", current_file, current_line, ebuf);
	    }
#endif
    return TOK_IDENTIFIER;
}

static int string(char *str)
{
    lexar *l;
    char *p;
    int x, t, v = 0;

    l = (lexar *) lex_str_copy(str);
    yylval.lexstr = l;
    p = l->s;
    for (str++; str[1] != '\0'; str++, p++) 
    {
	if (str[0] == '\\' && str[1] == 'n') {
	    *p = '\n';
	    str++;
	} else if (str[0] == '\\' && str[1] == 't') {
	    *p = '\t';
	    str++;
	} else if (str[0] == '\\' && str[1] == 'r') {
	    *p = '\r';
	    str++;
	} else if (str[0] == '\\' && str[1] == 'b') {
	    *p = '\b';
	    str++;
	} else if (str[0] == '\\' && str[1] == 'f') {
	    *p = '\f';
	    str++;
	} else if (str[0] == '\\' && str[1] == 'x') {
        t = 0;
        str++;
        for (x = 0; (x < 2) && str[1]; x++)
        {
            if (str[1] >= '0' && str[1] <= '9') v = str[1] - '0';
            else if (str[1] >= 'A' && str[1] <= 'F') v = str[1] - 'A';
            else if (str[1] >= 'a' && str[1] <= 'f') v = str[1] - 'a';
            else if (x == 0) 
                yyerror("Illegal bit representation (must be hex)");
            else break;
            str++;
            t = t*16 + v;
        }
        *p = t;
	} else if (str[0] == '\\' && str[1] == '"') {	/* LA */
	    *p = '"';					/* LA */
	    str++;					/* LA */
	    if (!str[1]) {
		yyerror("Unterminated string");
		break;
	    }
	} else if (str[0] == '\\') {
	    *p = str[1];
	    str++;
	} else
	    *p = *str;
    }
/*    *p = '\0'; */
    l->length =(int)p - (int)l->s;
    return TOK_STRING;
}

static int numhex(char * str)
{
    int r = 0;
    str++; str++;	/* skip 0x */	
    while (*str) {
	r = r << 4;
	if (isdigit(*str)) r = r + (*str - '0');
	else if (islower(*str)) r = r + (*str - 'a' + 10);
	else r = r + (*str - 'A' + 10);
	str++;
    }
    yylval.number = r;
    return TOK_NUMBER;
}

static int number(char *str)
{
    int i;
    i = atoi(str);
    yylval.number = i;
    return TOK_NUMBER;
}

static int numreal(char *str)
{
    float i;

    i = atof(str);
    yylval.real = i;
    return TOK_REAL;
}

void start_new_file(FILE *f)
{
#if 0
    extern int yyprevious;	/* KLUDGE! */
    NLSTATE;
    yysptr = yysbuf;
#endif
    free_defines();
    deallocate_local();
    yyin = f;
    slast = '\n';
    lastchar = '\n';
    current_line = 1;
    lex_fatal = 0;
    nbuf = 0;
    outp = defbuf+DEFMAX;
}

/*
 * The number of arguments stated below, are used by the compiler.
 * If min == max, then no information has to be coded about the
 * actual number of arguments. Otherwise, the actual number of arguments
 * will be stored in the byte after the instruction.
 * A maximum value of -1 means unlimited maximum value.
 *
 * If an argument has type 0 (T_INVALID) specified, then no checks will
 * be done at run time.
 */
struct predef {
    char *word;
    short token;
    int params;
};

struct predef predefs[] = { 
{ "allocate",		F_ALLOCATE, 1 },
{ "arrayp",		F_POINTERP, 1 },
{ "atoi",		F_ATOI,	1 },
{ "ator",		F_ATOR, 1 },
{ "call_other",		F_CALL_OTHER, -1 },	/* -1 is varargs */
{ "call_out",		F_CALL_OUT, -1 },
{ "caller", 		F_CALLER, 0 },
{ "capitalize",		F_CAPITALIZE, 1 },
{ "clone_object",	F_CLONE_OBJECT, 2 },
{ "contents",		F_CONTENTS, 1 },
{ "cp",			F_CP, 2 },
{ "creator",		F_CREATOR, 1 },
{ "destruct",		F_DESTRUCT, 1 },
{ "enable_commands",	F_ENABLE_COMMANDS, 0 },
{ "environment",	F_ENVIRONMENT, 1 },
{ "explode",		F_EXPLODE, 2 },
{ "ext_c_call",		F_EXT_C_CALL, -1 },
{ "external_program",	F_EXTERNAL_PROGRAM, 6 },
{ "file_name",		F_FILE_NAME, 1 },
{ "file_size",		F_FILE_SIZE, 1 },
{ "find_call_out",	F_FIND_CALL_OUT, 1 },
{ "find_object",	F_FIND_OBJECT, 1 },
{ "grab_file",		F_GRAB_FILE, 3 },
{ "hash_value",		F_HASH_VALUE, 1 },
{ "implode",		F_IMPLODE, 2 },
{ "index", 		F_INDEX, 4 },
{ "int2real",		F_INT2REAL, 1 },
{ "intp",		F_INTP, 1 },
{ "is_cloned",		F_IS_CLONED, 1 },
{ "living",		F_LIVING, 1 },
{ "load_shared_object", F_LOAD_SHARED_OBJECT, 1 },
{ "lower_case",		F_LOWER_CASE, 1 },
{ "ls",			F_LS, 1 },
{ "mkdir",		F_MKDIR, 1 },
{ "move_object",	F_MOVE_OBJECT, 2 },
{ "objectp",		F_OBJECTP, 1 },
{ "out_binary", 	F_OUT_BINARY, 1 },
{ "out_to_term", 	F_OUT_TO_TERM, 1 },
{ "pointerp",		F_POINTERP, 1 },
{ "present",		F_PRESENT, 2 },
{ "previous_object",	F_PREVIOUS_OBJECT, 0 },
{ "query_host_name",	F_QUERY_HOST_NAME, 0 },
{ "query_ip_number",	F_QUERY_IP_NUMBER, 1 },
{ "query_snoop",	F_QUERY_SNOOP, 1 },
#ifdef SECURE
{ "query_su_level",	F_QUERY_LEVEL, 1 },
{ "query_su_name",	F_QUERY_SU_NAME, 1 },
{ "query_valid_file",	F_QUERY_FILE, 3 },
#endif
{ "random",		F_RANDOM, 1 },
{ "real2int",		F_REAL2INT, 1 },
{ "realp",		F_REALP, 1 },
{ "remove_call_out",	F_REMOVE_CALL_OUT, 1 },
{ "rename",		F_RENAME, 2 },
{ "rename_object",	F_RENAME_OBJECT, 2 },
{ "restore_object",	F_RESTORE_OBJECT, 2 },
{ "rm",			F_RM, 1 },
{ "rmdir",		F_RMDIR, 1 },
{ "save_object",	F_SAVE_OBJECT, 2 },
{ "send_dgram", 	F_SENDTO, 6 },
//{ "set_ip_number",	F_SET_IP_NUMBER, 2 },
#ifdef SECURE
{ "set_uid_file",	F_SUID_FILE, 2 },
{ "set_uid_me",		F_SETUID, 3 },
#endif
{ "shutdown",		F_SHUTDOWN, 0 },
{ "sizeof",		F_SIZEOF, 1 },
{ "snoop",		F_SNOOP, 1 },
{ "stringp",		F_STRINGP, 1 },
{ "strlen",		F_STRLEN, 1 },
{ "switch_interactive",	F_SWITCH_INTERACTIVE, 1 },
{ "this_object",	F_THIS_OBJECT, 0 },
{ "throw",		F_THROW, 1 },
{ "time",		F_TIME, 0 },
{ "toggle_echo", 	F_TOGGLE_ECHO, 0 },
{ "unload_shared_object", F_UNLOAD_SHARED_OBJECT, 1 },
{ "users",		F_USERS, 0 },
{ "write_file",		F_WRITE_FILE, 2 },
};
#define NELEM(a) (sizeof (a) / sizeof (a)[0])

static struct predef reswords[] = {
{ "array",		TOK_ARRAY, },
{ "break",		TOK_BREAK, },
{ "case",		TOK_CASE, },
{ "catch",		TOK_CATCH, },
{ "class",		TOK_CLASS, }, 
{ "const",		TOK_CONST, },
{ "continue",		TOK_CONTINUE, },
{ "create",		TOK_NEW },
{ "default", 		TOK_DEFAULT },
{ "do",			TOK_DO, },
{ "else",		TOK_ELSE, },
{ "for",		TOK_FOR, },
{ "if",			TOK_IF, },
{ "import",		TOK_IMPORT, },
{ "inherit",    TOK_INHERIT, },
{ "int",		TOK_INT, },
{ "object",		TOK_OBJECT, },
{ "private",	TOK_PRIVATE, },
{ "real",		TOK_REALT, },
{ "return",		TOK_RETURN, },
{ "self",		TOK_SELF, },
{ "static",		TOK_STATIC, },
{ "string",		TOK_STRING_DECL, },
{ "switch",		TOK_SWITCH, },
{ "throw",		TOK_THROW, },
{ "void",		TOK_VOID, },
{ "while",		TOK_WHILE, },
};

/*
 * warnwords - tokens are actually initialised to 0 at
 * start of parsing a file, and incremented when found (so
 * second and later occurrences aren't marked)
 */

static struct predef warnwords[] = {
{ "abstract",		TOK_ABSTRACT, }, 
{ "enum", 		    TOK_ENUM, },
{ "generic", 		TOK_GENERIC, },
{ "module", 		TOK_MODULE, },
{ "typedef", 		TOK_TYPE, }
};

static int
lookupword(char *s, struct predef words[], int h)
{
    int i, l, r;

    l = 0;
    for(;;) {
      i = (l+h)/2;
      r = strcmp(s, words[i].word);
      if (r == 0)
          return words[i].token;
      else if (l == i)
          return -1;
      else if (r < 0)
          h = i;
      else
          l = i;
    }
}

static int lookup_resword(char *s)
{
    return lookupword(s, reswords, NELEM(reswords));
}

char * predef_by_num(int op) 
{
    int x = NELEM(predefs);
    while (x-- > 0)
        if (predefs[x].token == op)
            return predefs[x].word;
    fatal("Looked up invalid predef opcode - %d\n", op);
    return NULL;
}

struct predef * lookup_predef(char *s)
{
    int i, l, r, h = NELEM(predefs);
    char * ts;

    if (s[0] == ':' && s[1] == ':') ts = &(s[2]);	/* :: hack for driver */
    else ts = s;

    l = 0;
    for(;;) {
      i = (l+h)/2;
      r = strcmp(ts, predefs[i].word);
      if (r == 0)
          return &(predefs[i]);
      else if (l == i)
          return 0;
      else if (r < 0)
          h = i;
      else
          l = i;
    }
}

int lookup_warnword(char *s)
{
    return lookupword(s, warnwords, NELEM(warnwords));
}

#define NSIZE 256 
/* #define NSIZE 1024  */
#define NARGS 25
#define MLEN 4096
#define MARKS '@'

#define SKIPWHITE while(isspace(*p)) p++

void refill()
{
    char *p;
    int c;

    p = yytext;
    do {
	c = cmygetc();
	if (p < yytext+MAXLINE-5)
	    *p++ = c;
	else {
	    lexerror("Line too long (refill)");
	    break;
	}
    } while(c != '\n' && c != EOF);
    p[-1] = ' ';
    *p = 0;
/*    if (inctop == 0)
	store_line_number_info(); */
}

#define GETALPHA(_xyz) \
    while(isalunum(*p)) {\
	*q = *p++;\
	if (q < _xyz+NSIZE-1)\
	    q++;\
	else {\
	    lexerror("Name too long (GETALPHA)");\
	    return;\
	}\
    }\
    *q++ = 0

#if 0
/* for debugging */
getalpha(char * namebuf, char * p, char * q)
{
    while(isalunum(*p)) {
	*q = *p++;
	if (q < namebuf+NSIZE-1)
	    q++;
	else {
	    lexerror("Name too long (GETALPHA)");
	    return;
	}
    }
    *q++ = 0; 
} 
#endif


static char namebuf[NSIZE];
static char args[NARGS][NSIZE];
static char mtext[MLEN];

static void
handle_define(char *yyt)
{
    char *p, *q;

    p = yyt;
    strcat(p, " ");
    q = namebuf;
    GETALPHA(namebuf);
    if (*p == '(') {		/* if "function macro" */
	int arg;
	int inid;
	char *ids = NULL;

	p++;			/* skip '(' */
	SKIPWHITE;
	if (*p == ')') {
	    arg = 0;
	} else {
	    for(arg = 0; arg < NARGS; ) {
		q = args[arg];
		GETALPHA(args[arg]);
		arg++;
		SKIPWHITE;
		if (*p == ')')
		    break;
		if (*p++ != ',') {
		    yyerror("Missing ',' in #define parameter list");
		    return;
		}
		SKIPWHITE;
	    }
	    if (arg == NARGS) {
		lexerror("Too many macro arguments");
		return;
	    }
	}
	p++;			/* skip ')' */
	for(inid = 0, q = mtext; *p; ) {
	    if (isalunum(*p)) {
		if (!inid) {
		    inid++;
		    ids = p;
		}
	    } else {
		if (inid) {
		    int idlen = p - ids;
		    int n, l;
		    for(n = 0; n < arg; n++) {
			l = strlen(args[n]);
			if (l == idlen && strncmp(args[n], ids, l) == 0) {
			    q -= idlen;
			    *q++ = MARKS;
			    *q++ = n+MARKS+1;
			    break;
			}
		    }
		    inid = 0;
		}
	    }
	    *q = *p;
	    if (*p++ == MARKS)
		*++q = MARKS;
	    if (q < mtext+MLEN-2)
		q++;
	    else {
		lexerror("Macro text too long");
		return;
	    }
	    if (!*p && p[-2] == '\\') {
		q -= 2;
		refill();
		p = yytext;
	    }
	}
	*--q = 0;
	add_define(namebuf, arg, mtext);
    } else {
	for(q = mtext; *p; ) {
	    *q = *p++;
	    if (q < mtext+MLEN-2)
		q++;
	    else {
		lexerror("Macro text too long");
		return;
	    }
	    if (!*p && p[-2] == '\\') {
		q -= 2;
		refill();
		p = yytext;
	    }
	}
	*--q = 0;
	add_define(namebuf, -1, mtext);
    }
    return;
}

static void
add_input(char *p)
{
    int l = strlen(p);

/*if (l > 2)
fprintf(stderr, "add '%s'\n", p);*/
    if (nbuf+l >= DEFMAX-10) {
	lexerror("Macro expansion buffer overflow");
	return;
    }
    outp -= l;
    nbuf += l;
    strncpy(outp, p, l);
}

#define DEFHASH 33
struct defn *defns[DEFHASH];
#define EXPANDMAX 10000
static int nexpands;

#if 1
#define defhash(s) hashstr(s, MAXH, DEFHASH)
#else
static int
defhash(char *p)
{
    int r;

    for(r = 0; *p; p++)
	r += *p;
    return r % DEFHASH;
}
#endif

static void
add_define(char * name, int nargs, char *exps)
{
    struct defn *p;
    int h;

    if ( (p = lookup_define(name)) ) {
	if (nargs != p->nargs || strcmp(exps, p->exps) != 0) {
	    char buf[200];
	    sprintf(buf, "Redefinition of #define %s", name);
	    yyerror(buf);
	}
	return;
    }
    p = (struct defn *)malloc(sizeof(struct defn));
    p->name = malloc(strlen(name)+1);
    strcpy(p->name, name);
    p->undef = 0;
    p->nargs = nargs;
    p->exps = malloc(strlen(exps)+1);
    strcpy(p->exps, exps);
    h = defhash(name);
    p->next = defns[h];
    defns[h] = p;
/*fprintf(stderr, "define '%s' %d '%s'\n", name, nargs, exps);*/
}

static void
free_defines()
{
    struct defn *p, *q;
    int i;

    for(i = 0; i < DEFHASH; i++) {
	for(p = defns[i]; p != NULL; p = q) {
	    q = p->next;
	    free(p->name);
	    free(p->exps);
	    free((char *)p);
	}
	defns[i] = 0;
    }
    nexpands = 0;
}

struct defn *
lookup_define(char *s)
{
    struct defn *p;
    int h;

    h = defhash(s);
    for(p = defns[h]; p != NULL; p = p->next)
	if (!p->undef && strcmp(s, p->name) == 0)
	    return p;
    return 0;
}

#define SKIPW \
        do {\
	    c = cmygetc();\
	} while(isspace(c));


/* Check if yytext is a macro and expand if it is. */
static int
expand_define()
{
    struct defn *p;
    char expbuf[DEFMAX];
    char *args[NARGS];
    char buf[DEFMAX];
    char *q, *e, *b;

    if (nexpands > EXPANDMAX) {
	lexerror("Too many macro expansions");
	return 0;
    }
    p = lookup_define(yytext);
    if (p == NULL) {
	return 0;
    }
    if (p->nargs == -1) {
	add_input(p->exps);
    } else {
	int c, parcnt = 0, dquote = 0, squote = 0;
	int n;
	SKIPW;
	if (c != '(') {
	    yyerror("Missing '(' in macro call");
	    return 0;
	}
	SKIPW;
	if (c == ')')
	    n = 0;
	else {
	    q = expbuf;
	    args[0] = q;
	    for(n = 0; n < NARGS; ) {
		switch(c) {
		case '"': if (!squote) dquote ^= 1; break;
		case '\'': if (!dquote) squote ^= 1; break;
		case '(': if (!squote && !dquote) parcnt++; break;
		case ')': if (!squote && !dquote) parcnt--; break;
		case '\\': if (squote || dquote) { *q++ = c; c = mygetc();} break;
		}
		if (c == ',' && !parcnt && !dquote && !squote) {
		    *q++ = 0;
		    args[++n] = q;
		} else if (parcnt < 0) {
		    *q++ = 0;
		    n++;
		    break;
		} else {
		    if (c == EOF) {
			lexerror("Unexpected end of file");
			return 0;
		    }
		    if (q >= expbuf + DEFMAX - 5) {
			lexerror("Macro argument overflow");
			return 0;
		    } else {
			*q++ = c;
		    }
		}
		if (!squote && ! dquote)
		    c = cmygetc();
		else
		    c = mygetc();
	    }
	    if (n == NARGS) {
		lexerror("Maximum macro argument count exceeded");
		return 0;
	    }
	}
	if (n != p->nargs) {
	    yyerror("Wrong number of macro arguments");
	    return 0;
	}
	/* Do expansion */
	b = buf;
	e = p->exps;
	while(*e) {
	    if (*e == MARKS) {
		if (*++e == MARKS)
		    *b++ = *e++;
		else {
		    for(q = args[*e++ - MARKS - 1]; *q; ) {
			*b++ = *q++;
			if (b >= buf+DEFMAX) {
			    lexerror("Macro expansion overflow");
			    return 0;
			}
		    }
		}
	    } else {
		*b++ = *e++;
		if (b >= buf+DEFMAX) {
		    lexerror("Macro expansion overflow");
		    return 0;
		}
	    }
	}
	*b++ = 0;
	add_input(buf);
    }
    return 1;
}

/*
 * External interface stuff
 */

void LPC_set_line(int x)
{
    current_line = x;
}

void LPC_set_file(char * n)
{
    if (current_file != NULL) free(current_file); 
    current_file = str_copy(n);
}

