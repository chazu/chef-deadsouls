

/*
** $Id: lexer.h,v 1.1.1.1 2001/09/11 04:12:06 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpc/lexer.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:06 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
**
** Lexical analyser uses different strings;
** they're designed to add together easily;
** ie write("balh"+"blah"); will automatically be
** converted to write("balhblah");
*/

#ifndef _LEXER_H
#define _LEXER_H

#include "stralloc.h"

/* Lexer string definitions */
struct lexical_string 
{
    char * s;
    short length;
};

typedef struct lexical_string lexar;

Shared 
    * to_Cstring(lexar * s)
    ;

char
    * to_str(lexar * s)
    ;

struct lexical_string	
    * lex_str_copy(char *)
    ;

void
    init_lex_space(void),
    free_lex_space(void),
    lex_strcat(lexar * a, lexar * b)
    ;


#endif
