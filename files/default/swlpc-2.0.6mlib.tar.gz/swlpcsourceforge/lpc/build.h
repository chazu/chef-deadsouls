/*
** $Id: build.h,v 1.3 2001/10/30 12:03:39 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpc/build.h,v $
** $Revision: 1.3 $
** $Date: 2001/10/30 12:03:39 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _BUILD_H
#define _BUILD_H

#include "stralloc.h"

/*
 *   Stuff for "patch"ing - essentially for a second parse
 *   of the linear code. Also needed for freeing up strings
 *   when a program is deleted.
*/
#define P_NULL   0
#define P_STRING 1
#define P_CALLU  2
#define P_CSTRING  3
#define P_BREAK  4

typedef struct patch_def
{
    int tipe;
    int offset;
    void * value;
    struct patch_def * next;
} Patch;

typedef struct keyword 
{
    Shared * word;
    short  token;
    int params;
} Keyword;

Patch 
    * add_break_patch(int offset),
    * add_patch(Func * f, int tipe, void *v)
    ;

Func * alloc_function(int type, Shared * name, int size, int num_var);
Func * find_local_header(Obj * ob, byte * pc);

byte * code_size_fix(Func * p);

void 
    do_break_patch(int backto, int line),
    emit(byte instr, byte arg),
    emit16(byte instr, short parg),
    emit32(byte instr, char *arg),
    emit_constant(Val * v),
    emit_pop(int s),
    emit_push(int t, int s),
    emits(byte instr),
    new_function(),
    patch16(int loc, short pval),
    patch8(int loc, byte val),
    remove_patch(Func * f)
    ;

int 
    process_patches(Class * O),
    emit_number(int num),
    emit_cnumber(int num),
    free_bad_prog(Func * p),
    free_prog(Func * p),
    show_prog_status(),
    yyparse()
    ;

CVal * make_const(Shared *s, Val * v, int t);
Shared * make_next_switch();
Val * share_Cstring(Shared *str);

#endif
