/* A Bison parser, made by GNU Bison 1.875a.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_STATIC = 258,
     TOK_PRIVATE = 259,
     TOK_TYPE = 260,
     TOK_CLASS = 261,
     TOK_SELF = 262,
     TOK_ARRAY = 263,
     TOK_OBJECT = 264,
     TOK_STRING_DECL = 265,
     TOK_REALT = 266,
     TOK_INT = 267,
     TOK_NUMBER = 268,
     TOK_STRING = 269,
     TOK_REAL = 270,
     TOK_SWITCH = 271,
     TOK_CASE = 272,
     TOK_DEFAULT = 273,
     TOK_IDENTIFIER = 274,
     TOK_TYNAME = 275,
     TOK_NEW = 276,
     TOK_VOID = 277,
     TOK_INHERIT = 278,
     TOK_COLON_COLON = 279,
     TOK_ENUM = 280,
     TOK_AS = 281,
     TOK_IMPORT = 282,
     TOK_END = 283,
     TOK_MODULE = 284,
     TOK_CATCH = 285,
     TOK_THROW = 286,
     TOK_GENERIC = 287,
     TOK_ABSTRACT = 288,
     TOK_DOTDOT = 289,
     TOK_LEFT_ARR = 290,
     TOK_RIGHT_ARR = 291,
     TOK_IF = 292,
     TOK_THEN = 293,
     TOK_ELSE = 294,
     TOK_WHILE = 295,
     TOK_DO = 296,
     TOK_FOR = 297,
     TOK_BREAK = 298,
     TOK_CONTINUE = 299,
     TOK_RETURN = 300,
     TOK_CONST = 301,
     TOK_LSH_EQ = 302,
     TOK_RSH_EQ = 303,
     TOK_LARROW = 304,
     TOK_AND_EQ = 305,
     TOK_OR_EQ = 306,
     TOK_XOR_EQ = 307,
     TOK_ADD_EQ = 308,
     TOK_SUB_EQ = 309,
     TOK_MULT_EQ = 310,
     TOK_DIV_EQ = 311,
     TOK_MOD_EQ = 312,
     OPASSIGN = 313,
     TOK_LOR = 314,
     TOK_LAND = 315,
     TOK_NE = 316,
     TOK_EQ = 317,
     TOK_LE = 318,
     TOK_GE = 319,
     TOK_RSH = 320,
     TOK_LSH = 321,
     POSTDEC = 322,
     POSTINC = 323,
     TOK_DEC = 324,
     TOK_INC = 325,
     UMINUS = 326,
     TOK_ARROW = 327
   };
#endif
#define TOK_STATIC 258
#define TOK_PRIVATE 259
#define TOK_TYPE 260
#define TOK_CLASS 261
#define TOK_SELF 262
#define TOK_ARRAY 263
#define TOK_OBJECT 264
#define TOK_STRING_DECL 265
#define TOK_REALT 266
#define TOK_INT 267
#define TOK_NUMBER 268
#define TOK_STRING 269
#define TOK_REAL 270
#define TOK_SWITCH 271
#define TOK_CASE 272
#define TOK_DEFAULT 273
#define TOK_IDENTIFIER 274
#define TOK_TYNAME 275
#define TOK_NEW 276
#define TOK_VOID 277
#define TOK_INHERIT 278
#define TOK_COLON_COLON 279
#define TOK_ENUM 280
#define TOK_AS 281
#define TOK_IMPORT 282
#define TOK_END 283
#define TOK_MODULE 284
#define TOK_CATCH 285
#define TOK_THROW 286
#define TOK_GENERIC 287
#define TOK_ABSTRACT 288
#define TOK_DOTDOT 289
#define TOK_LEFT_ARR 290
#define TOK_RIGHT_ARR 291
#define TOK_IF 292
#define TOK_THEN 293
#define TOK_ELSE 294
#define TOK_WHILE 295
#define TOK_DO 296
#define TOK_FOR 297
#define TOK_BREAK 298
#define TOK_CONTINUE 299
#define TOK_RETURN 300
#define TOK_CONST 301
#define TOK_LSH_EQ 302
#define TOK_RSH_EQ 303
#define TOK_LARROW 304
#define TOK_AND_EQ 305
#define TOK_OR_EQ 306
#define TOK_XOR_EQ 307
#define TOK_ADD_EQ 308
#define TOK_SUB_EQ 309
#define TOK_MULT_EQ 310
#define TOK_DIV_EQ 311
#define TOK_MOD_EQ 312
#define OPASSIGN 313
#define TOK_LOR 314
#define TOK_LAND 315
#define TOK_NE 316
#define TOK_EQ 317
#define TOK_LE 318
#define TOK_GE 319
#define TOK_RSH 320
#define TOK_LSH 321
#define POSTDEC 322
#define POSTINC 323
#define TOK_DEC 324
#define TOK_INC 325
#define UMINUS 326
#define TOK_ARROW 327




/* Copy the first part of user declarations.  */
#line 1 "lang.y"

#include <limits.h>
#include "stack.h"
#include "opcodes.h"
#include "lpc.h"
#include "lexer.h"
#include "build.h"
#include "lexical.h"
#include "consts.h"
#include "class.h"

/* runtime stuff */
#include "../runtime/hash.h"

#define YYMAXDEPTH    600

struct field {
    unsigned int type;
    short offset;
};

Val           * find_const2(Class ** io, char *s);
void          yyerror(), free_local_names_from();
extern int    yylex();
void          init_globals(), print_type(int), free_locals();

int           variable_count;    /* global vars */
int           static_variable_flag;
extern char   * zero;
Func          * prog;

extern int    current_line, uinstr, puinstr;
extern Obj    * Emulate;

int           lang_debug = 0;
int           last_type = 0;

/*
 * 'inherit_file' is used as a flag. If it is set to a string
 * after yyparse(), this string should be loaded as an object,
 * and the original object must be loaded again.
 * 'inherit_ob' will point to the super class object. This value is saved
 * so that load_object() can set up pointers to it.
 */

extern char 
    * current_file
    ;
 
extern Shared
    ** inherit_file
    ;

int 
    file_number = 0, 
    inherit_number = 0
    ;

Class
    ** inherit_ob = NULL
    ;

#define MAX_BLOCK_DEPTH 16    /* big! */
int labelstack[100];

int switchstack[MAX_BLOCK_DEPTH];
int switch_depth = 0;

int LD = 0; 

union 
{
        float r;
        int i;
        lexar * s;
} ultima, penultima;

int     block_depth = 0, max_locals = 0;
int     num_args, current_type = 0;
int     no_of_classes;
Func     *prog_head = 0, *CPD = 0;
Func     *initialise_func = 0;
Val     **global_table = 0;
CVal     **constant_table = 0;
struct  var_def *arg_head = 0;

/* globals stuff */
struct var_def 
    * global_head = 0,
    * global_tail = 0
    ;
int num_globals = 0;
int num_constants = 0;

/* local variable stuff */
struct var_def *local_head = 0;
int num_locals;
int num_block_locals[MAX_BLOCK_DEPTH];


#define STRING_BLOCK 100
#define INITIAL_FUNC_SIZE 200

/*
    $Id $
    A word on the type hacks below
    o designed to minimise changes the rest of the system
      (this will be fixed in due course).
    o Assume 32 bit ints.
    top 8 bits struct no     (max 255 structs)
    next 8 bits        (pointer depth max 255)
    next 8 bits        (special types static, private etc)
    next 8 bits        (basic types)

    (should be done using a struct; driver should support
     a fully "distributable" type system - these will all
     be done when I work out how :-)

    Geoff Wong (C) Copyright 1993 Shattered World.

    %token TOK_LAND TOK_LOR TOK_EQ TOK_NE '>' '<' TOK_GE TOK_LE
    %token TOK_DEC TOK_INC TOK_LSH TOK_RSH '[' ']' '.' '@'
    %token TOK_LSH_EQ TOK_RSH_EQ 
    %token TOK_AND_EQ TOK_OR_EQ TOK_XOR_EQ
    %token TOK_ADD_EQ TOK_SUB_EQ TOK_MULT_EQ TOK_DIV_EQ TOK_MOD_EQ
*/



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 146 "lang.y"
typedef union YYSTYPE {
    Func *lnode;
    int number;
    char * string;
    Shared * shared;
    float real;
    lexar *lexstr;
    Val * val;
} YYSTYPE;
/* Line 191 of yacc.c.  */
#line 359 "y.tab.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 371 "y.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1097

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  98
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  89
/* YYNRULES -- Number of rules. */
#define YYNRULES  203
/* YYNRULES -- Number of states. */
#define YYNSTATES  336

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   327

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    84,     2,     2,     2,    78,    66,     2,
      93,    94,    77,    75,    97,    76,    91,    79,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    60,    92,
      70,    59,    69,    61,    87,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    88,     2,    89,    65,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    95,    64,    96,    85,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    62,    63,    67,    68,    71,    72,
      73,    74,    80,    81,    82,    83,    86,    90
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     4,     5,    10,    11,    12,    16,    17,
      19,    21,    24,    26,    29,    31,    34,    38,    43,    48,
      50,    52,    53,    54,    63,    67,    73,    75,    78,    80,
      81,    83,    86,    89,    90,    92,    94,    98,   101,   102,
     104,   106,   108,   110,   112,   114,   116,   118,   121,   123,
     127,   129,   133,   135,   136,   142,   143,   148,   150,   155,
     156,   157,   162,   164,   168,   170,   175,   179,   181,   182,
     183,   187,   190,   192,   194,   196,   198,   200,   203,   206,
     208,   210,   214,   217,   220,   222,   223,   224,   232,   233,
     234,   244,   245,   246,   247,   260,   261,   263,   264,   265,
     275,   277,   280,   281,   282,   289,   290,   295,   297,   301,
     304,   307,   311,   315,   316,   321,   322,   326,   327,   328,
     336,   339,   342,   344,   348,   352,   354,   357,   361,   363,
     364,   371,   377,   384,   385,   390,   391,   396,   400,   404,
     408,   412,   416,   420,   424,   428,   432,   436,   440,   444,
     448,   452,   456,   460,   462,   465,   468,   471,   473,   475,
     477,   479,   481,   483,   485,   487,   489,   491,   493,   495,
     498,   499,   501,   505,   507,   509,   511,   513,   515,   518,
     520,   523,   525,   527,   532,   536,   538,   542,   544,   548,
     552,   554,   558,   559,   563,   568,   575,   577,   581,   584,
     588,   589,   596,   600
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short yyrhs[] =
{
      99,     0,    -1,    -1,    -1,   100,   104,   101,   102,    -1,
      -1,    -1,   102,   103,   111,    -1,    -1,   105,    -1,   106,
      -1,   106,   105,    -1,   108,    -1,   105,   108,    -1,   107,
      -1,   106,   107,    -1,    23,    14,    92,    -1,    27,    14,
     186,    92,    -1,    27,     7,   186,    92,    -1,    13,    -1,
      15,    -1,    -1,    -1,   114,   186,    93,   112,   116,    94,
     113,   128,    -1,   114,   123,    92,    -1,    46,   127,    59,
     173,    92,    -1,   137,    -1,   115,   120,    -1,     3,    -1,
      -1,     4,    -1,     3,     4,    -1,     4,     3,    -1,    -1,
     117,    -1,   118,    -1,   118,    97,   117,    -1,   119,   186,
      -1,    -1,   120,    -1,   122,    -1,    12,    -1,    10,    -1,
       8,    -1,    11,    -1,     9,    -1,    22,    -1,     6,   186,
      -1,   121,    -1,   122,    64,   121,    -1,   124,    -1,   123,
      97,   124,    -1,   127,    -1,    -1,   127,    88,   125,   171,
      89,    -1,    -1,   127,    59,   126,   165,    -1,   186,    -1,
      95,   129,   135,    96,    -1,    -1,    -1,   120,   131,   132,
      92,    -1,   133,    -1,   133,    97,   132,    -1,   134,    -1,
     134,    88,   171,    89,    -1,   134,    59,   165,    -1,   186,
      -1,    -1,    -1,   138,   136,   135,    -1,     1,    92,    -1,
     183,    -1,   139,    -1,   145,    -1,   142,    -1,   150,    -1,
     170,    92,    -1,   165,    92,    -1,   128,    -1,   137,    -1,
      31,   158,    92,    -1,    43,    92,    -1,    44,    92,    -1,
     130,    -1,    -1,    -1,    40,   140,    93,   165,    94,   141,
     138,    -1,    -1,    -1,    41,   143,   138,   144,    40,    93,
     165,    94,    92,    -1,    -1,    -1,    -1,    42,    93,   149,
      92,   146,   149,    92,   147,   149,    94,   148,   138,    -1,
      -1,   158,    -1,    -1,    -1,    16,   151,    93,   165,    94,
     152,    95,   153,    96,    -1,   154,    -1,   153,   154,    -1,
      -1,    -1,    17,   155,   172,    60,   156,   135,    -1,    -1,
      18,    60,   157,   135,    -1,   165,    -1,   158,    97,   165,
      -1,    83,   165,    -1,    82,   165,    -1,   177,    59,   165,
      -1,   174,    59,   165,    -1,    -1,   174,   161,   169,   165,
      -1,    -1,    30,   162,   138,    -1,    -1,    -1,   165,    61,
     163,   165,   164,    60,   165,    -1,   174,    83,    -1,   174,
      82,    -1,   180,    -1,    88,   171,    89,    -1,    35,   171,
      36,    -1,   174,    -1,    21,   186,    -1,    93,   158,    94,
      -1,   172,    -1,    -1,   165,    88,    34,   166,   165,    89,
      -1,   165,    88,   165,    34,    89,    -1,   165,    88,   165,
      34,   165,    89,    -1,    -1,   165,    62,   167,   165,    -1,
      -1,   165,    63,   168,   165,    -1,   165,    64,   165,    -1,
     165,    65,   165,    -1,   165,    66,   165,    -1,   165,    68,
     165,    -1,   165,    67,   165,    -1,   165,    69,   165,    -1,
     165,    72,   165,    -1,   165,    70,   165,    -1,   165,    71,
     165,    -1,   165,    74,   165,    -1,   165,    73,   165,    -1,
     165,    75,   165,    -1,   165,    76,   165,    -1,   165,    77,
     165,    -1,   165,    78,   165,    -1,   165,    79,   165,    -1,
     159,    -1,    84,   165,    -1,    85,   165,    -1,    76,   165,
      -1,   160,    -1,    50,    -1,    51,    -1,    52,    -1,    47,
      -1,    48,    -1,    53,    -1,    54,    -1,    55,    -1,    57,
      -1,    56,    -1,    45,    -1,    45,   158,    -1,    -1,   165,
      -1,   171,    97,   165,    -1,   178,    -1,   109,    -1,   110,
      -1,    14,    -1,    13,    -1,    76,    13,    -1,    15,    -1,
      76,    15,    -1,   186,    -1,   186,    -1,   165,    88,   165,
      89,    -1,   165,    91,   186,    -1,   186,    -1,   186,    97,
     175,    -1,   175,    -1,   175,    64,   186,    -1,    70,   176,
      69,    -1,    14,    -1,    93,   171,    94,    -1,    -1,   182,
     181,   179,    -1,   165,    90,   186,   179,    -1,   165,    90,
      93,   165,    94,   179,    -1,   186,    -1,    14,    24,   186,
      -1,    24,   186,    -1,    37,   185,   138,    -1,    -1,    37,
     185,   138,    39,   184,   138,    -1,    93,   165,    94,    -1,
      19,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   207,   207,   219,   207,   280,   282,   281,   312,   313,
     315,   317,   322,   324,   329,   330,   334,   377,   401,   410,
     418,   429,   437,   428,   477,   479,   489,   533,   542,   543,
     544,   545,   546,   549,   550,   553,   554,   557,   569,   570,
     573,   576,   577,   578,   579,   580,   581,   582,   596,   597,
     600,   601,   604,   609,   608,   629,   628,   645,   653,   661,
     672,   672,   674,   675,   678,   684,   693,   700,   709,   711,
     710,   715,   718,   719,   720,   721,   722,   723,   724,   725,
     729,   730,   735,   745,   754,   759,   764,   758,   780,   784,
     779,   798,   802,   809,   797,   825,   826,   830,   834,   829,
     875,   877,   882,   891,   881,   908,   907,   926,   927,   933,
     942,   954,   963,   970,   969,   981,   980,   994,  1000,   993,
    1012,  1023,  1034,  1038,  1045,  1051,  1052,  1066,  1068,  1070,
    1069,  1081,  1091,  1101,  1100,  1114,  1113,  1126,  1132,  1138,
    1144,  1150,  1156,  1162,  1168,  1174,  1180,  1186,  1192,  1207,
    1215,  1222,  1229,  1236,  1237,  1242,  1248,  1263,  1266,  1267,
    1268,  1269,  1270,  1271,  1272,  1273,  1274,  1275,  1278,  1283,
    1290,  1291,  1292,  1296,  1302,  1309,  1320,  1324,  1330,  1336,
    1342,  1348,  1369,  1398,  1421,  1438,  1439,  1443,  1444,  1448,
    1455,  1465,  1471,  1470,  1571,  1581,  1590,  1592,  1605,  1614,
    1622,  1619,  1633,  1640
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOK_STATIC", "TOK_PRIVATE", "TOK_TYPE", 
  "TOK_CLASS", "TOK_SELF", "TOK_ARRAY", "TOK_OBJECT", "TOK_STRING_DECL", 
  "TOK_REALT", "TOK_INT", "TOK_NUMBER", "TOK_STRING", "TOK_REAL", 
  "TOK_SWITCH", "TOK_CASE", "TOK_DEFAULT", "TOK_IDENTIFIER", "TOK_TYNAME", 
  "TOK_NEW", "TOK_VOID", "TOK_INHERIT", "TOK_COLON_COLON", "TOK_ENUM", 
  "TOK_AS", "TOK_IMPORT", "TOK_END", "TOK_MODULE", "TOK_CATCH", 
  "TOK_THROW", "TOK_GENERIC", "TOK_ABSTRACT", "TOK_DOTDOT", 
  "TOK_LEFT_ARR", "TOK_RIGHT_ARR", "TOK_IF", "TOK_THEN", "TOK_ELSE", 
  "TOK_WHILE", "TOK_DO", "TOK_FOR", "TOK_BREAK", "TOK_CONTINUE", 
  "TOK_RETURN", "TOK_CONST", "TOK_LSH_EQ", "TOK_RSH_EQ", "TOK_LARROW", 
  "TOK_AND_EQ", "TOK_OR_EQ", "TOK_XOR_EQ", "TOK_ADD_EQ", "TOK_SUB_EQ", 
  "TOK_MULT_EQ", "TOK_DIV_EQ", "TOK_MOD_EQ", "OPASSIGN", "'='", "':'", 
  "'?'", "TOK_LOR", "TOK_LAND", "'|'", "'^'", "'&'", "TOK_NE", "TOK_EQ", 
  "'>'", "'<'", "TOK_LE", "TOK_GE", "TOK_RSH", "TOK_LSH", "'+'", "'-'", 
  "'*'", "'%'", "'/'", "POSTDEC", "POSTINC", "TOK_DEC", "TOK_INC", "'!'", 
  "'~'", "UMINUS", "'@'", "'['", "']'", "TOK_ARROW", "'.'", "';'", "'('", 
  "')'", "'{'", "'}'", "','", "$accept", "all", "@1", "@2", "program", 
  "@3", "in_options", "import_list", "inheritance_list", "inheritance", 
  "import", "number", "realnumber", "function_def", "@4", "@5", 
  "statprivtype", "static", "arglist", "fun_arglist", "new_fun_arg", 
  "possible_type", "type", "basetype", "typelist", "global_name_list", 
  "new_global_name_decl", "@6", "@7", "new_global_name", "block", 
  "blktmp", "local_declaration", "@8", "local_list", "locid_decl", 
  "newlocid", "statements", "@9", "simple_stmt", "statement", "while", 
  "@10", "@11", "do", "@12", "@13", "for", "@14", "@15", "@16", 
  "for_expr", "switch", "@17", "@18", "switch_expr", "switch_case", "@19", 
  "@20", "@21", "comma_expr", "prefix", "stmt_expr", "@22", "@23", "@24", 
  "@25", "expr", "@26", "@27", "@28", "op_assign", "return", "expr_list", 
  "constant_expr", "constant_expr2", "variable", "variable_list", 
  "variable_match", "pattern", "string", "bracket_list", "function_call", 
  "@29", "function_name", "ifstmt", "@30", "if_expr", "identifier", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,    61,
      58,    63,   314,   315,   124,    94,    38,   316,   317,    62,
      60,   318,   319,   320,   321,    43,    45,    42,    37,    47,
     322,   323,   324,   325,    33,   126,   326,    64,    91,    93,
     327,    46,    59,    40,    41,   123,   125,    44
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,    98,   100,   101,    99,   102,   103,   102,   104,   104,
     104,   104,   105,   105,   106,   106,   107,   108,   108,   109,
     110,   112,   113,   111,   111,   111,   111,   114,   115,   115,
     115,   115,   115,   116,   116,   117,   117,   118,   119,   119,
     120,   121,   121,   121,   121,   121,   121,   121,   122,   122,
     123,   123,   124,   125,   124,   126,   124,   127,   128,   129,
     131,   130,   132,   132,   133,   133,   133,   134,   135,   136,
     135,   135,   137,   137,   137,   137,   137,   137,   137,   137,
     138,   138,   138,   138,   138,   140,   141,   139,   143,   144,
     142,   146,   147,   148,   145,   149,   149,   151,   152,   150,
     153,   153,   155,   156,   154,   157,   154,   158,   158,   159,
     159,   160,   160,   161,   160,   162,   160,   163,   164,   160,
     160,   160,   160,   165,   165,   165,   165,   165,   165,   166,
     165,   165,   165,   167,   165,   168,   165,   165,   165,   165,
     165,   165,   165,   165,   165,   165,   165,   165,   165,   165,
     165,   165,   165,   165,   165,   165,   165,   165,   169,   169,
     169,   169,   169,   169,   169,   169,   169,   169,   170,   170,
     171,   171,   171,   172,   172,   172,   173,   173,   173,   173,
     173,   173,   174,   174,   174,   175,   175,   176,   176,   177,
     178,   179,   181,   180,   180,   180,   182,   182,   182,   183,
     184,   183,   185,   186
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     0,     0,     4,     0,     0,     3,     0,     1,
       1,     2,     1,     2,     1,     2,     3,     4,     4,     1,
       1,     0,     0,     8,     3,     5,     1,     2,     1,     0,
       1,     2,     2,     0,     1,     1,     3,     2,     0,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     1,     3,
       1,     3,     1,     0,     5,     0,     4,     1,     4,     0,
       0,     4,     1,     3,     1,     4,     3,     1,     0,     0,
       3,     2,     1,     1,     1,     1,     1,     2,     2,     1,
       1,     3,     2,     2,     1,     0,     0,     7,     0,     0,
       9,     0,     0,     0,    12,     0,     1,     0,     0,     9,
       1,     2,     0,     0,     6,     0,     4,     1,     3,     2,
       2,     3,     3,     0,     4,     0,     3,     0,     0,     7,
       2,     2,     1,     3,     3,     1,     2,     3,     1,     0,
       6,     5,     6,     0,     4,     0,     4,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     1,     2,     2,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       0,     1,     3,     1,     1,     1,     1,     1,     2,     1,
       2,     1,     1,     4,     3,     1,     3,     1,     3,     3,
       1,     3,     0,     3,     4,     6,     1,     3,     2,     3,
       0,     6,     3,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       2,     0,     8,     1,     0,     0,     3,     9,    10,    14,
      12,     0,     0,     0,     5,    13,    11,    15,    16,   203,
       0,     0,     6,    18,    17,    29,    28,    30,    19,   190,
      20,    97,     0,     0,   115,   170,     0,    85,    88,     0,
     168,     0,     0,     0,     0,     0,     0,     0,   170,     0,
      59,   174,   175,     7,     0,     0,    79,    26,    73,    75,
      74,    76,   153,   157,     0,     0,   128,   125,     0,   173,
     122,   192,    72,   182,    31,    32,     0,     0,   126,   198,
       0,   171,     0,     0,     0,     0,     0,    95,   169,   107,
       0,    57,   187,     0,   185,   156,   110,   109,   154,   155,
       0,     0,     0,     0,    50,    52,    57,     0,    43,    45,
      42,    44,    41,    46,    27,    48,    40,   117,   133,   135,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    78,
      77,     0,   121,   120,     0,     0,     0,   197,     0,     0,
       0,     0,    60,    84,    80,   116,   124,     0,     0,   199,
       0,    89,     0,    96,     0,     0,     0,   189,     0,   123,
     127,     0,     0,    69,    24,     0,    55,    53,    21,    47,
       0,     0,     0,     0,   137,   138,   139,   141,   140,   142,
     144,   145,   143,   147,   146,   148,   149,   150,   151,   152,
     129,     0,     0,     0,   184,   112,   161,   162,   158,   159,
     160,   163,   164,   165,   167,   166,     0,   111,   170,   193,
       0,     0,    82,    83,     0,   172,   202,   200,     0,     0,
      91,   108,   177,   176,   179,     0,     0,   181,   188,   186,
      71,    58,     0,    51,     0,   170,    33,    49,   118,   134,
     136,     0,     0,   183,     0,   194,   114,     0,    98,    81,
       0,    62,    64,    67,     0,    86,     0,    95,   178,   180,
      25,    70,    56,     0,     0,    34,    35,     0,    39,     0,
       0,   131,     0,     0,   191,     0,    61,     0,     0,   170,
     201,     0,     0,     0,    54,    22,    38,    37,     0,   130,
     132,   195,     0,    63,    66,     0,    87,     0,    92,     0,
      36,   119,   102,     0,     0,   100,    65,     0,    95,    23,
       0,   105,    99,   101,    90,     0,   190,     0,     0,    93,
     103,   106,     0,     0,    94,   104
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,     1,     2,    14,    22,    25,     6,     7,     8,     9,
      10,    51,    52,    53,   246,   309,    54,    55,   274,   275,
     276,   277,   152,   115,   116,   103,   104,   245,   244,   105,
      56,   102,   153,   224,   260,   261,   262,   172,   242,   154,
     173,    58,    85,   291,    59,    86,   229,    60,   267,   318,
     332,   162,    61,    77,   285,   314,   315,   320,   333,   328,
     163,    62,    63,   144,    80,   181,   279,    64,   251,   182,
     183,   216,    65,    82,    66,   236,    67,    92,    93,    68,
      69,   219,    70,   146,    71,    72,   264,    84,    73
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -248
static const short yypact[] =
{
    -248,     7,    12,  -248,    15,    59,  -248,    26,    12,  -248,
    -248,   -54,    58,    58,  -248,  -248,    26,  -248,  -248,  -248,
      17,    27,   124,  -248,  -248,   461,   126,   136,  -248,   120,
    -248,  -248,    58,    58,  -248,   626,    52,  -248,  -248,    57,
     626,    58,    58,   626,   626,   626,   626,   626,   626,   626,
    -248,  -248,  -248,  -248,    58,    22,  -248,  -248,  -248,  -248,
    -248,  -248,  -248,  -248,   615,    60,  -248,   109,    96,  -248,
    -248,  -248,  -248,    65,  -248,  -248,    58,    80,  -248,  -248,
     549,   823,   -30,   626,   549,    81,   549,   626,    54,   823,
     116,  -248,   112,   108,    83,    30,    30,    30,    30,    30,
     -33,    29,   375,   -42,  -248,   -37,    85,    58,  -248,  -248,
    -248,  -248,  -248,  -248,  -248,  -248,   118,  -248,  -248,  -248,
     626,   626,   626,   626,   626,   626,   626,   626,   626,   626,
     626,   626,   626,   626,   626,   626,   119,   -15,    58,  -248,
    -248,   626,  -248,  -248,   218,   626,    91,  -248,   626,   626,
      93,    94,  -248,  -248,  -248,  -248,  -248,   626,   362,   148,
     626,  -248,   102,    54,   626,    28,    58,  -248,    58,  -248,
    -248,   104,   101,  -248,  -248,    58,  -248,  -248,  -248,  -248,
      22,   626,   626,   626,   907,   933,   958,   983,   983,  1006,
    1006,  1006,  1006,   -16,   -16,    -9,    -9,    30,    30,    30,
    -248,   273,   626,    91,  -248,   823,  -248,  -248,  -248,  -248,
    -248,  -248,  -248,  -248,  -248,  -248,   626,   823,   626,  -248,
     448,    11,  -248,  -248,    58,   823,  -248,  -248,   659,   150,
    -248,   823,  -248,  -248,  -248,    92,   113,  -248,  -248,  -248,
    -248,  -248,   284,  -248,   626,   626,   212,  -248,   823,   852,
     880,   626,   582,  -248,   693,  -248,   823,    34,  -248,  -248,
     114,   103,   -34,  -248,   549,  -248,    95,   626,  -248,  -248,
    -248,  -248,   823,   -32,   117,  -248,   111,    58,  -248,   153,
     761,  -248,   792,    91,  -248,   130,  -248,    58,   626,   626,
    -248,   549,   626,   123,  -248,  -248,    22,  -248,   626,  -248,
    -248,  -248,    98,  -248,   823,   -13,  -248,   727,  -248,   132,
    -248,   823,  -248,   154,     6,  -248,  -248,   127,   626,  -248,
     122,  -248,  -248,  -248,  -248,   135,  -248,   170,   284,  -248,
    -248,  -248,   549,   284,  -248,  -248
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
    -248,  -248,  -248,  -248,  -248,  -248,  -248,   225,  -248,   227,
      33,  -248,  -248,  -248,  -248,  -248,  -248,  -248,  -248,   -60,
    -248,  -248,   -53,    61,  -248,  -248,    62,  -248,  -248,   197,
     -70,  -248,  -248,  -248,   -43,  -248,  -248,  -216,  -248,   215,
     -65,  -248,  -248,  -248,  -248,  -248,  -248,  -248,  -248,  -248,
    -248,  -247,  -248,  -248,  -248,  -248,   -69,  -248,  -248,  -248,
     -22,  -248,  -248,  -248,  -248,  -248,  -248,   -35,  -248,  -248,
    -248,  -248,  -248,   -47,   -74,  -248,  -248,    79,  -248,  -248,
    -248,  -200,  -248,  -248,  -248,  -248,  -248,  -248,     4
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -197
static const short yytable[] =
{
      81,   100,   114,   255,    19,    89,   156,     3,    95,    96,
      97,    98,    99,    81,    89,   155,    20,    21,    88,   159,
     293,   161,   176,   312,   313,   288,   271,   101,   107,    11,
     108,   109,   110,   111,   112,     4,    78,    79,    18,     5,
      15,   232,   233,   234,   113,    91,    94,    19,   158,    15,
     174,   177,    89,     5,   289,   175,   169,   294,   106,   131,
     132,   133,   134,   135,   157,   157,    12,   157,   133,   134,
     135,   325,   136,    13,   137,   138,   316,    19,   202,   136,
     147,   137,   138,   301,   157,   184,   185,   186,   187,   188,
     189,   190,   191,   192,   193,   194,   195,   196,   197,   198,
     199,   201,   322,   259,   235,   268,   205,   269,   164,    23,
     217,   179,   331,   220,    89,   312,   313,   335,   136,    24,
     137,   138,   225,   170,    -4,   228,   164,   221,   284,   231,
      74,   157,    28,    29,    30,    28,   326,    30,    19,    75,
      32,   203,   204,    33,    76,    83,   248,   249,   250,    34,
      87,   164,   140,   200,    35,   145,  -113,  -113,  -196,  -113,
    -113,  -113,  -113,  -113,  -113,  -113,  -113,   254,   141,   237,
     238,   257,    94,   148,   160,   165,   166,   167,   178,    91,
     168,   256,   180,    81,   218,   222,   223,   227,   292,    42,
     266,   142,   143,   278,   230,    43,   240,   241,   273,   290,
     287,    44,    45,    46,    47,   270,   286,    48,   296,   272,
      81,   295,    49,   298,   321,   308,   280,   282,   107,   324,
     108,   109,   110,   111,   112,   302,   306,    50,   263,   329,
     330,   -38,    89,    16,   113,    17,   310,   243,    90,   319,
      57,   247,   305,   278,   303,   323,   327,   239,     0,     0,
       0,     0,     0,   304,    81,     0,     0,   307,     0,     0,
       0,     0,     0,   311,     0,   206,   207,   334,   208,   209,
     210,   211,   212,   213,   214,   215,     0,     0,     0,     0,
       0,   297,     0,    89,     0,   171,     0,     0,     0,     0,
     107,   263,   108,   109,   110,   111,   112,    28,    29,    30,
      31,   -68,   -68,    19,     0,    32,   113,   252,    33,     0,
       0,     0,     0,     0,    34,   149,     0,     0,     0,    35,
       0,    36,     0,     0,    37,    38,    39,   150,   151,    40,
       0,     0,     0,     0,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,     0,    42,     0,     0,     0,     0,     0,
      43,   136,   253,   137,   138,     0,    44,    45,    46,    47,
       0,     0,    48,     0,     0,     0,   171,    49,     0,    50,
     -68,   107,     0,   108,   109,   110,   111,   112,    28,    29,
      30,    31,     0,     0,    19,     0,    32,   113,     0,    33,
       0,     0,     0,     0,     0,    34,   149,     0,     0,     0,
      35,     0,    36,     0,     0,    37,    38,    39,   150,   151,
      40,     0,     0,   117,   118,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     134,   135,     0,     0,     0,    42,     0,     0,     0,     0,
     136,    43,   137,   138,     0,     0,   226,    44,    45,    46,
      47,     0,     0,    48,    26,    27,     0,     0,    49,     0,
      50,   -68,     0,     0,    28,    29,    30,    31,     0,     0,
      19,     0,    32,     0,     0,    33,     0,     0,     0,     0,
       0,    34,     0,     0,     0,     0,    35,     0,    36,     0,
       0,    37,    38,    39,     0,     0,    40,    41,     0,   117,
     118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,   134,   135,     0,     0,
       0,    42,     0,     0,     0,     0,   136,    43,   137,   138,
       0,     0,   258,    44,    45,    46,    47,     0,     0,    48,
       0,     0,     0,     0,    49,   107,    50,   108,   109,   110,
     111,   112,    28,    29,    30,    31,     0,     0,    19,     0,
      32,   113,     0,    33,     0,     0,     0,     0,     0,    34,
     149,     0,     0,     0,    35,     0,    36,     0,     0,    37,
      38,    39,   150,   151,    40,    28,    29,    30,     0,     0,
       0,    19,     0,    32,     0,     0,    33,     0,     0,     0,
       0,     0,    34,     0,     0,     0,     0,    35,     0,    42,
       0,     0,     0,     0,     0,    43,     0,     0,     0,     0,
       0,    44,    45,    46,    47,     0,     0,    48,     0,    28,
      29,    30,    49,     0,    50,    19,     0,    32,     0,     0,
      33,     0,    42,     0,     0,     0,    34,     0,    43,     0,
       0,    35,     0,     0,    44,    45,    46,    47,     0,     0,
      48,   281,     0,     0,     0,    49,   117,   118,   119,   120,
     121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
     131,   132,   133,   134,   135,     0,    42,     0,     0,     0,
       0,     0,    43,   136,     0,   137,   138,   139,    44,    45,
      46,    47,     0,     0,    48,     0,     0,     0,     0,    49,
     117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,     0,
       0,     0,     0,     0,     0,     0,     0,   136,     0,   137,
     138,     0,     0,   265,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,     0,     0,     0,     0,     0,     0,     0,
       0,   136,     0,   137,   138,     0,     0,   283,   117,   118,
     119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
     129,   130,   131,   132,   133,   134,   135,     0,     0,     0,
       0,     0,     0,     0,     0,   136,     0,   137,   138,     0,
       0,   317,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,     0,     0,     0,     0,     0,     0,     0,     0,   136,
     299,   137,   138,   117,   118,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     134,   135,     0,     0,     0,     0,     0,     0,     0,     0,
     136,   300,   137,   138,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,     0,     0,     0,     0,     0,     0,     0,
       0,   136,     0,   137,   138,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     134,   135,     0,     0,     0,     0,     0,     0,     0,     0,
     136,     0,   137,   138,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
       0,     0,     0,     0,     0,     0,     0,     0,   136,     0,
     137,   138,   121,   122,   123,   124,   125,   126,   127,   128,
     129,   130,   131,   132,   133,   134,   135,     0,     0,     0,
       0,     0,     0,     0,     0,   136,     0,   137,   138,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,     0,     0,     0,     0,     0,     0,     0,
       0,   136,     0,   137,   138,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,   134,   135,     0,     0,
       0,     0,     0,     0,     0,     0,   136,     0,   137,   138,
    -197,  -197,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,     0,     0,     0,     0,     0,     0,     0,
       0,   136,     0,   137,   138,  -197,  -197,  -197,  -197,   129,
     130,   131,   132,   133,   134,   135,     0,     0,     0,     0,
       0,     0,     0,     0,   136,     0,   137,   138
};

static const short yycheck[] =
{
      35,    48,    55,   203,    19,    40,    36,     0,    43,    44,
      45,    46,    47,    48,    49,    80,    12,    13,    40,    84,
     267,    86,    59,    17,    18,    59,   242,    49,     6,    14,
       8,     9,    10,    11,    12,    23,    32,    33,    92,    27,
       7,    13,    14,    15,    22,    41,    42,    19,    83,    16,
      92,    88,    87,    27,    88,    97,    89,    89,    54,    75,
      76,    77,    78,    79,    97,    97,     7,    97,    77,    78,
      79,   318,    88,    14,    90,    91,    89,    19,    93,    88,
      76,    90,    91,   283,    97,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,    96,    92,    76,    13,   141,    15,    97,    92,
     145,   107,   328,   148,   149,    17,    18,   333,    88,    92,
      90,    91,   157,    94,     0,   160,    97,   149,    94,   164,
       4,    97,    13,    14,    15,    13,    14,    15,    19,     3,
      21,   137,   138,    24,    24,    93,   181,   182,   183,    30,
      93,    97,    92,    34,    35,    59,    47,    48,    93,    50,
      51,    52,    53,    54,    55,    56,    57,   202,    59,   165,
     166,   218,   168,    93,    93,    59,    64,    69,    93,   175,
      97,   216,    64,   218,    93,    92,    92,    39,    93,    70,
      40,    82,    83,   246,    92,    76,    92,    96,   245,   264,
      97,    82,    83,    84,    85,    92,    92,    88,    97,   244,
     245,    94,    93,    60,    60,    92,   251,   252,     6,    92,
       8,     9,    10,    11,    12,    95,   291,    95,   224,    94,
      60,    19,   267,     8,    22,     8,   296,   175,    41,   309,
      25,   180,   289,   296,   287,   314,   320,   168,    -1,    -1,
      -1,    -1,    -1,   288,   289,    -1,    -1,   292,    -1,    -1,
      -1,    -1,    -1,   298,    -1,    47,    48,   332,    50,    51,
      52,    53,    54,    55,    56,    57,    -1,    -1,    -1,    -1,
      -1,   277,    -1,   318,    -1,     1,    -1,    -1,    -1,    -1,
       6,   287,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    -1,    21,    22,    34,    24,    -1,
      -1,    -1,    -1,    -1,    30,    31,    -1,    -1,    -1,    35,
      -1,    37,    -1,    -1,    40,    41,    42,    43,    44,    45,
      -1,    -1,    -1,    -1,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    -1,    70,    -1,    -1,    -1,    -1,    -1,
      76,    88,    89,    90,    91,    -1,    82,    83,    84,    85,
      -1,    -1,    88,    -1,    -1,    -1,     1,    93,    -1,    95,
      96,     6,    -1,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    -1,    -1,    19,    -1,    21,    22,    -1,    24,
      -1,    -1,    -1,    -1,    -1,    30,    31,    -1,    -1,    -1,
      35,    -1,    37,    -1,    -1,    40,    41,    42,    43,    44,
      45,    -1,    -1,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    70,    -1,    -1,    -1,    -1,
      88,    76,    90,    91,    -1,    -1,    94,    82,    83,    84,
      85,    -1,    -1,    88,     3,     4,    -1,    -1,    93,    -1,
      95,    96,    -1,    -1,    13,    14,    15,    16,    -1,    -1,
      19,    -1,    21,    -1,    -1,    24,    -1,    -1,    -1,    -1,
      -1,    30,    -1,    -1,    -1,    -1,    35,    -1,    37,    -1,
      -1,    40,    41,    42,    -1,    -1,    45,    46,    -1,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    70,    -1,    -1,    -1,    -1,    88,    76,    90,    91,
      -1,    -1,    94,    82,    83,    84,    85,    -1,    -1,    88,
      -1,    -1,    -1,    -1,    93,     6,    95,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    -1,    -1,    19,    -1,
      21,    22,    -1,    24,    -1,    -1,    -1,    -1,    -1,    30,
      31,    -1,    -1,    -1,    35,    -1,    37,    -1,    -1,    40,
      41,    42,    43,    44,    45,    13,    14,    15,    -1,    -1,
      -1,    19,    -1,    21,    -1,    -1,    24,    -1,    -1,    -1,
      -1,    -1,    30,    -1,    -1,    -1,    -1,    35,    -1,    70,
      -1,    -1,    -1,    -1,    -1,    76,    -1,    -1,    -1,    -1,
      -1,    82,    83,    84,    85,    -1,    -1,    88,    -1,    13,
      14,    15,    93,    -1,    95,    19,    -1,    21,    -1,    -1,
      24,    -1,    70,    -1,    -1,    -1,    30,    -1,    76,    -1,
      -1,    35,    -1,    -1,    82,    83,    84,    85,    -1,    -1,
      88,    89,    -1,    -1,    -1,    93,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    -1,    70,    -1,    -1,    -1,
      -1,    -1,    76,    88,    -1,    90,    91,    92,    82,    83,
      84,    85,    -1,    -1,    88,    -1,    -1,    -1,    -1,    93,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,    -1,    90,
      91,    -1,    -1,    94,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    88,    -1,    90,    91,    -1,    -1,    94,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    88,    -1,    90,    91,    -1,
      -1,    94,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,
      89,    90,    91,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      88,    89,    90,    91,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    88,    -1,    90,    91,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      88,    -1,    90,    91,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,    -1,
      90,    91,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    88,    -1,    90,    91,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    88,    -1,    90,    91,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    88,    -1,    90,    91,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    88,    -1,    90,    91,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    88,    -1,    90,    91
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,    99,   100,     0,    23,    27,   104,   105,   106,   107,
     108,    14,     7,    14,   101,   108,   105,   107,    92,    19,
     186,   186,   102,    92,    92,   103,     3,     4,    13,    14,
      15,    16,    21,    24,    30,    35,    37,    40,    41,    42,
      45,    46,    70,    76,    82,    83,    84,    85,    88,    93,
      95,   109,   110,   111,   114,   115,   128,   137,   139,   142,
     145,   150,   159,   160,   165,   170,   172,   174,   177,   178,
     180,   182,   183,   186,     4,     3,    24,   151,   186,   186,
     162,   165,   171,    93,   185,   140,   143,    93,   158,   165,
     127,   186,   175,   176,   186,   165,   165,   165,   165,   165,
     171,   158,   129,   123,   124,   127,   186,     6,     8,     9,
      10,    11,    12,    22,   120,   121,   122,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    88,    90,    91,    92,
      92,    59,    82,    83,   161,    59,   181,   186,    93,    31,
      43,    44,   120,   130,   137,   138,    36,    97,   165,   138,
      93,   138,   149,   158,    97,    59,    64,    69,    97,    89,
      94,     1,   135,   138,    92,    97,    59,    88,    93,   186,
      64,   163,   167,   168,   165,   165,   165,   165,   165,   165,
     165,   165,   165,   165,   165,   165,   165,   165,   165,   165,
      34,   165,    93,   186,   186,   165,    47,    48,    50,    51,
      52,    53,    54,    55,    56,    57,   169,   165,    93,   179,
     165,   158,    92,    92,   131,   165,    94,    39,   165,   144,
      92,   165,    13,    14,    15,    76,   173,   186,   186,   175,
      92,    96,   136,   124,   126,   125,   112,   121,   165,   165,
     165,   166,    34,    89,   165,   179,   165,   171,    94,    92,
     132,   133,   134,   186,   184,    94,    40,   146,    13,    15,
      92,   135,   165,   171,   116,   117,   118,   119,   120,   164,
     165,    89,   165,    94,    94,   152,    92,    97,    59,    88,
     138,   141,    93,   149,    89,    94,    97,   186,    60,    89,
      89,   179,    95,   132,   165,   171,   138,   165,    92,   113,
     117,   165,    17,    18,   153,   154,    89,    94,   147,   128,
     155,    60,    96,   154,    92,   149,    14,   172,   157,    94,
      60,   135,   148,   156,   138,   135
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)         \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (cinluded).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylineno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylineno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 207 "lang.y"
    {
    /* initialise here! */
         prog_head = 0;
        CPD = 0;
         num_globals = 0;
        num_constants = 0;
        global_head = 0;
        no_of_classes = 0;
       }
    break;

  case 3:
#line 219 "lang.y"
    { 
      Func *p;
      if (inherit_file != NULL) {
        inherit_file[file_number] = 0;
        return 0;
      }
      if (inherit_ob != NULL) {
        inherit_ob[inherit_number] = 0;
      }
      p = alloc_function(0, C("*InitGlobals"),
            INITIAL_FUNC_SIZE, 0);
      p->next = 0;
      p->num_arg = 0;
      CPD = p;
      emit(S_ENTER, 0);
      if (inherit_ob != NULL || inherit_file != NULL) 
      {
        Shared * v;
        char pname[1024];
        int i;

        for (i = 0; inherit_ob[i]; i++) 
        {
            emit(S_PUSH8, 0);
            emit(S_PUSHC, 0);    
            emit(S_PUSHC, 0);
            emit(S_ADDSP, 0);
            strcpy(pname, inherit_ob[i]->name->str);
            strcat(pname, "::*InitGlobals");
            v = string_copy(pname);
            add_patch(CPD, P_CALLU, v);
            /* printf("S_CALLU: %s\n", v); */
            emit32(S_CALLU, (char *)&(v));
        }
      }
      initialise_func = p;
      prog_head = p;
      init_globals(); 
      CPD = initialise_func;
    }
    break;

  case 4:
#line 261 "lang.y"
    {
        initialise_func->next = 0;
        CPD = initialise_func;
        /* copy initialise code block to a non-global one */
        emit(S_PUSH8, 0);
        emits(S_RETURN);
        emits(S_END);
          CPD->block = code_size_fix(CPD); 
        CPD->num_var = 0;
        prog_head = yyvsp[0].lnode;
        if (!prog_head) {
            printf("No program returned!\n");
        }
        make_global_tables();
    }
    break;

  case 5:
#line 280 "lang.y"
    { yyval.lnode = prog_head; /* start of program */ }
    break;

  case 6:
#line 282 "lang.y"
    {
        block_depth = 0;
    }
    break;

  case 7:
#line 286 "lang.y"
    {
        if (yyvsp[0].lnode != 0) 
        {
            Func *p = (Func *)yyvsp[0].lnode;
            p->next = (Func *)yyvsp[-2].lnode;
            yyval.lnode = p;
            /* should this also check efuns & emulatefuns? */
            if (defined_function(p->name)) 
            {
                yyerror("Illegal to redeclare function.");
            }
        } 
        else 
        {
            yyval.lnode = yyvsp[-2].lnode;
        }
    }
    break;

  case 8:
#line 312 "lang.y"
    { yyval.number = 0; }
    break;

  case 9:
#line 314 "lang.y"
    { yyval.number = 0; }
    break;

  case 10:
#line 316 "lang.y"
    { yyval.number = 0; }
    break;

  case 11:
#line 318 "lang.y"
    { yyval.number = 0; }
    break;

  case 12:
#line 323 "lang.y"
    { yyval.number = yyvsp[0].number; }
    break;

  case 13:
#line 325 "lang.y"
    { yyval.number = yyvsp[0].number; }
    break;

  case 16:
#line 335 "lang.y"
    {
        /* FIX:: MAX_INHERIT is non-dynamic brain damage */
        if (inherit_number >= MAX_INHERIT ) 
        {
            yyerror("Too many files inherited.\n");
        } 
        else 
        {
            Shared * inhs = to_Cstring(yyvsp[-1].lexstr);

            free(yyvsp[-1].lexstr);
            if (inherit_ob == NULL) 
            {
                /* space leak! */
                inherit_ob = (Class **)
                  malloc(sizeof(Class *) * (MAX_INHERIT+1));
                inherit_number = 0;
            }

            /* External dependency! */
            inherit_ob[inherit_number] = find_class(inhs);

            if (inherit_ob[inherit_number] == 0) 
            {
                if (inherit_file == NULL) {
                /* space leak! */
                inherit_file = (Shared **)
                  malloc(sizeof(char *) * (MAX_INHERIT+1));
                file_number = 0;
                }
                inherit_file[file_number++] = inhs;
                inherit_file[file_number] = 0;
            }
            else 
            {
                inherit_number++;
            }
        }
    }
    break;

  case 17:
#line 378 "lang.y"
    {
        Shared *inhs = to_Cstring(yyvsp[-2].lexstr);
        Class  *iobj; 

        free(yyvsp[-2].lexstr);
        /* need to insure stuff is loaded. fuck fuck fuck */
        iobj = find_class(inhs);
        if (!iobj) {
            /* sigh - nasty piece of work. */
            if (!inherit_file) {
                inherit_file = (Shared **)
                  malloc(sizeof(char *) * (MAX_INHERIT+1));
                file_number = 0;
                }
            inherit_file[file_number++] = inhs;
            inherit_file[file_number] = 0;
        }
        else {
            add_type_list(yyvsp[-1].shared, iobj);
        }
        yyval.number = 0;
    }
    break;

  case 18:
#line 402 "lang.y"
    {
        /* FIX:: self importing */
        add_type_list(yyvsp[-1].shared, 0);
        yyval.number = 0;
    }
    break;

  case 19:
#line 411 "lang.y"
    {
        emit_number(yyvsp[0].number);
        yyval.number = (int)yyvsp[0].number;
    }
    break;

  case 20:
#line 419 "lang.y"
    {
        yyval.real = yyvsp[0].real;
        emit32(S_PUSHr, (char *)&yyval.real);
#if 0
printf("real yacc: %f\n", yyval.real);
#endif
    }
    break;

  case 21:
#line 429 "lang.y"
    {
        block_depth++; 
        yyval.lnode = alloc_function(yyvsp[-2].number, yyvsp[-1].shared, INITIAL_FUNC_SIZE, 0);
        CPD = yyval.lnode;

        new_function();
    }
    break;

  case 22:
#line 437 "lang.y"
    {
        struct var_def *t = arg_head;    

        /* haven't taken into account ret addr and old bp on stack */
        if (arg_head != NULL) 
        {
            /* emit(S_COPY, num_args); */
            while (t) {
                emit16(S_TYPEC, t->type);
                /*
                if (t->type != T_ANY)
                    emit16(S_TYPEC, t->type);
                else
                    emit(S_ADDSP, -1);    
                */
                t = t->next;
            }
        }
        emit(S_ENTER, 0);
        CPD->num_arg = num_args;
        yyval.number = CPD->current_I;
    }
    break;

  case 23:
#line 460 "lang.y"
    {
        Func *p = yyvsp[-4].lnode;
        patch8(yyvsp[-1].number - 1, max_locals);
/*      p->num_arg = num_args; */
/*      p->type = p->type | $1; */
        yyval.lnode = p;
        CPD = yyval.lnode;
        /* free the local and arg space */
        free_locals();
        emit(S_PUSH8,0);
        emits(S_RETURN);
        emits(S_END);
        p->block = code_size_fix(p); 
        p->num_var = max_locals;
        block_depth--;
        if (block_depth == 0) CPD = initialise_func;
    }
    break;

  case 24:
#line 478 "lang.y"
    { yyval.lnode = 0; }
    break;

  case 25:
#line 480 "lang.y"
    {
        /* + these could be copy propagated later? */
        /* + need to redefine global_table in object */
        /* + copy in values when creating variable table */
        /* + also must ensure these aren't assigned to! */

        add_global_variable(yyvsp[-3].shared, yyvsp[-1].val->type | TY_CONSTANT, yyvsp[-1].val);
        yyval.lnode = 0;
    }
    break;

  case 26:
#line 489 "lang.y"
    { yyval.lnode = 0; }
    break;

  case 27:
#line 534 "lang.y"
    { 
      /* $$ = $2; 41093 */
      current_type = yyvsp[-1].number | yyvsp[0].number;
      yyval.number = current_type;
      static_variable_flag = yyval.number;
    }
    break;

  case 28:
#line 542 "lang.y"
    { yyval.number = TY_STATIC; }
    break;

  case 29:
#line 543 "lang.y"
    { yyval.number = 0; }
    break;

  case 30:
#line 544 "lang.y"
    { yyval.number = TY_PRIVATE; }
    break;

  case 31:
#line 545 "lang.y"
    { yyval.number = TY_STATIC | TY_PRIVATE; }
    break;

  case 32:
#line 546 "lang.y"
    { yyval.number = TY_STATIC | TY_PRIVATE; }
    break;

  case 33:
#line 549 "lang.y"
    { yyval.number = 0; }
    break;

  case 34:
#line 550 "lang.y"
    { yyval.number = yyvsp[0].number; }
    break;

  case 37:
#line 558 "lang.y"
    { 
        /* only called when processing args */
        if (find_argument(yyvsp[0].shared))
            yyerrorf("Name \"%s\"appears twice in function parameter list\n", yyvsp[0].shared->str);
        else 
            add_argument(yyvsp[0].shared, current_type);
        yyval.number = 0;
     }
    break;

  case 38:
#line 569 "lang.y"
    { yyval.number = T_ANY; current_type = T_ANY; }
    break;

  case 39:
#line 570 "lang.y"
    { yyval.number = yyvsp[0].number; current_type = yyvsp[0].number;  }
    break;

  case 40:
#line 573 "lang.y"
    { yyval.number = yyvsp[0].number; }
    break;

  case 41:
#line 576 "lang.y"
    { yyval.number = T_NUMBER; }
    break;

  case 42:
#line 577 "lang.y"
    { yyval.number = T_STRING; }
    break;

  case 43:
#line 578 "lang.y"
    { yyval.number = T_POINTER; }
    break;

  case 44:
#line 579 "lang.y"
    { yyval.number = T_REAL; }
    break;

  case 45:
#line 580 "lang.y"
    { yyval.number = T_OBJECT; }
    break;

  case 46:
#line 581 "lang.y"
    { yyval.number = T_VOID; }
    break;

  case 47:
#line 583 "lang.y"
    {
        struct field * x;

        x = find_type(yyvsp[0].shared);
        if (x) 
        {
            yyval.number = x->type;
            free(x);
        }
        else yyval.number = 0;
    }
    break;

  case 48:
#line 596 "lang.y"
    { yyval.number = yyvsp[0].number; }
    break;

  case 49:
#line 597 "lang.y"
    { yyval.number = yyvsp[-2].number | yyvsp[0].number; }
    break;

  case 50:
#line 600 "lang.y"
    { yyval.number = 0; }
    break;

  case 51:
#line 601 "lang.y"
    { yyval.number = 0; }
    break;

  case 52:
#line 605 "lang.y"
    {
        add_global_variable(yyvsp[0].shared, current_type, 0); 
    }
    break;

  case 53:
#line 609 "lang.y"
    {
        yyval.lnode = CPD;
        CPD = initialise_func;
    }
    break;

  case 54:
#line 614 "lang.y"
    {
        int x, y;

        y = current_type | (yyvsp[-1].number << 16);
#if 0
printf("adding type %d,%d = %d\n", yyvsp[-1].number, current_type, y);
#endif
        x = add_global_variable(yyvsp[-4].shared, y, 0); 
        emit(S_PUSHC, yyvsp[-1].number);
        emits(S_ARR_ALLOC);
        emit(S_POPG, x-1);
        type_check(yyvsp[-1].number, T_ANY, T_NUMBER, "array declaration");
        CPD = yyvsp[-2].lnode;     
    }
    break;

  case 55:
#line 629 "lang.y"
    {
        yyval.lnode = CPD;
         CPD = initialise_func;
        add_global_variable(yyvsp[-1].shared, current_type, 0); 
    }
    break;

  case 56:
#line 635 "lang.y"
    {
        int x = find_global_variable(yyvsp[-3].shared);

/*        printf("Global no: %d.\n", x); */
        emit(S_POPG, x - 1);
        type_check(yyvsp[0].number, T_ANY, current_type, "global assignment");
        CPD = yyvsp[-1].lnode;     
    }
    break;

  case 57:
#line 646 "lang.y"
    {
        if (find_global_variable(yyvsp[0].shared))
            yyerrorf("Redeclaration of global variable \"%s\"\n", yyvsp[0].shared->str);
        yyval.shared = yyvsp[0].shared;
    }
    break;

  case 58:
#line 654 "lang.y"
    {
        block_depth--;
        num_locals = yyvsp[-2].number;
    }
    break;

  case 59:
#line 661 "lang.y"
    { 
        yyval.number = num_locals;
        block_depth++;        /* re-set in 'block' */
    }
    break;

  case 60:
#line 672 "lang.y"
    { current_type = yyvsp[0].number; }
    break;

  case 61:
#line 672 "lang.y"
    { yyval.number = yyvsp[-1].number; }
    break;

  case 64:
#line 679 "lang.y"
    {
        int x = add_local_variable(yyvsp[0].shared, current_type);
        emit(S_PUSH8, 0);
        emit(S_POPL, x - 1); 
     }
    break;

  case 65:
#line 685 "lang.y"
    {
     int x, y;
        y = current_type | (yyvsp[-1].number << 16);
         x = add_local_variable(yyvsp[-3].shared, y);
        emit(S_PUSHC, yyvsp[-1].number);
        emits(S_ARR_ALLOC);
        emit(S_POPL, x - 1);
     }
    break;

  case 66:
#line 694 "lang.y"
    {
        int x = add_local_variable(yyvsp[-2].shared, current_type);
        emit(S_POPL, x - 1);
     }
    break;

  case 67:
#line 701 "lang.y"
    {
        if (find_local_block(yyvsp[0].shared))
            yyerrorf("Redefinition of \"%s\" within the same block", yyvsp[0].shared->str);
        yyval.shared = yyvsp[0].shared;
     }
    break;

  case 68:
#line 709 "lang.y"
    { yyval.number = 0; }
    break;

  case 69:
#line 711 "lang.y"
    { 
        end_of_statement();
    }
    break;

  case 71:
#line 715 "lang.y"
    { yyerror("Illegal statement"); yyval.number = 0; }
    break;

  case 73:
#line 719 "lang.y"
    { yyval.number = 0; }
    break;

  case 74:
#line 720 "lang.y"
    { yyval.number = 0; }
    break;

  case 75:
#line 721 "lang.y"
    { yyval.number = 0; }
    break;

  case 76:
#line 722 "lang.y"
    { yyval.number = 0; }
    break;

  case 77:
#line 723 "lang.y"
    { yyval.number = 0; }
    break;

  case 78:
#line 724 "lang.y"
    { yyval.number = 0; }
    break;

  case 79:
#line 725 "lang.y"
    { yyval.number = 0; }
    break;

  case 81:
#line 731 "lang.y"
    { 
        emits(S_THROW);  
        yyval.number = 0; 
    }
    break;

  case 82:
#line 736 "lang.y"
    { 
        if ((LD == 0) && (switch_depth == 0)) 
        {
            yyerror("Break outside while, for, do, or switch construct.\n");
        }
        add_break_patch(CPD->current_I);
        emit16(S_JUMPU, 0);
        yyval.number = 0;
    }
    break;

  case 83:
#line 746 "lang.y"
    { 
        if (LD == 0)  
        {
            yyerror("Continue outside while, for, or do loop.\n");
        }
        emit16(S_JUMP, labelstack[LD-1] - CPD->current_I - 3);
        yyval.number = 0;
    }
    break;

  case 84:
#line 754 "lang.y"
    { yyval.number = 0; }
    break;

  case 85:
#line 759 "lang.y"
    {
        labelstack[LD++] = CPD->current_I;
        yyval.number = CPD->current_I;
    }
    break;

  case 86:
#line 764 "lang.y"
    {
         emit16(S_JZERO,0);
         yyval.number = CPD->current_I;
    }
    break;

  case 87:
#line 769 "lang.y"
    {
        end_of_statement();
        emits(S_OFLOW_CHECK);
        emit16(S_JUMP, yyvsp[-5].number - CPD->current_I - 3);  
        patch16((int)yyvsp[-1].number - 2, CPD->current_I - yyvsp[-1].number);
        do_break_patch(yyvsp[-5].number, CPD->current_I);
        LD--;
    }
    break;

  case 88:
#line 780 "lang.y"
    {
        yyval.number = CPD->current_I;
        labelstack[LD++] = CPD->current_I;
    }
    break;

  case 89:
#line 784 "lang.y"
    {
        end_of_statement();
    }
    break;

  case 90:
#line 789 "lang.y"
    {
        emits(S_OFLOW_CHECK);
        emit16(S_JNZERO, yyvsp[-7].number - CPD->current_I - 3); 
        do_break_patch(yyvsp[-7].number, CPD->current_I);
        LD--;
    }
    break;

  case 91:
#line 798 "lang.y"
    {
        yyval.number = CPD->current_I; 
    }
    break;

  case 92:
#line 802 "lang.y"
    {
        emit16(S_JZERO, 0);
        emit16(S_JUMP, 0);
        yyval.number = CPD->current_I;
        labelstack[LD++] = CPD->current_I;
    }
    break;

  case 93:
#line 809 "lang.y"
    {
        emit16(S_JUMP, yyvsp[-5].number - CPD->current_I - 3);
        patch16((int)(yyvsp[-2].number - 2), CPD->current_I - yyvsp[-2].number);
    }
    break;

  case 94:
#line 814 "lang.y"
    {
        end_of_statement();
        emits(S_OFLOW_CHECK);
        emit16(S_JUMP, yyvsp[-4].number - CPD->current_I - 3);
        patch16((int)(yyvsp[-4].number - 5), CPD->current_I - yyvsp[-4].number + 3);
        do_break_patch(yyvsp[-7].number, CPD->current_I);
        LD--;
    }
    break;

  case 95:
#line 825 "lang.y"
    { emit(S_PUSH8, 1); }
    break;

  case 97:
#line 830 "lang.y"
    {
        yyval.lnode = CPD->current_I;
    }
    break;

  case 98:
#line 834 "lang.y"
    {
        int x;    
        /* add a global *switch[X] */
        /* this will be an array ({ const, line num, const etc }) */
        x = add_global_variable(make_next_switch(),TY_STATIC|T_ANY,0);
        emit(S_SWITCH, x - 1);        /* switch on global */
        switchstack[switch_depth++] = CPD->current_I;

        /* set up the constants */
        yyval.lnode = CPD;
        CPD = initialise_func;
        emit_push(GLOBAL, x);
        CPD = yyval.lnode;
        yyval.lnode = x;
    }
    break;

  case 99:
#line 850 "lang.y"
    { 
        int x = yyvsp[-1].number, y;

        /* once we've emitted all the statements emit switch table */
        yyval.lnode = CPD;
        y = CPD->current_I - switchstack[switch_depth-1];
        CPD = initialise_func;
        x = x * 2 + 2;

        /* we don't need to emit this IF we emitted
           a default: case */
        emit(S_PUSH8, -2);    /* no match marker.. */
        emit_number(y);

        emit_cnumber(x);
        emits(S_AGGREGATE);
        emits(S_POPO);    

        CPD = yyval.lnode;
        yyval.lnode = 0;
        switch_depth--;
        do_break_patch(yyvsp[-7].number, CPD->current_I);
    }
    break;

  case 100:
#line 876 "lang.y"
    { yyval.number = 1; }
    break;

  case 101:
#line 878 "lang.y"
    { yyval.number = yyvsp[-1].number + 1; }
    break;

  case 102:
#line 882 "lang.y"
    {
#if 1
        /* record the last line */
        yyval.lnode = CPD;
        CPD = initialise_func;
#endif
    }
    break;

  case 103:
#line 891 "lang.y"
    {
#if 1
    int x;
        /* put the offset line number (next for code) */
        CPD = yyvsp[-2].lnode;
        x = CPD->current_I - switchstack[switch_depth-1];    
        CPD = initialise_func;
        emit_number(x);
        CPD = yyvsp[-2].lnode;
#endif
    }
    break;

  case 104:
#line 903 "lang.y"
    { 
        /* return line number? */
        yyval.lnode = NULL;
    }
    break;

  case 105:
#line 908 "lang.y"
    {
        /* two defaults should generate an error; it doesn't yet */
        int y;

        yyval.lnode = CPD;
        y = -(CPD->current_I-switchstack[switch_depth-1]) - 1;    
        /* number is negative so we recognise it! */
        CPD = initialise_func;
        emit(S_PUSH8, -1);    
        emit_number(y);
        CPD = yyval.lnode;
    }
    break;

  case 106:
#line 921 "lang.y"
    { 
        yyval.lnode = NULL;
    }
    break;

  case 108:
#line 928 "lang.y"
    {
         yyval.number = yyvsp[0].number;
    }
    break;

  case 109:
#line 934 "lang.y"
    { 
        emit(S_COPY, 1);
        emit(S_PUSH8, 1);
        emits(S_PLUS); 
        emit_pop(yyvsp[0].number);
        type_check(yyvsp[0].number, T_ANY, T_NUMBER, "pre ++");
        yyval.number = yyvsp[0].number; 
    }
    break;

  case 110:
#line 943 "lang.y"
    {
        emit(S_COPY, 1);
        emit(S_PUSH8, -1);
        emits(S_PLUS); 
        emit_pop(yyvsp[0].number);
        type_check(yyvsp[0].number, T_ANY, T_NUMBER, "pre --");
        yyval.number = yyvsp[0].number;
    }
    break;

  case 111:
#line 955 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_POINTER, "pattern assignment");
        yyval.number = yyvsp[-2].number;

        /* for each element in pattern assign nth element of $3 */
        /* allow tail match for 'rest'? */
    }
    break;

  case 112:
#line 964 "lang.y"
    { 
        type_check(yyvsp[-2].number, yyvsp[0].number, T_ANY, "variable assignment");
        yyval.number = yyvsp[-2].number;
        emit_pop(yyvsp[-2].number);
    }
    break;

  case 113:
#line 970 "lang.y"
    {
        emit(S_COPY, 1);    
    }
    break;

  case 114:
#line 974 "lang.y"
    {
        type_check(yyvsp[-3].number, yyvsp[0].number, T_ANY, "variable op= assignment");
        yyval.number = yyvsp[-3].number;
        emits(yyvsp[-1].number); 
        emit_pop(yyvsp[-3].number);
    }
    break;

  case 115:
#line 981 "lang.y"
    {
        emit16(S_CATCH, 0);
        yyval.number = CPD->current_I;
    }
    break;

  case 116:
#line 986 "lang.y"
    { 
        end_of_statement();
        /* back patch the correct line */
        emits(S_POPCATCH);
        patch16(yyvsp[-1].number - 2, CPD->current_I - yyvsp[-1].number);
        yyval.number = T_ANY;
    }
    break;

  case 117:
#line 994 "lang.y"
    {
         emit16(S_JZERO, 0);
         yyval.number = CPD->current_I;
        /* $$ is just after jmp offset  */
    }
    break;

  case 118:
#line 1000 "lang.y"
    {

          emit16(S_JUMP, 0);
          yyval.number = CPD->current_I;
          patch16((int)yyvsp[-1].number - 2, CPD->current_I - yyvsp[-1].number);
    }
    break;

  case 119:
#line 1007 "lang.y"
    {
        patch16((int)yyvsp[-2].number - 2, CPD->current_I - yyvsp[-2].number); 
        type_check(yyvsp[-3].number,  yyvsp[0].number, T_ANY, "conditional operator");
        yyval.number = yyvsp[-3].number;    
    }
    break;

  case 120:
#line 1013 "lang.y"
    {
        emit(S_COPY, 1);
        emit(S_PUSH8, 1);
        emits(S_PLUS);
        emit_pop(yyvsp[-1].number);
        emit(S_PUSH8, 1);
        emits(S_MINUS);
        type_check(yyvsp[-1].number, T_ANY, T_NUMBER, "post inc");
        yyval.number = yyvsp[-1].number;
    }
    break;

  case 121:
#line 1024 "lang.y"
    {
        emit(S_COPY, 1);
        emit(S_PUSH8, 1);
        emits(S_MINUS);
        emit_pop(yyvsp[-1].number);
        emit(S_PUSH8, 1);
        emits(S_PLUS);
        type_check(yyvsp[-1].number, T_ANY, T_NUMBER, "post dec");
        yyval.number = yyvsp[-1].number;
    }
    break;

  case 122:
#line 1034 "lang.y"
    { yyval.number = yyvsp[0].number; }
    break;

  case 123:
#line 1039 "lang.y"
    {
        emit_cnumber(yyvsp[-1].number);
        emits(S_AGGREGATE);
        yyval.number = T_POINTER;
    }
    break;

  case 124:
#line 1046 "lang.y"
    {
        emit_cnumber(yyvsp[-1].number);
        emits(S_AGGREGATE);
        yyval.number = T_POINTER;
    }
    break;

  case 125:
#line 1051 "lang.y"
    { yyval.number = yyvsp[0].number; }
    break;

  case 126:
#line 1053 "lang.y"
    {
        struct field * x;
        x = find_type(yyvsp[0].shared);

        if (x) 
        {
            emit(S_PUSH8, x->offset);
            emit(S_PUSHC, 1);
            emits(S_ARR_ALLOC);
            yyval.number = x->type;
            free(x);
        }
    }
    break;

  case 127:
#line 1067 "lang.y"
    { yyval.number = yyvsp[-1].number; }
    break;

  case 129:
#line 1070 "lang.y"
    { 
        emit(S_PUSH8, 0); 
    }
    break;

  case 130:
#line 1074 "lang.y"
    {
        /* emits(S_EXTRACT);  */
        emit(S_EFUND, F_EXTRACT);
        type_check(yyvsp[-5].number, T_ANY,  T_POINTER|T_STRING, "extract arg 1");
        type_check(yyvsp[-1].number, T_ANY,  T_NUMBER, "extract arg 3");
        yyval.number = yyvsp[-5].number;
    }
    break;

  case 131:
#line 1082 "lang.y"
    {     
        int x = INT_MAX;
        emit32(S_PUSHi, (char *)&x);
        /* emits(S_EXTRACT); */
        emit(S_EFUND, F_EXTRACT);
        type_check(yyvsp[-4].number, T_ANY,  T_POINTER|T_STRING, "extract arg 1");
        type_check(yyvsp[-2].number, T_ANY,  T_NUMBER, "extract arg 2");
        yyval.number = yyvsp[-4].number;
    }
    break;

  case 132:
#line 1092 "lang.y"
    { 
          /* emits(S_EXTRACT);  */
        emit(S_EFUND, F_EXTRACT);
        type_check(yyvsp[-5].number, T_ANY,  T_POINTER|T_STRING, "extract arg 1");
        type_check(yyvsp[-3].number, T_ANY,  T_NUMBER, "extract arg 2");
        type_check(yyvsp[-1].number, T_ANY,  T_NUMBER, "extract arg 3");
        yyval.number = yyvsp[-5].number;
    }
    break;

  case 133:
#line 1101 "lang.y"
    {
        emit(S_COPY, 1);
        emit16(S_JNZERO, 0);
        yyval.number = CPD->current_I;
    }
    break;

  case 134:
#line 1107 "lang.y"
    {
           /* type_check($1, $4, T_ANY); */
        yyval.number = T_NUMBER;
        emits(S_LOR);
        patch16(yyvsp[-1].number -2, CPD->current_I - yyvsp[-1].number);
    }
    break;

  case 135:
#line 1114 "lang.y"
    { 
        emit(S_COPY, 1);
        emit16(S_JZERO, 0); 
        yyval.number = CPD->current_I;
    }
    break;

  case 136:
#line 1120 "lang.y"
    { 
        /* type_check($1, $4, T_ANY); */
        yyval.number = T_NUMBER;
        emits(S_LAND); 
        patch16(yyvsp[-1].number -2, CPD->current_I - yyvsp[-1].number);
    }
    break;

  case 137:
#line 1127 "lang.y"
    { 
        type_check(yyvsp[-2].number, yyvsp[0].number, T_NUMBER, "arithmetic or");
        yyval.number = yyvsp[-2].number;
        emits(S_OR); 
    }
    break;

  case 138:
#line 1133 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_NUMBER, "arithmetic xor");
        yyval.number = yyvsp[-2].number;
        emits(S_XOR); 
    }
    break;

  case 139:
#line 1139 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_NUMBER, "arithmetic and");
        yyval.number = yyvsp[-2].number;
        emits(S_AND); 
    }
    break;

  case 140:
#line 1145 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_ANY, "equals");
        yyval.number = T_NUMBER;
        emits(S_EQ); 
    }
    break;

  case 141:
#line 1151 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_ANY, "not equals");
        yyval.number = T_NUMBER;
        emits(S_NE); 
    }
    break;

  case 142:
#line 1157 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_STRING|T_REAL|T_NUMBER, ">");
        yyval.number = T_NUMBER;
        emits(S_GT);
    }
    break;

  case 143:
#line 1163 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_STRING|T_REAL|T_NUMBER, ">=");
        yyval.number = T_NUMBER;
        emits(S_GE);
    }
    break;

  case 144:
#line 1169 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_STRING|T_REAL|T_NUMBER, "<");
        yyval.number = T_NUMBER;
        emits(S_LT);
    }
    break;

  case 145:
#line 1175 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_STRING|T_REAL|T_NUMBER, "<=");
        yyval.number = T_NUMBER;
        emits(S_LE);
    }
    break;

  case 146:
#line 1181 "lang.y"
    {
        type_check(yyvsp[-2].number, yyvsp[0].number, T_NUMBER, "lsh");
        yyval.number = T_NUMBER;
        emits(S_LSH);
    }
    break;

  case 147:
#line 1187 "lang.y"
    { 
        type_check(yyvsp[-2].number, yyvsp[0].number, T_NUMBER, "rsh");
        yyval.number = T_NUMBER;
        emits(S_RSH);
    }
    break;

  case 148:
#line 1193 "lang.y"
    {
    /* const fix hack should do constant check on last 2 pushes,
       if both strings or numbers then add them remove 2 instrs
       and add the new push */
        if (!constant_fold(S_PLUS)) {
        emits(S_PLUS);
        type_check(yyvsp[-2].number,T_ANY,T_REAL|T_NUMBER|T_STRING|T_POINTER, "plus");
        type_check(yyvsp[0].number,T_ANY,T_REAL|T_NUMBER|T_STRING|T_POINTER, "plus");
        if ((yyvsp[-2].number & T_POINTER) || (yyvsp[0].number & T_POINTER)) {
            if (!(yyvsp[-2].number & yyvsp[0].number)) yyerror("Illegal array addition\n");
        }
        yyval.number = (yyvsp[-2].number > yyvsp[0].number) ? yyvsp[-2].number : yyvsp[0].number;
        }
    }
    break;

  case 149:
#line 1208 "lang.y"
    { 
        if (!constant_fold(S_MINUS)) {
            emits(S_MINUS);
            type_check(yyvsp[-2].number, yyvsp[0].number, T_REAL|T_NUMBER, "minus");
            yyval.number = yyvsp[-2].number;
        }
    }
    break;

  case 150:
#line 1216 "lang.y"
    {
    /*    if (!constant_fold(S_MULT)) */
        emits(S_MULT);
        type_check(yyvsp[-2].number, yyvsp[0].number, T_REAL|T_NUMBER, "multiply");
        yyval.number = yyvsp[-2].number;
    }
    break;

  case 151:
#line 1223 "lang.y"
    {    
    /*    if (!constant_fold(S_MOD)) */
        emits(S_MOD);
        type_check(yyvsp[-2].number, yyvsp[0].number, T_NUMBER, "modulo");
        yyval.number = yyvsp[-2].number;
    }
    break;

  case 152:
#line 1230 "lang.y"
    {
    /*    if (!constant_fold(S_DIVIDE))  */
        emits(S_DIVIDE);
        type_check(yyvsp[-2].number, yyvsp[0].number, T_REAL|T_NUMBER, "divide");
        yyval.number = yyvsp[-2].number;
    }
    break;

  case 154:
#line 1238 "lang.y"
    {
        emits(S_LNOT); 
        yyval.number =  T_NUMBER;
    }
    break;

  case 155:
#line 1243 "lang.y"
    {
        type_check(yyvsp[0].number, T_ANY, T_NUMBER, "arithmetic not");
        yyval.number = T_NUMBER;
        emits(S_NOT); 
    }
    break;

  case 156:
#line 1249 "lang.y"
    {
        type_check(yyvsp[0].number, T_ANY, T_NUMBER | T_REAL, "negate");
        yyval.number = yyvsp[0].number;
#if 1
        if (uinstr == S_PUSH8) {
        char x;
            x = -(CPD->block[CPD->current_I-1]);
            CPD->block[CPD->current_I-1] = x;
        }
        /* should also do PUSHi & PUSHr */
        else
#endif
         emits(S_NEGATE);
    }
    break;

  case 158:
#line 1266 "lang.y"
    { yyval.number = S_AND; }
    break;

  case 159:
#line 1267 "lang.y"
    { yyval.number = S_OR; }
    break;

  case 160:
#line 1268 "lang.y"
    { yyval.number = S_XOR; }
    break;

  case 161:
#line 1269 "lang.y"
    { yyval.number = S_LSH; }
    break;

  case 162:
#line 1270 "lang.y"
    { yyval.number = S_RSH; }
    break;

  case 163:
#line 1271 "lang.y"
    { yyval.number = S_PLUS; }
    break;

  case 164:
#line 1272 "lang.y"
    { yyval.number = S_MINUS; }
    break;

  case 165:
#line 1273 "lang.y"
    { yyval.number = S_MULT; }
    break;

  case 166:
#line 1274 "lang.y"
    { yyval.number = S_MOD; }
    break;

  case 167:
#line 1275 "lang.y"
    { yyval.number = S_DIVIDE; }
    break;

  case 168:
#line 1279 "lang.y"
    {
        emit(S_PUSH8, 0); 
        emits(S_RETURN);
    }
    break;

  case 169:
#line 1284 "lang.y"
    { 
        type_check(yyvsp[0].number, T_ANY, CPD->type, "return type of function");
        emits(S_RETURN); 
    }
    break;

  case 170:
#line 1290 "lang.y"
    { yyval.number = 0; }
    break;

  case 171:
#line 1291 "lang.y"
    { yyval.number = 1; }
    break;

  case 172:
#line 1292 "lang.y"
    { yyval.number = yyvsp[-2].number + 1; }
    break;

  case 173:
#line 1297 "lang.y"
    {
        penultima.s = ultima.s;
        ultima.s = yyvsp[0].lexstr;
        yyval.number = T_STRING;
    }
    break;

  case 174:
#line 1303 "lang.y"
    {
        penultima.i = ultima.i;
        ultima.i = yyvsp[0].number;
        if (!(yyvsp[0].number)) yyval.number = T_ANY;    /* zero hack :( */
        else yyval.number = T_NUMBER;
    }
    break;

  case 175:
#line 1310 "lang.y"
    {
/*
        penultima.r = ultima.r;
        ultima.r = $<real>1;
        $$ = $<real>1;
*/
        yyval.number = T_REAL;
    }
    break;

  case 176:
#line 1321 "lang.y"
    {
        yyval.val = share_Cstring(to_Cstring((lexar *)yyvsp[0].string));
    }
    break;

  case 177:
#line 1325 "lang.y"
    {
        yyval.val = alloc_value();
        yyval.val->type = T_NUMBER;
        yyval.val->u.number = yyvsp[0].number;
    }
    break;

  case 178:
#line 1331 "lang.y"
    {
        yyval.val = alloc_value();
        yyval.val->type = T_NUMBER;
        yyval.val->u.number = - yyvsp[0].number;
    }
    break;

  case 179:
#line 1337 "lang.y"
    {
        yyval.val = alloc_value();
        yyval.val->type = T_REAL;
        yyval.val->u.number = yyvsp[0].number;
    }
    break;

  case 180:
#line 1343 "lang.y"
    {
        yyval.val = alloc_value();
        yyval.val->type = T_REAL;
        yyval.val->u.number = - yyvsp[0].number;
    }
    break;

  case 181:
#line 1349 "lang.y"
    {
        Val * x;

        if ((x = find_constant(yyvsp[0].shared)))
        {
/*        printf("Global no: %d.\n", $$); */
            yyval.val = alloc_value();
            // FIX: look up global
            assign_value(yyval.val, x);
        }
        else
        {
            yyerror("Only constant values maybe used in switch expressions\n");
        }
    }
    break;

  case 182:
#line 1370 "lang.y"
    {  
        int x;
        Val * v;

        if ((x = find_local_variable(yyvsp[0].shared))) 
        {
            emit_push(LOCAL, x-1);
        }
        else if ((x = find_argument(yyvsp[0].shared))) 
        {
            emit_push(LOCAL, x);
        }
        else if ((x = find_global_variable(yyvsp[0].shared))) 
        {
            emit_push(GLOBAL, x);
/*        printf("Global no: %d.\n", $$); */
        }
        else if ((v = find_constant(yyvsp[0].shared))) 
        {
            /* what should we do? */
            emit_constant(v);
        }
        else
        {
             yyerrorf("Identifier %s used but not declared", yyvsp[0].shared->str);
        }
        yyval.number = last_type;
    }
    break;

  case 183:
#line 1399 "lang.y"
    { 
        int t, r;
        /* ADDIND should typecheck too! */
        emits(S_ADDIND);
        yyval.number = 0;
        type_check(yyvsp[-1].number, T_ANY, T_NUMBER, "array access arg 2");
        t = (yyvsp[-3].number & 0x00ff0000) >> 16;
        if (!t) {
            if (yyvsp[-3].number & 0xff000000)
                yyerror("Non class accessed\n");
            else {
                yyval.number = T_ANY;
                type_check(yyvsp[-3].number,T_ANY,T_POINTER|T_STRING,
                 "array access arg 1");
            }
        }
        else {
            r = yyvsp[-3].number & 0xff00ffff;
            t--;
            yyval.number = (t << 16) | r;
        }
    }
    break;

  case 184:
#line 1422 "lang.y"
    {
        struct field * x;

        x = find_type_info(yyvsp[-2].number, yyvsp[0].shared);
        if (x) {
            emit(S_PUSH8, x->offset);
            emits(S_ADDIND);
            type_check(yyvsp[-2].number, T_ANY, T_POINTER, "class access arg 1");
            yyval.number = x->type;
            free(x);
        }
        else yyval.number = 0;
    }
    break;

  case 189:
#line 1449 "lang.y"
    { 
        yyval.number = 0; 
        yyerror("pattern matching unimplemented\n");
    }
    break;

  case 190:
#line 1456 "lang.y"
    {    /* blech */
        add_patch(CPD, P_STRING, yyvsp[0].lexstr);
        emit32(S_PUSHs, zero);
/*        $<lexstr>$ = (lexstr *)p; */
        yyval.lexstr = yyvsp[0].lexstr;
    }
    break;

  case 191:
#line 1466 "lang.y"
    { yyval.number = yyvsp[-1].number; }
    break;

  case 192:
#line 1471 "lang.y"
    {
        Keyword * x = NULL;

        x = lookup_emulate(yyvsp[0].shared);

        /* ugly cast */
        if (!x) x = (Keyword *) lookup_predef(yyvsp[0].shared->str);

        if (x && (x->token == F_EMULATE)) 
        {
            Shared * v;

            /* make it a call_other to Emulate.. */
            /* argh need a S_PUSHo opcode now..  */
            v = string_copy(EMULATE_EFUN);
/*            add_patch(CPD, P_CSTRING, v);  */
            emit32(S_PUSHs, (char *) &(v));
            // v = shared_string_copy($1);
/*            add_patch(CPD, P_CSTRING, v);  */
            // emit32(S_PUSHs, (char *) &(v));
        }
        else if (!x || (x && (x->token != F_CALL_OTHER))) {
            emit(S_PUSH8, 0); /* dummy this_object() */
        }
        yyval.number = x;
    }
    break;

  case 193:
#line 1498 "lang.y"
    { 
        Keyword * x;
        int p, n;

        x = (Keyword *)yyvsp[-1].string;
        if (x != NULL) 
        {
            /* check the no. of parameters is correct */
            p = x->params;
            if (p > 0) 
            {
                n = yyvsp[0].number;
                while (n < p) 
                {
                    emit(S_PUSH8, 0);
                    n++;
                }
                if (n > p) 
                {
                    emit(S_ADDSP, n - p);
                }    
            }
            else if (p == -1) 
            {    
                /* it has variable params.. */
                emit(S_PUSHC, yyvsp[0].number);    /* no of params */
            }
            if (x->token == F_CALL_OTHER) 
            {
                /* special case for call_other efun() */
                byte n = yyvsp[0].number - 2;
                /* patch no of args to be correct */
                if (yyvsp[0].number < 2) {
                     yyerror("Not enough args to call_other()");
                }
                /* adjust number of params */
                CPD->block[CPD->current_I-1] = n;
                emits(S_CALLOF);
            }
            else if (x->token == F_EMULATE) 
            {
                Shared * ss = shared_string_copy(yyvsp[-2].shared);

                emit(S_PUSHC, yyvsp[0].number);
                /* string should be added to patch list */
                /*        add_patch(CPD, P_CSTRING, x); */
                emit32(S_CALLO, (char *)&(ss));
                free(x);    
            }
            else 
            {
                emit(S_EFUN, (char)x->token);    
            }
        }
        else 
        {
            /* It's a local function call. */
            Shared * v;

            emit(S_PUSHC, yyvsp[0].number);
            emit(S_PUSHC, 0);
            emit(S_ADDSP, 0);    /* varargs fix - blech */
            v = shared_string_copy(yyvsp[-2].shared);
            add_patch(CPD, P_CALLU, v);
            emit32(S_CALLU, (char *)&(v)); 
        }          
        /*
         * check function calls later 
         * should be able to do this without
         * checking the function list again 
         */
        yyval.number = T_ANY;
     }
    break;

  case 194:
#line 1572 "lang.y"
    {
        Shared * x = shared_string_copy(yyvsp[-1].shared);

        emit(S_PUSHC, yyvsp[0].number);
        /* string should be added to patch list */
/*        add_patch(CPD, P_CSTRING, x); */
        emit32(S_CALLO, (char *)&(x)); 
        yyval.number = T_ANY;
    }
    break;

  case 195:
#line 1582 "lang.y"
    {
        /* need to dup expr4 */
        emit(S_PUSHC, yyvsp[0].number);
        emits(S_CALLOF); 
        yyval.number = T_ANY;
    }
    break;

  case 196:
#line 1591 "lang.y"
    { yyval.shared = yyvsp[0].shared; }
    break;

  case 197:
#line 1593 "lang.y"
    {
        /* are the following space leaks? (or fuck up counts anyway?) */
        /* perhaps all should use string_copy and we should free elsewhere. */
        Shared * t = to_Cstring(yyvsp[-2].lexstr);
        char *p = (char *)malloc(yyvsp[0].shared->length + t->length + 3);

        strcpy(p, t->str); strcat(p, "::"); strcat(p, yyvsp[0].shared->str);
        yyval.shared = string_copy(p);
        free_string(t);
        free(yyvsp[-2].string);
        free(p);
    }
    break;

  case 198:
#line 1606 "lang.y"
    {
        char *p = (char *)malloc(yyvsp[0].shared->length + 3);
        strcpy(p, "::"); strcat(p, yyvsp[0].shared->str);
        yyval.shared = string_copy(p);
        free(p);
    }
    break;

  case 199:
#line 1616 "lang.y"
    {
        patch16((int)yyvsp[-1].number - 2, CPD->current_I - yyvsp[-1].number);
    }
    break;

  case 200:
#line 1622 "lang.y"
    {
        emit16(S_JUMP, 0);
        patch16((int)yyvsp[-2].number - 2, CPD->current_I - yyvsp[-2].number);
        yyval.number = CPD->current_I;
    }
    break;

  case 201:
#line 1628 "lang.y"
    {
        patch16((int)yyvsp[-1].number - 2, CPD->current_I - yyvsp[-1].number);
    }
    break;

  case 202:
#line 1634 "lang.y"
    {
        emit16(S_JZERO, 0);
        yyval.number = CPD->current_I;
    }
    break;

  case 203:
#line 1641 "lang.y"
    {
        yyval.shared = string_copy(yyvsp[0].string);
    }
    break;


    }

/* Line 999 of yacc.c.  */
#line 3574 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("syntax error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyss < yyssp)
	    {
	      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
	      yydestruct (yystos[*yyssp], yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
      yydestruct (yytoken, &yylval);
      yychar = YYEMPTY;

    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      yyvsp--;
      yystate = *--yyssp;

      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 1645 "lang.y"


int defined_function(Shared *s)
{
    Func *p;

    for(p = prog_head; p; p = p->next) 
    {
        if (p->name == s) return 1;
    }
    return 0;
} 

/*
 *   All the code below here is 
 *   Copyright (C), Geoff Wong, June 1993.
 *   geoff@serc.rmit.edu.au
 */

int inherited_globals = 0;

void init_globals()
{
int i;
    inherited_globals = 0;
#if 1
    if (inherit_ob == NULL) return;
    for (i = 0; inherit_ob[i]; i++) {
        inherited_globals += inherit_ob[i]->num_variables;
    }
#endif
}


/* tail insertion */
int add_global_variable(Shared * s, int type, Val * val)
{
    struct var_def *t;

    if (lang_debug) printf("D: add global %s\n", s->str);
    t = (struct var_def *)malloc(sizeof(struct var_def));
    t->name = shared_string_copy(s);
    if (!type) type = 1;
    t->type = type;
    t->next = 0;
    t->v = val;
    if (!global_head) 
    {
        global_tail = t;
        global_head = t;
    }
    else {
        global_tail->next = t;
        global_tail = t;
    }
    if (type & TY_CONSTANT) {
        num_constants++;
    }
    else num_globals++;
    return num_globals + inherited_globals;
}

int find_global_variable(Shared * s)
{
    struct var_def *t = global_head;

    int d = 0, i, j, count = 1;

    while (t) 
    {
        if ((t->type & TY_CONSTANT) == 0) 
        {
            d++;
            if (t->name == s) 
            {
/*              printf("find_global %s\n", t->name);  */
                last_type = t->type & 0xffff00ff;
                /* get rid of static */
                return d + inherited_globals;
            }
         }
         t = t->next;
    }
#if 1    /* if we want to access inherited vars directly */
    if (!inherit_ob) return 0;

    /* all globals are copied into each level of the object */
    for (i = 0; inherit_ob[i]; i++) 
    {
        for (j = 0; j < inherit_ob[i]->num_variables; j++) 
        {
            if (inherit_ob[i]->global_table[j]->u.string == s) 
            {
                last_type = inherit_ob[i]->global_table[j]->type;
                return count;
            }
            count++;
        }
    }
#endif
    return 0;
}

Val * find_constant(Shared * s)
{
    struct var_def *t = global_head;
    Val * v;

    while (t) 
    {
        if (t->name == s && (t->type & TY_CONSTANT)) 
        {
/*            printf("find_constant %s\n", t->name);  */
            last_type = t->type & 0xffff00ff;
                     /* get rid of static (const etc) */
            return t->v;
        }
        t = t->next;
    }    
    if (!inherit_ob) return 0;
    /* have to recurse into the objects */
    
    v = find_const2(inherit_ob, s->str);
    return v;
}

Val * find_const2(Class ** io, char *s)
{
    int i, j;
    Val * v;

    for (i = 0; io[i]; i++) 
    {
        for (j = 0; j < io[i]->num_constants; j++) {
            if (!strcmp(io[i]->constant_table[j]->name->str,s)) 
            {
                last_type =
                      io[i]->constant_table[j]->type;
                return io[i]->constant_table[j]->val;
            }
        }
        if (io[i]->inherit) {
            v = find_const2(io[i]->inherit, s);
            if (v) return v;    
        }
    }
    return 0;
}

void make_global_tables()
{
    struct var_def *t = global_head, *x;
    int d = 0, ct = 0;
    Val **table;
    CVal ** consttable;

#if 0
printf("%s : num = %d\n", current_file, num_globals);
#endif

    if (!num_globals) table = 0; 
    else table = (Val **)malloc(sizeof(Val *) * num_globals + 1);
    if (!num_constants) consttable = 0;
    else consttable = (CVal **)malloc(sizeof(CVal *) * num_constants + 1);
    while (t && (d < num_globals || ct < num_constants)) 
    {
        if (t->type & TY_CONSTANT) {
            consttable[ct++] = 
                make_const(t->name, t->v, t->type);
        } 
        else {
            table[d++] = share_Cstring(t->name);
            table[d-1]->type = t->type;    
        }
        x = t;
        t = t->next;
        free(x);
    }
    global_table = table;
    constant_table = consttable;
    return;
}

/* arguments name stuff */
/* head insertion */

int find_argument(Shared *s)
{
    int d;
    struct var_def *t = arg_head;
    d = 0;

    while (t && d < num_args) 
    {
        d++;
        if (t->name == s) 
        {
            last_type = t->type;
            return -d;
        }
        t = t->next;
    }    
    return 0;
}

int add_argument(Shared * s, int type)
{
    struct var_def *t;

    if (lang_debug)    printf("D: add argument %s\n", s->str);

    t = (struct var_def *)malloc(sizeof(struct var_def));
    t->name = s;
    t->v = 0;
    t->next = arg_head;
    t->type = type;
    arg_head = t;
    num_args++;
    return num_args;
}

/* head insertion for locals. */
int add_local_variable(Shared * s, int type)
{
    struct var_def *t;

    if (lang_debug) printf("D: add local %s\n", s->str);

    t = (struct var_def *)malloc(sizeof(struct var_def));
    t->name = s;
    t->next = local_head;
    t->v = 0;
    t->type = type;
    local_head = t;
    num_locals++;
    max_locals++;
    num_block_locals[block_depth]++;
    return max_locals;
}

int find_local_variable(Shared * s)
{
    struct var_def *t;
    int d = max_locals;

    t = local_head;
#if 0
    while (t && d > num_locals) {
        d--;    
        t = t->next;
    }
#endif
        while (t && d > 0) {
        if (t->name == s) {
/*            printf("find_local %s\n", t->name); */
            last_type = t->type;
            return d;
        }
        t = t->next;
        d--;
        }    
    return 0;
}

int find_local_block(Shared * s)
{
    struct var_def *t;
    int d = max_locals, i = 0;

    t = local_head;
    while (t && d > num_locals) 
    {
        d--;    
        t = t->next;
    }
    while (t && i < num_block_locals[block_depth]) 
    {
        i++;
        d--;
        if (t->name == s) return d;
        t = t->next;
    }
    return 0;
}

void free_locals()
{
    struct var_def *x, *t = local_head;

    while (t) 
    {
        x = t;
        t = t->next;
        free(x);
    }
    t = arg_head;
    while (t) 
    {
        x = t;
        t = t->next;
        free(x);
    }
    local_head = 0;
    arg_head = 0;
}

int constant_fold(int type)
{
    int size = 10, flag = 0, r;

    if (type == S_PLUS) 
    {
        if (puinstr == S_PUSHs &&
            uinstr == S_PUSHs) 
        {
#if 0
        return 0;
printf("constant fold %s + %s\n", penultima.s,
                ultima.s;
#endif
            /* should this ever happen?? */
            if (!penultima.s || !ultima.s) return 0;

            lex_strcat(penultima.s, ultima.s);

            /* nuke off folded instructions */
                CPD->current_I = CPD->current_I - size;

            /* need to nuke off last 2 from patch list */
            remove_patch(CPD);
            remove_patch(CPD);

#if 0
            Patch *old; 

            old = ((Patch *)CPD->patch);
            CPD->patch = (char **)((Patch *)CPD->patch)->next->next;
            CPD->num_str = CPD->num_str - 2;
            free(old->next);
            free(old);
#endif

            add_patch(CPD, P_STRING, penultima.s);
            emit32(S_PUSHs, zero);

            ultima.s = penultima.s;
            penultima.s = 0;
            return 1;
        }
    }
    return 0;
    
    if ( (puinstr == S_PUSHi && uinstr == S_PUSH8) ||
         (puinstr == S_PUSH8 && uinstr == S_PUSHi) ) {
        size = 7;
        flag = 1;
    }
    if  (puinstr == S_PUSH8 && uinstr == S_PUSH8) {
        size = 4;
        flag = 1;
    }
    
    if (flag || (puinstr == S_PUSHi &&
            uinstr == S_PUSHi)) {
        switch(type)
        {    
        case S_PLUS:
        r = ultima.i + penultima.i;
#if 0
printf("constant fold %d + %d in %s\n", penultima.i, ultima.i, current_file);
#endif
        break;
        case S_MULT:
        r = penultima.i * ultima.i;
        break;
        case S_DIVIDE:
        r = penultima.i / ultima.i;
        break;
        case S_MOD:
        r = penultima.i % ultima.i;
        break;
        case S_MINUS:
        r = penultima.i - ultima.i;
        default:
            break;
        }
        CPD->current_I = CPD->current_I - (short)size;
        if (r <= MAXFIXEDINT && r >= MINFIXEDINT)
        {
                 emit(S_PUSH8, r);
        }
        else 
        { 
            emit32(S_PUSHi, (char *)&r);
        }
        puinstr = 0;
        ultima.i = r;
        penultima.i = 0;
        return 1;
    }

#if 0
    if (CPD->block[p-11] == S_PUSHr &&
            CPD->block[p-6] == S_PUSHr) {
        switch(type)
        {    
        case S_PLUS:
        z = ultima.r + penultima.r;
        break;
        case S_MULT:
        z = ultima.r * penultima.r;
        break;
        case S_DIVIDE:
        z = ultima.r / penultima.r;
        break;
        case S_MOD:
        yyerror("Illegal modulo on type real.\n");
        break;
        case S_MINUS:
        z = ultima.r - penultima.r;
        break;
        default:
            break;
        }
        CPD->current_I = CPD->current_I - size;
        emit32(S_PUSHr, (char *)&z);
        return 1;
    }
#endif
    return 0;
}

int type_check(int a, int b, int c, char * where)
{
    return 1;
/* FIX: ALERT:  this isn't correct for pointer offsets and structs */
      if (!(a & b)) {
              yyerrorf("Types don't match in %s\n", where);
#if 0
        fprintf(stderr,"NM on a "); print_type(a);
        fprintf(stderr,"NM on b "); print_type(b);
#endif
              return 0;
      }
      if (!(a & c)) {
#if 0
printf("type expr = %d\n", a);
        fprintf(stderr,"IT on a "); print_type(a);
#endif
              yyerrorf("Illegal type present in %s\n", where);
              return 0;
      }
      return 1;
}

void print_type(int x)
{
    switch (x) {
        case T_NUMBER:
            fprintf(stderr,"type integer\n");
            break;
        case T_REAL:
            fprintf(stderr,"type real\n");
            break;
        case T_POINTER:
            fprintf(stderr,"type pointer\n");
            break;
        case T_OBJECT:
            fprintf(stderr,"type object\n");
            break;
        case T_ANY:
            fprintf(stderr,"type any\n");
            break;
        case T_STRING:
            fprintf(stderr,"type string\n");
            break;
        default:    
            fprintf(stderr,"Unknown type %d\n", x);
            break;
    }
            
}

typedef struct TL 
{
    Shared * name;
    Class * obj;
} Type_list;

#define MAX_CLASSES 16 /* I know - small to start with 
            but hey this many unloaded classes would fuck up! */

Type_list * type_list[MAX_CLASSES];

void
add_type_list(Shared * name, Class * code)
{
    Type_list * tmp;

    tmp = (Type_list *) malloc (sizeof(Type_list));
    tmp->name = name;
    tmp->obj = code;
    type_list[no_of_classes] = tmp;
    no_of_classes++;
}


//    we overload struct field (blech!)
//    using offset for the size we want
struct field *
find_type(Shared * name)
{
    struct field * tmp;
    int i;

#if 0
    printf("find_type\n");
#endif

    for (i = 0; i < no_of_classes; i++) 
    {
        if (type_list[i]->name == name) 
        {
            tmp = (struct field *)malloc(sizeof(struct field));
            tmp->offset = type_list[i]->obj->num_variables;
            tmp->type = ((i+1) << 24) | T_POINTER;
            return tmp;
        }
    }
    yyerrorf("No such class: %s imported.\n", name->str);
    return 0;
}

/*
    returns a struct of "offset" and type of offset 
*/
struct field * find_type_info(unsigned int typestuff, Shared * fieldname)
{
    unsigned int classnum;
    struct field * tmp;
    Class * tobj;
    int i;

    if (typestuff & 0x00ff0000) 
    {
        yyerror("Type error accessing an array as a class.\n");
        return 0;
    }
    classnum = ((typestuff & 0xff000000) >> 24) -1 ;

    if (classnum >= no_of_classes) 
    {
        yyerror("Failed to resolve class type correctly.\n");
        return 0;
    }
    tmp = (struct field *)malloc(sizeof(struct field));
#if 0
    printf("find_type_info %d.\n", classnum);
#endif
    tobj = type_list[classnum]->obj;    
/*    printf("find_type_info: %s.\n", tobj->name); */

    for (i = 0; i < (int)tobj->num_variables; i++) 
    {
#if 0
        printf("type info: %s\n", tobj->global_table[i]->u.string);
#endif
        if (tobj->global_table[i]->u.string == fieldname) 
        {
            tmp->offset = i;
            tmp->type = tobj->global_table[i]->type & 0xff;
            return tmp;
        }
    }    
    yyerrorf("Unknown fieldname used in class %s.\n", tobj->name->str);
    return 0;
}

/*
    The emulate file contains emulation functions only at
    the "top" level (inherited files do not have their functions
    added to the emulation).

    (this could be changed using "find_program" - but this
     has other side effects and is slow compared to 1 hash lookup).

    Should return 0 if the fun is "::<something>"
    so we can do direct calls to the driver and ignore the
    simulated efuns.
*/


struct keyword * lookup_emulate(Shared * fun)
{
    struct keyword * retval;
    Func * pr = 0;

    if (!Emulate) return NULL;

    pr = Hfunction(fun, Emulate->name);
    if (!pr) return 0;
    retval = (struct keyword *) malloc(sizeof(struct keyword));
    retval->word = pr->name;
    retval->token = (short)F_EMULATE;
    retval->params = -1;
    return retval;
}

void end_of_statement()
{
    if (uinstr == S_POPI) 
    {
        CPD->block[CPD->current_I-1] = S_POPO;
        uinstr = S_POPI;
    }
}

