
/*
** $Id: yyerror.c,v 1.2 2001/10/08 14:25:59 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/lpc/yyerror.c,v $
** $Revision: 1.2 $
** $Date: 2001/10/08 14:25:59 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include <stdio.h>
#include <stdarg.h>

#include "stack.h"
#include "lpc.h"

#define MAX_ERR 2048
#define SLOP 256

extern char * current_file;
extern int current_line;

extern int uinstr, puinstr;

void yyerrord(const char * str, int line)
{
    extern int LPC_parse_errors;
    extern Shared * LPC_error_buffer[];

    char * buf;

    if (str == NULL) return;
    if (LPC_parse_errors > MAX_COMPILE_ERRORS) return;

    buf = malloc(strlen(str) + SLOP);
    
    if (current_file != NULL)
        sprintf(buf, "%s (%d): %s\n", current_file, line, str);
    else
        sprintf(buf, "%s\n", str);

    // fprintf(stderr, "%s", buf);

    LPC_error_buffer[LPC_parse_errors] = string_copy(buf);
    LPC_parse_errors++;

    free(buf);
}


void yyerrorf(const char * fmt, ...)
{
    char buf[MAX_ERR];
    va_list args;
    va_start(args, fmt);
    vsprintf(buf, fmt, args);
    va_end(args);
    yyerror(buf);
}


void yyerror(const char *str)
{
    extern int LPC_parse_errors;
    extern Shared * LPC_error_buffer[];

    char * buf;

    if (str == NULL) return;
    if (LPC_parse_errors > MAX_COMPILE_ERRORS) return;

    buf = malloc(strlen(str) + SLOP);
    
    if (current_file != NULL)
        sprintf(buf, "%s (%d): %s\n", current_file, current_line, str);
    else
        sprintf(buf, "%s\n", str);


    LPC_error_buffer[LPC_parse_errors] = string_copy(buf);
    //fprintf(stderr, "%s", LPC_error_buffer[LPC_parse_errors]->str);
    LPC_parse_errors++;

    // clear instruction history so we don't try to do something smart!
    puinstr = uinstr;
    uinstr = 0;

    free(buf);
}

