
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/select.h>
#include <netdb.h>
#include <errno.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <pthread.h>


Val * lpc_thread_create()
{
    pthread_t * thr;

    return Const(0);

#if 0
    thr = (pthread_t *) malloc(sizeof(pthread_t));
    // FIX: start function and args?
    pthread_create(thr, NULL, NULL, NULL);

    return make_object(thr);
#endif
}
