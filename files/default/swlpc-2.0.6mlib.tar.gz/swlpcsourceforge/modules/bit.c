#ifdef BIT_STRINGS
void SET_BIT()

{
    Val  arg, arg1, arg2, *ret;
    char *str;
    int  len, old_len, ind;
    int  x, nonblank;

    Pop(&arg2);
    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_STRING, "set_bit", 1);
    type_check(&arg1, T_NUMBER, "set_bit", 2);
    type_check(&arg2, T_NUMBER, "set_bit", 3);

    if (arg1.u.number > MAX_BITS)
    {
        efun_error("set_bit: too big bit number: %d\n", arg1.u.number);
        return;
    }
    if (arg1.u.number < 0)
    {
        efun_error("set_bit: negative bit number: %d\n", arg1.u.number);
        return;
    }

    old_len = len = strlen(arg.u.string);
    ind = arg1.u.number / 6;
    if (ind >= len)
        len = ind + 1;
    str = xalloc(len + 1);
    str[len] = '\0';
    nonblank = 0;
    for (x = len - 1; x >= 0; x--)
    {
        char c;

        if (x < old_len)
            c = arg.u.string[x];
        else
            c = ' ';
        if (x == ind)
        {
            if (arg2.u.number)
                c = (c - ' ' | (1 << arg1.u.number % 6)) + ' ';
            else
                c = (c - ' ' & ~(1 << arg1.u.number % 6)) + ' ';
            if (c > 0x3f + ' ' || c < ' ')
            {
                efun_error("Illegal bit pattern in set_bit character %d\n", ind);
                return;
            }
        }
        if (c == ' ' && !nonblank)
            c = '\0';  /* truncate strings where possible */
        else
            nonblank = 1;
        str[x] = c;
    }
    ret = share_string(str);
    free(str);
    Push(ret);
}

void TEST_BIT()
{
    Val  arg, arg1, *ret;
    int  len;

    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_STRING, "test_bit", 1);
    type_check(&arg1, T_NUMBER, "test_bit", 2);
    len = strlen(arg.u.string);
    if (arg1.u.number / 6 >= len)
    {
        Push(Const(0));
        return;
    }
    if (arg.u.string[arg1.u.number / 6] - ' ' & 1
        << arg1.u.number % 6)
    {
        Push(Const(1));
        return;
    }
    Push(Const(0));
}
#endif
