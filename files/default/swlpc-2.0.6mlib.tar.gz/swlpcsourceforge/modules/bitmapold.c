/**************************************************************************
 * bitmap.c                                                               *
 * written by David Brackeen                                              *
 * http://www.brackeen.com/home/vga/                                      *
 *                                                                        *
 * This is a 16-bit program.                                              *
 * Tab stops are set to 2.                                                *
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned long  dword;

#define MAXBITMAP 1280000

typedef struct tagBITMAP              /* the structure for a bitmap. */
{
  word width;
  word height;
  byte data[MAXBITMAP];
  // byte *data;
} BITMAP;

BITMAP *bmp;

/**************************************************************************
 *  fskip                                                                 *
 *     Skips bytes in a file.                                             *
 **************************************************************************/

void fskip(FILE *fp, int num_bytes)
{
   int i;
   for (i=0; i<num_bytes; i++)
      fgetc(fp);
}

/**************************************************************************
 *  load_bmp                                                              *
 *    Loads a bitmap file into memory.                                    *
 **************************************************************************/
#define PATH_SIZE 100

Val * lpc_loadbitmap(Val * file)
{
  FILE *fp;
  long index;
  word num_colors;
  long x;

  char file2[PATH_SIZE];
  strcpy(file2, file->u.string->str);
  //return make_string(file2);
  /* open the file */
  //  efun_error("iiiError opening file  (%s)\n", file2/*file->u.string*/);
    //return Const(0);
 if ((fp = fopen(file2,"rb")) == NULL)
  {
    efun_error("Error opening file  (%s)\n", file2/*file->u.string*/);
    return Const(0);

  }

  /* check to see if it is a valid bitmap file */
  if (fgetc(fp)!='B' || fgetc(fp)!='M')
  {
    fclose(fp);
    efun_error("(%s) is not a bitmap file.\n", file2/*file->u.string*/);
    return Const(0);
  }

  bmp=malloc(sizeof(BITMAP));
  /* read in the width and height of the image, and the
     number of colors used; ignore the rest */
  fskip(fp,16);
  fread(&bmp->width, sizeof(word), 1, fp);
  fskip(fp,2);
  fread(&bmp->height,sizeof(word), 1, fp);
  fskip(fp,22);
  fread(&num_colors,sizeof(word), 1, fp);
  fskip(fp,6);

  /* assume we are working with an 8-bit file */
  if (num_colors==0) num_colors=256;

  /* try to allocate memory */
//  if ((bmp->data = (byte *) malloc((word)(bmp->width*bmp->height))) == NULL)
//  {
//    fclose(fp);
//    efun_error("Error allocating memory for file (%s).\n", file2/*file->u.string*/);
//    return Const(0);
 // }

  /* Ignore the palette information for now.
     See palette.c for code to read the palette info. */
  fskip(fp,num_colors*4);

 //  bmp->data[254*254]=(byte)5;
//  bmp->data[(word)63516/*254*254*/]=5;
  /* read the bitmap */
  for(index=(bmp->height-1)*bmp->width;index>=0;index-=bmp->width)
    for(x=0;x<bmp->width;x++)
      bmp->data[index+x]=(byte)fgetc(fp);

  fclose(fp);

  return Const(1);

}

byte color(int x,int y)
{
  return bmp->data[y*bmp->width+x];
  //return 5;//bmp->data[1000];
}

Val *lpc_color(Val *xV,Val *yV)
{
  int x,y;
  byte iColor;
  char sColor[2];

  x = xV->u.number;
  y = yV->u.number;

  //iColor= bmp->data[1000];
  iColor= bmp->data[(y-1)*(bmp->width-1)+(x-2)];
  sprintf(sColor,"%x",iColor);
  //sprintf(sColor,"%x %x",iColor,y*bmp->width+x);

  return make_string(sColor);
}

Val *lpc_width()
{
  return make_number(bmp->width);
}

Val *lpc_height()
{
  return make_number(bmp->height);
}

/**************************************************************************
 *  Main                                                                  *
 *    Draws opaque and transparent bitmaps                                *
 **************************************************************************/
//void main()
//{
 // printf("%s","yeah");
 // int i,x,y;

 // load_bmp("staticobjectss.bmp");        /* open the file */
 // printf("%d",color(39,48));

//  free(bmp->data);                     /* free up memory used */
 // free(bmp);
 // return;
//}

