
#include "../config.h"
#include <stdlib.h>
#include <sys/types.h>
#include <openssl/blowfish.h>
#ifdef BSD
#include <crypto/crypto.h>
#else
#include <crypt.h>
#endif

#include "../config.h"
#include "stack.h"

Val * lpc_crypt(Val * arg, Val * arg1)
{
    Val *ret;
    char salt[2];
    char *choice =
    "abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVXYZ0123456789./";

    //type_check(&arg, T_STRING, "crypt", 1);
    //type_check(&arg1, T_STRING, "crypt", 2);
    if (arg1->type == T_STRING && arg->u.string->length >= 2)
    {
        salt[0] = arg1->u.string->str[0];
        salt[1] = arg1->u.string->str[1];
    }
    else
    {
#ifdef HAVE_SRANDOM
        salt[0] = choice[random() % strlen(choice)];
        salt[1] = choice[random() % strlen(choice)];
#else /* use time instead */
        salt[0] = choice[time(0l) % strlen(choice)];
        salt[1] = choice[time(0l) % strlen(choice)];
#endif /* RANDOM */
    }

#ifdef HAVE_CRYPT_H
    ret = make_string(crypt(arg->u.string->str, salt));
#else
    ret = share_string(arg->u.string);
#endif

    return ret;
}

Val * do_blowfish(Val * str, Val * key, int enc)
{
   /* BF_KEY bfkey;
    char * outstr;
    int len;
    Shared * blown;
    Val * ret;
    char ivec[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
    int num = 0;

    len = str->u.string->length;
    outstr = malloc(len+1);
    memset(outstr, '\0', len+1);
    memset(&bfkey, '\0', sizeof(bfkey));

    BF_set_key(&bfkey, key->u.string->length, key->u.string->str);
    BF_cfb64_encrypt(str->u.string->str, outstr,
                    len, &bfkey, ivec, &num, enc);

    blown = string_ncopy(outstr, len);
    free(outstr);
    ret = share_string(blown);*/
    Shared * blown;
    Val * ret;
    blown = string_ncopy("farts", strlen("farts"));
    ret = share_string(blown);
    return ret;
}

Val * lpc_blowfish_encrypt(Val * str, Val * key)
{
    return str;//do_blowfish(str, key, BF_ENCRYPT);
}

Val * lpc_blowfish_decrypt(Val * str, Val * key)
{
    return str;//do_blowfish(str, key, BF_DECRYPT);
}

Val * lpc_idea_decrypt(Val * str, Val * key)
{
    return NULL;
}

