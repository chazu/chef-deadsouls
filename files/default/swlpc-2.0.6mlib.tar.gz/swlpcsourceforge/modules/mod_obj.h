
int emit_new_string(FILE *f, char *s);
int emit_object(FILE *f, Obj *o);
int emit_string(FILE *f, char *s);
int emit_value(FILE *f, Val *v);
int emit_vector(FILE *f, struct vector *v);
int find_variable(Obj * ob, char * buff, int offset);
char * global_by_num(Obj *ob, int vnum);
int internal_restore(Obj *ob, char *file, FILE *flag);
int internal_save(Obj *ob, char *file, FILE *flag);
int read_new_string(FILE *f, char *buff, Val *v);
int read_object(FILE *f, char *buff, Val *v);
int read_string(FILE *f, char *buff, Val *v);
int read_value(FILE *f, char *buff, Val *v);
int read_vector(FILE * f, char *buff, Val *v);
Val * restore_object(Val * ob, Val * file);
Val * save_object(Val * ob, Val * file);
int skip_object(FILE * f, char *buff);
int skip_vector(FILE * f, char *buff);
