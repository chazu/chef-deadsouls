/*
** $Id: math.c,v 1.1.1.1 2001/09/11 04:12:21 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/modules/math.c,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:21 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include <math.h>
#include "stack.h"

Val * lpc_acos(Val * x)
{
    return make_real(acos(x->u.real));
}

Val * lpc_asin(Val * x)
{
    return make_real(asin(x->u.real));
}

Val * lpc_atan(Val * x)
{
    return make_real(atan(x->u.real));
}

Val * lpc_atan2(Val * x, Val * y)
{
    return make_real(atan2(x->u.real, y->u.real));
}

Val * lpc_ceil(Val * x)
{
    return make_real(ceil(x->u.real));
}

Val * lpc_cos(Val * x)
{
    return make_real(cos(x->u.real));
}

Val * lpc_cosh(Val * x)
{
    return make_real(cosh(x->u.real));
}

Val * lpc_exp(Val * x)
{
    return make_real(exp(x->u.real));
}

Val * lpc_fabs(Val * x)
{
    return make_real(fabs(x->u.real));
}

Val * lpc_floor(Val * x)
{
    return make_real(floor(x->u.real));
}

Val * lpc_fmod(Val * x, Val * y)
{
    return make_real(fmod(x->u.real, y->u.real));
}

#if 0
Val * lpc_frexp(Val * x, Val * y)
{
    return make_real(frexp(x->u.real, y->u.real));
}
#endif

Val * lpc_hypot(Val * x, Val * y)
{
    return make_real(hypot(x->u.real, y->u.real));
}

Val * lpc_ldexp(Val * x, Val * y)
{
    return make_real(ldexp(x->u.real, y->u.real));
}

#if 0
Val * lpc_modf(Val * x, Val * y)
{
    return make_real(modf(x->u.real, y->u.real));
}
#endif

Val * lpc_pow(Val * x, Val * y)
{
    return make_real(pow(x->u.real, y->u.real));
}

Val * lpc_sin(Val * x)
{
    return make_real(sin(x->u.real));
}

Val * lpc_sinh(Val * x)
{
    return make_real(sinh(x->u.real));
}

Val * lpc_sqrt(Val * x)
{
    return make_real(sqrt(x->u.real));
}

Val * lpc_tan(Val * x)
{
    return make_real(tan(x->u.real));
}

Val * lpc_tanh(Val * x)
{
    return make_real(tanh(x->u.real));
}



