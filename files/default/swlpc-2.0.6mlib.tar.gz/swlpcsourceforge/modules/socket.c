/*
** $Id: socket.c,v 1.2 2002/10/18 04:25:37 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/modules/socket.c,v $
** $Revision: 1.2 $
** $Date: 2002/10/18 04:25:37 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <sys/select.h>
#include <arpa/inet.h>
#define TELOPTS
#include <arpa/telnet.h>
#include <netdb.h>
#include <errno.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#include "stack.h"

Val * lpc_socket(Val * domain, Val * type, Val * protocol)
{
    return make_number(socket(domain->u.number, 
            type->u.number, protocol->u.number));
}

Val * lpc_ioctl(Val * socket, Val * ctl, Val * data)
{
    return make_number(ioctl(socket->u.number, ctl->u.number, data->u.number));
}

Val * lpc_fcntl(Val * socket, Val * how, Val * flag)
{
    return make_number(ioctl(socket->u.number, how->u.number, flag->u.number));
}

Val * lpc_listen(Val * socket, Val * len)
{
    return make_number(listen(socket->u.number, len->u.number));
}

Val * lpc_bind(Val * socket, Val * port)
{
    struct sockaddr_in sin;

    sin.sin_port= htons(port->u.number);
    // sin.sin_family = ??;
    sin.sin_addr.s_addr = INADDR_ANY;

    return make_number(bind(socket->u.number, (struct sockaddr *)&sin, sizeof sin));
}

#define MAX_HOST_NAME 256

Val * lpc_gethostbyname(Val * name)
{
    struct hostent *hp;
    char            host_name[MAX_HOST_NAME];
    char            host_addr[MAX_HOST_NAME];

    if (gethostname(host_name, sizeof host_name) == -1) 
    {
        perror("gethostname");
    }
    hp = gethostbyname(host_name);
    if (hp == NULL) 
    {
        (void) fprintf(stderr, "gethostbyname: unknown host.\n");
        exit(1);
    }
    
    memset((char *) &host_addr, '\0', sizeof host_addr);
    memcpy((char *) &host_addr, hp->h_addr, hp->h_length);
    return make_string(host_addr);
}

Val * lpc_gethostname()
{
    char            host_name[MAX_HOST_NAME];

    if (gethostname(host_name, sizeof host_name) == -1) 
    {
        perror("gethostname");
    }
    return make_string(host_name);
}

Val * lpc_gethostbyaddr()
{
    return Const(0);
}

Val * lpc_ntohl(Val * x)
{
    return make_number(ntohl(x->u.number));
}

Val * lpc_htonl(Val * x)
{
    return make_number(htonl(x->u.number));
}

Val * lpc_close(Val * x)
{
    return make_number(close(x->u.number));
}

Val * lpc_shutdown(Val * s, Val * how)
{
    return make_number(shutdown(s->u.number, how->u.number));
}

Val * lpc_connect(Val * address)
{
    return Const(0);
}

Val * lpc_send(Val * s, Val * str, Val * flags)
{
    return make_number(send(s->u.number, str->u.string, str->u.string->length, flags->u.number));
}

Val * lpc_sendto(Val * s, Val * str, Val * flags)
{
    return make_number(send(s->u.number, str->u.string, str->u.string->length, flags->u.number));
}

#define MAX_RECV 4096
Val * lpc_recv(Val * s, Val * flags)
{
    char buf[MAX_RECV]; 
    int res;
    res = recv(s->u.number, buf, MAX_RECV, flags->u.number);

    if (res == -1) return Const(0);
    buf[res] = '\0';
    return make_string(buf);
}

Val * lpc_recvfrom(Val * s, Val * flags)
{
    char buf[MAX_RECV]; 
    int res;
    res = recv(s->u.number, buf, MAX_RECV, flags->u.number);

    if (res == -1) return Const(0);
    buf[res] = '\0';
    return make_string(buf);
}

Val * lpc_setblocking(Val * s)
{
    return Const(0);
}

Val * lpc_read(Val * fd, Val * max)
{
    char * buf = (char *) malloc(max->u.number + 1) ;
    int r;
    Val * rs;

    r = read(fd->u.number, buf, max->u.number);
    rs = make_string(buf);
    free(buf);
    return rs;
}

Val * lpc_write(Val * fd, Val * str)
{
    return make_number(write(fd->u.number, str->u.string, str->u.string->length));
}


Val * lpc_select(Val * fd)
{
    return Const(0);
}

Val * lpc_usleep(Val * num)
{
    usleep(num->u.number);
    return Const(0);
}

