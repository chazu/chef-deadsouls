
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "stack.h"
#include "../runtime/comm.h"

#define HOST_NAME_LEN 256

Val * lpc_query_host_name()
{
    char  name[HOST_NAME_LEN];

    gethostname(name, sizeof name);
    /* Just to make sure */
    name[sizeof name - 1] = '\0';   
    return make_string(name);
}

Val * lpc_set_ip_number(Val * ob, Val * ip)
{
    Obj * o = ob->u.ob;

    if (!o || !o->interactive) return Const(0);

    if (o->interactive->ipaddr) 
    {
        free_string(o->interactive->ipaddr);
        o->interactive->ipaddr = 0;
    }

    if (ip->u.string) o->interactive->ipaddr = shared_string_copy(ip->u.string);

    return Const(1);
}

Val * lpc_query_ip_number(Val * vob)
{
    Obj * ob = vob->u.ob;

    if (!ob || !ob->interactive) return Const(0);
    if (ob->interactive->ipaddr) 
        return share_string(ob->interactive->ipaddr->str);

    return make_string(inet_ntoa(ob->interactive->addr.sin_addr));
}


