/*
** $Id: misc.c,v 1.2 2003/01/31 03:43:42 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/modules/misc.c,v $
** $Revision: 1.2 $
** $Date: 2003/01/31 03:43:42 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/
#include <time.h>
#include "stack.h"

#ifdef __WIN32__
#define srandom(X) srand(X)
#define random() rand()
#endif

#define HUGE_PRIME  29000039
#define addhash(h, i) (((h) * P1 + (i) * P2 + P3) % HUGE_PRIME)

int subhash(Val * v)
{
    int  h = 0;
    int  x;
    int ret;

    if (!v) return 0;
    h = v->type;
    switch (v->type)
    {
        case T_NUMBER:
        case T_REAL:
        case T_OBJECT:
            ret = addhash(h, v->u.number);
            break;
        case T_STRING:
            ret = addhash(h, LPC_StrHash(v->u.string, HUGE_PRIME));
            break;
        case T_POINTER:
            h = addhash(h, v->u.vec->size);
            for (x = 0; x < v->u.vec->size; x++)  /* sigh - really values */
                h = addhash(h, subhash(&v->u.vec->item[x]));
            ret = h;
            break;
        default:
            ret = 0;
    }

    return ret;
}

/* relies on no recursive arrays */
Val * hash_value(Val * v)
{
    return make_number(abs(subhash(v)));
}


Val * lpc_srandom(Val * seed)
{
    srandom(seed->u.number);
    return Const(0);
}

Val * lpc_random(Val * range)
{
    if (range->u.number == 0) return Const(0);

    return make_number((random()>>2) % range->u.number);
}

Val * lpc_ctime(Val * arg)
{
    long tmp;
    char *cp, *s;

    tmp = arg->u.number;
    s = ctime(&tmp);
    /* Now strip the newline. */
    cp = strchr(s, '\n');
    if (cp) *cp = '\0';

    return make_string(s);
}

Val * lpc_array_index(Val * arr, Val * ele, Val * match, Val * start)
{
    int i, num;
    Val * subarr;

    num = ele->u.number;
    for (i = start->u.number; i < arr->u.vec->size; i++)
    {
        subarr = &arr->u.vec->item[i];
        if (   (subarr->type == T_POINTER)
            && (subarr->u.vec->size >= num)
            && (subarr->u.vec->item[num].type == match->type))
        {
            switch(match->type)
            {
                case T_REAL:
                    if (subarr->u.vec->item[num].u.real == match->u.real)
                        return make_number(i);
                    break;
                case T_STRING:
                    if (subarr->u.vec->item[num].u.string == match->u.string)
                        return make_number(i);
                    break;
                case T_POINTER:
                    if (subarr->u.vec->item[num].u.vec == match->u.vec)
                        return make_number(i);
                    break;
                case T_OBJECT:
                    if (subarr->u.vec->item[num].u.ob == match->u.ob)
                        return make_number(i);
                    break;
                case T_NUMBER:
                default:
                    if (subarr->u.vec->item[num].u.number == match->u.number)
                        return make_number(i);
            }
        }
    }

    // failed
    return make_number(-1);
}

