

/*
** $Id: hash.h,v 1.2 2003/05/24 07:52:09 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/hash.h,v $
** $Revision: 1.2 $
** $Date: 2003/05/24 07:52:09 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-2001
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/


#ifndef _RHASH_H
#define _RHASH_H

#include "stack.h"
#include "rhash.h"
#include "stralloc.h"

// this will limit the maximum no. of functions 
#define IHSIZE 99109

// profiling on/off
#define PROFILE 1

typedef struct Ielement
{
    Shared * obj;               /* key */
    Func * program;             /* program pointer */
#ifdef PROFILE
    unsigned long called;       /* # of times called */
#endif
    char used, deleted;
    short offset;               /* offset for global vars */
} i_element;

Func * Hfunction(Shared * func_name, Shared * );

int    add_Hfunction(Func * pr, Shared * ,short);

int    remove_Hfunction(Shared * func_name, Shared * );

int    iHash(char *, char *, int);

void   init_Htable();
    /* Initialise the internal hash table */

int  show_ihash_table_status();

extern i_element * IHtable;

#endif

