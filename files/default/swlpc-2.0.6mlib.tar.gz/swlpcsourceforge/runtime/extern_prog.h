
/*
** $Id: extern_prog.h,v 1.2 2003/01/16 04:04:30 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/extern_prog.h,v $
** $Revision: 1.2 $
** $Date: 2003/01/16 04:04:30 $
** $State: Exp $
**
** Author: Zik Saleeba
** Copyright(C) 1993-1998
** zik@zikzak.net
**
** See the file "Copying" distributed with this file.        
**
** Further hacked by Mike McGaughey and Geoff Wong
*/

#ifndef _EXTERN_PROG_H
#define _EXTERN_PROG_H

#if 0
#include <sys/types.h>
#include <sys/socket.h>
/* #include <sys/un.h> */
#include <sys/wait.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <errno.h>
#endif
#include "comm.h"

void
    child_termination(),
    close_external_sockets(struct interactive * ip),
    completed_external(struct interactive * ip),
    extern_commands(char *To, char *From),
    finito_call(struct interactive * ip, int RetVal),
    kill_external(struct interactive * ip),
    start_external()
    ;

#endif
