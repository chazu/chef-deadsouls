/*
	Some compilation stubs for single user driver
	(so we don't need inet stuff etc)
*/
#include "proto.h"

void
start_external(
	char *ProgName, char *SocketName, 
	char *argv[], char *envp[], char *finito, 
	int usestdio, 
	char *infile, char *outfile, char *errfile)
{
}

child_termination()
{
}
