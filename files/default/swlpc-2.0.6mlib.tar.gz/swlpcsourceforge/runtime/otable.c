/*
** $Id: otable.c,v 1.2 2001/10/28 03:05:49 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/otable.c,v $
** $Revision: 1.2 $
** $Date: 2001/10/28 03:05:49 $
** $State: Exp $
**
** Author: Mike McGaughey
** Copyright(C) 1991-1998
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.        
**
** Object name hash table.  Object names are unique, so no special
** problems - like stralloc.c.  For non-unique hashed names, we need
** a better package (if we want to be able to get at them all) - we
** cant move them to the head of the hash chain, for example.
**
** Note: if you change an object name, you must remove it and reenter it.
*/

#include <stdlib.h>
#include <stdio.h>
#include "hash.h"
#include "stack.h"
#include "gd_config.h"

//#define ODEBUG

/*
 * hash table - list of pointers to heads of object chains.
 * Each object in chain has a pointer, next_hash, to the next object.
 * OTABLE_SIZE is in gd_config.h, and should be a prime, probably between
 * 100 and 1000.  You can have a quite small table and still get very good
 * performance!  Our database is 20Meg; we use about 500.
 */

Obj ** obj_table = 0;

void init_Otable();

void init_Otable()
{
    int x;
    obj_table = (Obj **)
            malloc(sizeof(Obj *) * OTABLE_SIZE);

    for (x=0; x<OTABLE_SIZE; x++)
        obj_table[x] = 0;
}

void free_Otable()
{
    free(obj_table);
}

#if 0
/*
 * Object hash function, ripped off from stralloc.c.
 */

static int ObjHash(char *s)
{
    int h = 0;

#if 0
    if (!obj_table)
        init_Otable();
#endif

    while (*s)
        h = (h * P1 + *(s++) * P2 + P3) % OTABLE_SIZE;
    
    return h;
}
#endif

/*
 * Looks for obj in table, moves it to head.
 */

static int obj_searches = 0, obj_probes = 0, objs_found = 0;

Obj * find_obj_n(Shared *s)
{
    Obj * curr, *prev;

    int h = hashstr(s->str, MAXH, OTABLE_SIZE);

    curr = obj_table[h];
    prev = 0;

    obj_searches++;

    while (curr != NULL) 
    {
        obj_probes++;
        if (curr->name == s) 
        { 
        /* found it */
        if (prev) 
        { 
            /* not at head of list */
            prev->next_hash = curr->next_hash;
            curr->next_hash = obj_table[h];
            obj_table[h] = curr;
        }
        objs_found++;
#ifdef ODEBUG
    printf("HASHO: find_obj_n #%s#\n", curr->name->str);
#endif
        return(curr);    /* pointer to object */
        }
        prev = curr;
        curr = curr->next_hash;
    }
#ifdef ODEBUG
    printf("HASHO: find_obj_n FAILED (%d) #%s#\n", h, s->str);
#endif
    
    return(0); /* not found */
}

/*
 * Add an object to the table - can't have duplicate names.
 */

static int objs_in_table = 0;

Obj * enter_object_hash(Obj *ob)
{
    Obj * s;
    int h = hashstr(ob->name->str, MAXH, OTABLE_SIZE);

#ifdef ODEBUG
    printf("HASHO: enter (%d) #%s#\n", h, ob->name->str);
#endif

    s = find_obj_n(ob->name);
    if (s) return s;
#if 0
    {
        if (s != ob)
            fatal("Duplicate object \"%s\" in object hash table, ", ob->name);
        else
            fatal("Entering object \"%s\" twice in object table, ", ob->name);
    }
    else 
    {
        if (ob->next_hash)
        fatal("Object \"%s\" not found in object table but next link not null",
                ob->name);
    }
    if (ob->name->str[0] == '/') abort();
#endif

    ob->next_hash = obj_table[h];
    obj_table[h] = ob;
    objs_in_table++;
#ifdef ODEBUG
    s = find_obj_n(ob->name);
    if (s != ob)
        printf("HASHO: enter VERIFY FAILED #%s#\n", s->name->str);
    else
        printf("HASHO: enter VERIFIED #%s#\n", s->name->str);
#endif
    return(ob);
}

/*
 * Remove an object from the table - generally called when it
 * is removed from the next_all list - i.e. in destruct.
 */

void remove_object_hash(Obj *ob)
{
    Obj * s;
    int h = hashstr(ob->name->str, MAXH, OTABLE_SIZE);

#ifdef ODEBUG
    printf("HASHO: remove(%d) #%s#\n", h, ob->name->str);
#endif

    /* note: find_obj_n moves s to front of hash chain */
    s = find_obj_n(ob->name);

    if (!s)
        fatal("Remove object \"%s\": not found!", ob->name->str);
    if (s != ob && ob->next_hash != NULL)
        fatal("Remove object \"%s\": found a different object!",
            ob->name->str);
    
    obj_table[h] = s->next_hash;
    s->next_hash = 0;
    objs_in_table--;
    return;
}

/*
 * Lookup an object in the hash table; if it isn't there, return null.
 * This is only different to find_object_n in that it collects different
 * stats; more finds are actually done than the user ever asks for.
 */

static int user_obj_lookups = 0, user_obj_found = 0;

Obj * lookup_object_hash(Shared * s)
{
    Obj * ob = find_obj_n(s);

#ifdef ODEBUG
    printf("HASHO: lookup #%s#\n", s->str);
#endif

    user_obj_lookups++;
    if (ob) user_obj_found++;
    return(ob);
}

/*
 * Print stats, returns the total size of the object table.  All objects
 * are in table, so their size is included as well.
 */

static char sbuf[100];

int show_otable_status()
{
    add_message("Objects :   %5d (%6d bytes), ",
        objs_in_table, objs_in_table * sizeof(Obj));
    add_message("hash overhead:  %d bytes\n",
        OTABLE_SIZE * sizeof(Obj *));
    sprintf(sbuf, "%.2f", objs_in_table / (float) OTABLE_SIZE);
    add_message("Av ob chain len: %s, ", sbuf);
    sprintf(sbuf, "%.2f", (float)obj_probes / obj_searches);
    add_message("Searches (search length):  %d (%s)\n",
        obj_searches, sbuf);
    add_message("External lookups succeeded (failed):  %d (%d)\n",
        user_obj_lookups, user_obj_found);
    return (OTABLE_SIZE * sizeof(Obj *) + objs_in_table * sizeof(Obj));
}
