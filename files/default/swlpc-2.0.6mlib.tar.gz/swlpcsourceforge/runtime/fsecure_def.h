
#ifndef _FSECUREDEF_H
#define _FSECUREDEF_H

/*
 * Access lists for files and directories.
 */
#define NOONE (-1)
#define NOTHING (0)

struct access 
{ 
     char * dir;
	 int read, write, append;
}
/* List of levels required to read, write and append files in each dir.
 * %p is replaced by playername.  %n is no slash. %s is anything.
 * other characters match precisely.  Creation and reading of directories
 * follows the same rules as the file access lists; you should append a '/' to
 * the directory name when checking a 'directory' read or write (see
 * secure/wiz_soul for examples...)
 */
MudFileAccessList[] = {
	{ "/",			APPRENTICE, GOD, GOD },	/* mud root dir */
	{ "",			APPRENTICE, GOD, GOD },	/* mud root dir */
	{ "/%s",		NOONE, NOONE, NOONE },	/* NOPE! */
	{ "secure%s",		NOONE, NOONE, NOONE },	/* game driver */
	{ "RO%s",		APPRENTICE, GOD, GOD }, /* read only */
	{ "closed%s",		GOD, GOD, GOD },	/* souls, etc */
	{ "ideas/%s",           APPRENTICE, CREATE, CREATE },
#ifndef SHATTERED
	{ "W/%p",		APPRENTICE, GOD, GOD },	 /* my savefile */
	{ "W/%n/closed%s", GOD, GOD, GOD },	/* player only */
	{ "W/%n/open%s",	APPRENTICE, ED_OTHERS, ED_OTHERS },
	{ "W/%p/%s",		APPRENTICE, CREATE, CREATE },
	{ "W/%n/%s",	READ_OTHERS, ED_OTHERS, ED_OTHERS}, /* others */
#endif
	{ "players/%p",		APPRENTICE, GOD, GOD },	 /* my savefile */
	{ "players/%p.o",	APPRENTICE, GOD, GOD },	 /* my savefile */
	{ "players/%p.%n",	APPRENTICE, GOD, GOD },	 /* my savefile */
	{ "players/%p/closed%s",	/* my closed stuff (>cre) */
				CREATE + 1, CREATE + 1, CREATE + 1 },
	{ "players/%p/%s",	APPRENTICE, CREATE, CREATE },
	{ "players/%n/closed%s", GOD, GOD, GOD },	/* player only */
	{ "players/%n/open%s",	APPRENTICE, ED_OTHERS, ED_OTHERS },
	{ "players/%n/toys%s",	APPRENTICE, ED_OTHERS, ED_OTHERS },
	{ "players/%n/%s",	READ_OTHERS, ED_OTHERS, ED_OTHERS}, /* others */
	{ "%Gplayers/%s",	CREATE, GOD, GOD }, /* savefiles */
	{ "players/%s",		ED_OTHERS, GOD, GOD }, /* savefiles */
	{ "log/%p",  		APPRENTICE, CREATE, CREATE },  /* your log */
	{ "log/%p.%n", 		APPRENTICE, CREATE, CREATE },  /* your log */
	{ "log/.%p/%s",		APPRENTICE, CREATE, CREATE },  /* your log dir */
	{ "log/%s",   		CREATE, ED_LOG, ED_LOG },  /* all logs */
	{ "%Gobj/%s",		APPRENTICE, CREATE, CREATE },
	{ "obj/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "admin/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "%Groom/post_dir/%s",	CREATE, CREATE, CREATE },
	{ "room/post_dir/%s",	EDIT_STANDARD, EDIT_STANDARD, EDIT_STANDARD },
	{ "room/W/%s",	    CREATE, EDIT_STANDARD, EDIT_STANDARD },
	{ "%Groom/%s",		APPRENTICE, CREATE, CREATE },
	{ "room/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "%Glib/%s",		APPRENTICE, CREATE, CREATE },
	{ "lib/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "%Gguilds/%s",	APPRENTICE, CREATE, CREATE },
	{ "guilds/%s",		APPRENTICE, ED_OTHERS, ED_OTHERS },
	{ "%Gstd/%s",		APPRENTICE, CREATE, CREATE },
	{ "std/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "S/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "include/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "%Gopen/%s",		0, 0, 0 },
	{ "open/%s",		APPRENTICE, CREATE, CREATE },
	{ "open/board/%s",	CREATE, CREATE, CREATE },
	{ "%Gbanish/%s",	APPRENTICE, CREATE, CREATE },
	{ "banish/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "doc/%s",		ANYONE, EDIT_STANDARD, EDIT_STANDARD },
	{ "LISTS/%s",		APPRENTICE, EDIT_STANDARD, EDIT_STANDARD },
	{ "%n",			APPRENTICE, GOD, GOD },	/* files in root dir */
	{ "%s",			GOD, GOD, GOD },	/* all other dirs */
	{ 0,			NOONE, NOONE, NOONE }
};

/*
 * Level to (initially) give any object.  The object itself is responsible
 * for its own security; in general, only player.c need worry, as it is
 * the only god-level object (as well as the game driver).
 */
struct ocap { char * dir; int level; }
caplist[] = {
	{ "secure%s",		NOTHING }, /* assigned by driver */
	{ "RO%s",		NOTHING }, /* assigned by driver */
	{ "closed%s",		CREATE }, /* passed on by player */
#ifndef SHATTERED
	{ "W/%n/closed%s", LOCAL_ED },
	{ "W/%n/%s",	CREATE },
#endif
	{ "players/%n/toys%s",	NOTHING }, /* other players must trust to use */
	{ "players/%n/closed%s", LOCAL_ED },
	{ "players/%n/%s",	CREATE },
	{ "obj/%s",		CREATE },
	{ "room/%s",		CREATE },
	{ "guilds/%s",		CREATE },
	{ "guilds/%n/%s",       CREATE },
	{ "std/%s",		CREATE },
	{ "lib/%s",             CREATE },
	{ "include/%s",		NOTHING },
	{ "open/%s",		NOTHING }, /* all other objs - ie /open - */
	{ "%s",			NOTHING }, /* must be nilpotent. Player can */
	{ 0,			NOTHING }  /* trust them if he needs them. */
	};

#endif
