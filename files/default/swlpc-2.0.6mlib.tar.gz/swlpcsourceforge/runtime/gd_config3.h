/*
 * Version.
 */

#define SHATTERED /**/

#ifdef SHATTERED
#ifndef PORTNUM2
#define PORTNUM2		2666
#endif
#ifndef	EPORTNUM2	/* extra port */
#define EPORTNUM2		17609
#endif
#else
#ifndef PORTNUM2
#define PORTNUM2		5001
#endif
#ifndef	EPORTNUM2	/* extra port */
#define EPORTNUM2		17610
#endif
#endif /* SHATTERED */

#define MUD_NAME		"Shattered World"
#define MUD_SHORT		"Shattered"
#define DRIVER_VERSION		"XLPC-apr98"
#define	LANGUAGE_VERSION	"XLPC-1.0"

#define MAX_SAVE_OBJECT_DEPTH 2

/*
 * Set this if you want a file with simulated efuns.
 * This must be a maximum security file (it's loaded first!)
 */

#define EMULATE_EFUN	"RO/emulate" /* */

/*
 * Datagram server (this is where datagrams get delivered to).
 */

#define OBJ_DATAGRAM_SERV  "secure/remote/dg_serv"

/*
 * When the system is made (make install), a file with the system
 * configuration is placed in the mudlib.   Define the location
 * of the file here (it is prepended with MUD_LIB).
 */

#define	MUD_CONFIG_FILE	"RO/Consts.h"

/* 
 * Some defines for the hash table stuff
 */

#define LOCAL_HTABLE_SIZE 93

/* 
 * Is your machine big endian?
 */
#define ENDIAN

/*
 * Umask to use on files (077, 022, 007 usually)
 */

#define UMASK 002

/*
 * Maximum number of bits in a bit field. They are stored in printable
 * strings, 6 bits per byte.
 */
#define MAX_BITS		1200	/* 200 bytes */

/*
 * There is a hash table for living objects, used by find_living().
 */
#define LIVING_HASH_SIZE	701

/*
 * Set default MUD_LIB to the directory which contains the mud data.
 */

#define MUD_LIB			"/home/mud/swlpc/mudlib"

/*
 * The following is the secure directory where secure files are to be kept
 */

#define SECURE_LIB		"/home/mud/swlpc/secure"

/*
 * And this is where it looks for external programs and keeps
 * UNIX domain sockets.
 */

#define	EXTPROG_DIR		"/home/knoppix/swlpc-2.0.6/extprog"
#define	EXTPROG_SOCKDIR		"/home/knoppix/swlpc-2.0.6/extprog/sockets"

/*
 * This is the file that the TERMCAP information should be taken from
 */

#define TERMCAP_PATH		"/etc/termcap"

/*
 * Which port to use on this host.  The #ifndef is so that we can define a
 * different port with a -D option to the compiler.
 */

#ifndef PORTNUM
#ifdef SHATTERED
#define PORTNUM			23
#else
#define PORTNUM			5000
#endif /* SHAT */
#endif
#ifndef	EPORTNUM	/* extra port */
#ifdef SHATTERED
#define EPORTNUM		17953
#else	
#define EPORTNUM		11953
#endif /* SHAT */
#endif

/*
 * This is the maximum array size allowed for a single array.
 */
//#define MAX_ARRAY_SIZE		12000


/*
 * Define this to be the maximum number of players you will allow on your
 * mud.
 */
#define MAX_PLAYERS	40


/*
 * Define this to be the maximum number of lines printed in a cat or similar
 * operation before ***TRUNCATED*** is printed.
 */
#define MAX_LINES 100

/*
 * When uploading files, we want fast response; however, normal players
 * shouldn't be able to hog the system in this way.  Define ALLOWED_ED_CMDS
 * to be the ratio of the no of ed cmds executed per player cmd
 */

#define	ALLOWED_ED_CMDS		20
#define MAX_CMD_TIME		10

/*
 * Maximum time (secs) of execution from a command start
 * (callouts and player commands)
 *
 * 0 - infinite
 */

#define MAX_LOOP_TIME       0


/*
 * And the following are the buffer sizes for the dgram socket.
 * Small - should be set by checking system consts.
 */

#define DG_BUFF 8300    /* actually near 9K, but there's packet header overhead
*/

/*
 * Object hash table size. Define this like you did with the strings;
 * probably set to about 1/4 of the number of objects in a game, as the
 * distribution of accesses to objects is rather uniform.
 */

#define OTABLE_SIZE	10223   /* we have 20k obs usually */

/*
 * Define the following if you want to change the name of debug.log (for
 * example, if you don't want the hostname prepended to the file name)
 * The DEBUG_LOG string must also be defined in consts.c
 */

#define DEBUG_LOG "bad.log"
#define FATAL_LOG "fat.log"

/*
 * The locations of the objects and mudlib files known about by the
 * game driver.
 */

#define	OBJ_VOID	"RO/void"
#define	OBJ_MASTER	"secure/master"
#define	OBJ_CONNECT	"secure/connect"
#define	OBJ_CONNECT2	"secure/connect2"	/* backup port */
#define	OBJ_STORAGE	"RO/storage"	/* testing purposes */
#define	OBJ_SHUT	"RO/shut"

#define	PLAYER_DIR	"players"

/*****************************************************************************/
/* END OF CONFIG -- DO NOT ALTER ANYTHING BELOW THIS LINE	     */
/*****************************************************************************/

/*
 * some generic large primes used by various hash functions in different
 * files These are not critical.
 */

#define	P1		701	/* 3 large, different primes */
#define	P2		14009	/* There's a file of them here somewhere :-) */
#define	P3		54001

#define HUGE_PRIME	29000039 

/*****************************************************************************/
