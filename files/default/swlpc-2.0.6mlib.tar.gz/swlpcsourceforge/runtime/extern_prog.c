

/*
** $Id: extern_prog.c,v 1.3 2003/02/23 10:27:38 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/extern_prog.c,v $
** $Revision: 1.3 $
** $Date: 2003/02/23 10:27:38 $
** $State: Exp $
**
** Author: Zik Saleeba
** Copyright(C) 1993-1998
** zik@zikzak.net
**
** See the file "Copying" distributed with this file.        
**
**
** Further hacked by Mike McGaughey and Geoff Wong
*/

#include "proto.h"
#include "extern_prog.h"

#ifndef __WIN32__
#ifdef HAVE_FCNTL_H
#include <fcntl.h>
#endif
#include "comm.h"

extern struct interactive *find_extern_pid(int);

extern int num_made;

void start_external(
    char * ProgName, 
    char * SocketName, 
    char * argv[], 
    char * envp[],
    char * finito,
    int usestdio, 
    char * infile, 
    char * outfile, 
    char * errfile)
{
	struct interactive *PlayerInt;
	char            Program[500];
	int sockpair[2];
	int ChildSock = (-1);
	int infd = (-1), outfd = (-1), errfd = (-1);

	/* remove the socket if it already exists */
	unlink(SocketName);

	/* create the full program name */
	strcpy(Program, EXTPROG_DIR);
	strcat(Program, "/");
	strcat(Program, ProgName);

#if 0
	printf("Environment:\n");
	for (Count=0; envp[Count] != 0; Count++)
		printf("%d: %s\n", Count, envp[Count]);
	printf("\nArguments: ");
	for (Count=0; argv[Count] != 0; Count++)
		printf("%s ", argv[Count]);
	printf("\n");
#endif

	if (command_giver == 0 || command_giver->interactive == 0)
		return;
	PlayerInt = command_giver->interactive;

	/* the player may have an already active external session; zap it */
	if (PlayerInt->extern_pid != 0)
		kill_external(PlayerInt);

	/* set up the finito call */
	if (finito) {		/* set up */
		PlayerInt->finito_call = string_copy(finito);
		PlayerInt->finito_callee = Scurrent();
	} 
	else {			/* no finito call */
		PlayerInt->finito_call = 0;
		PlayerInt->finito_callee = 0;
	}

#if 0
	printf("Trying to establish communication with child on %s. (std: %d)\n", SocketName, usestdio);
#endif

	if (!usestdio) {
		/* open the socket */
		PlayerInt->my_ext_socket = socket(AF_UNIX, SOCK_STREAM, 0);
		PlayerInt->my_ext_addr.sun_family = AF_UNIX;
		strcpy(PlayerInt->my_ext_addr.sun_path, SocketName);

#if 0
		if (bind(PlayerInt->my_ext_socket, (caddr_t) & PlayerInt->my_ext_addr, strlen(SocketName) + sizeof(PlayerInt->my_ext_addr.sun_family)) == -1) {
#endif
		if (bind(PlayerInt->my_ext_socket, (struct sockaddr *) & PlayerInt->my_ext_addr, strlen(SocketName) + sizeof(PlayerInt->my_ext_addr.sun_family)) == -1) {
			PlayerInt->my_ext_socket = 0;
			finito_call(PlayerInt, 0);
			perror("External program bind failed");
			efun_error("Bind failed.\n");
			return;
		}
		listen(PlayerInt->my_ext_socket, 1);
		fcntl(PlayerInt->my_ext_socket, F_SETFL, O_NDELAY); /* no blocking */
	}
	else { /* use stdio.  If any of stdin, out, err are null, they should be
		  connected to the terminal, otherwise, they are connected to files.
		  Make sure we have a childsock, though, coz we want to make sure
		  we know when the child exits (if necessary, make it FD 3) */
	    int x = socketpair(AF_UNIX, SOCK_STREAM, 0, sockpair);
	    if (x == (-1)) {
		perror("Socketpair failed\n");
		efun_error("Socketpair failed.\n");
		return;
		}
	    PlayerInt->my_ext_socket = 0;
	    PlayerInt->extern_socket = sockpair[0];
	    ChildSock = sockpair[1];
	}

	PlayerInt->extern_pid = vfork();
	if (PlayerInt->extern_pid == 0) { 
		/* we're the child - try opening the files */
		/* redirect input from /dev/null, to fix an embarrassing bug */
		if (!usestdio) {
			fcntl(0, F_SETFD, 1); /* close stdin on exec */
			}
		else { /* its stdin, stdout should be the sockets */
		    if (ChildSock != 3)
			dup2(ChildSock, 3); /* make a fake connected socket */
		    if (infile) {
			infd = open(infile, O_RDONLY, 0);
			if (infd < 0)
			    efun_error(
				"Couldn't open stdin file \"%s\"", infile);
			    return;
			}
		    else
			infd = ChildSock;
		    if (infd != 4) {
			/* sigh - later overwrite check */
		        if (dup2(infd, 4) == -1) {
				printf("dup2 error on infd/4\n");	
			}
		    }
		    if (outfile) {
			outfd = open(outfile, O_APPEND | O_CREAT, 0666);
			if (outfd < 0) {
			    efun_error(
				"Couldn't open stdout file \"%s\"", outfile);
			    return;
			    }
			}
		    else
			outfd = ChildSock;
		    if (outfd != 5) {
			 /* sigh - later overwrite check */
		        if (dup2(outfd, 5) == -1) {
				printf("dup2 error on outfd/5\n");	
		        }
		    }
		    if (errfile) {
			errfd = open(errfile, O_APPEND | O_CREAT, 0666);
			if (errfd < 0)
			    efun_error(
				"Couldn't open stderr file \"%s\"", errfile);
			    return;
			}
		    else
			errfd = ChildSock;
		    if (errfd != 6) {
			/* sigh - later overwrite check */
			if (dup2(errfd, 6) == -1)
				printf("dup2 error on errfd/6\n");	
		    }
		    if (dup2(4, 0) == -1) /* in */
				printf("dup2 error on 4/0\n");	
		    if (dup2(5, 1) == -1) /* out */
				printf("dup2 error on 5/1\n");	
		    if (dup2(6, 2) == -1) /* err */
				printf("dup2 error on 6/2\n");	
		    fcntl(3, F_SETFD, 1); /* close stdin on exec */
		    fcntl(4, F_SETFD, 1); /* close stdin on exec */
		    fcntl(5, F_SETFD, 1); /* close stdin on exec */
		    fcntl(6, F_SETFD, 1); /* close stdin on exec */
		    }
		execve(Program, argv, envp);
		kill_external(PlayerInt);
		perror("Execution of child program failed");
		efun_error("Execution of child program failed\n");
	} 
	else { /* parent - clean up the spare socket */
		if (usestdio)
		    close(ChildSock);
	        fcntl(PlayerInt->extern_socket, F_SETFL, O_NDELAY); /* no blocking */
		PlayerInt->extern_timeout = 0;
		set_noecho(command_giver, 1);
	    }
#if 0
	printf("External program started.\n"); 
#endif
}


void kill_external(struct interactive * ip)
{
    if (ip != 0 && ip->extern_pid != 0) {
	close_external_sockets(ip);	/* cut it off */
	if (ip->extern_pid != 0)
	    kill(ip->extern_pid, SIGHUP);	/* tell it to die */
	ip->extern_pid = 0;	/* forget that it ever existed */
	ip->extern_status = -1;
	ip->extern_timeout = 0;
    }
}


void completed_external(struct interactive * ip)
{
    if (ip != 0) {
	close_external_sockets(ip);
	finito_call(ip, ip->extern_status);
	ip->extern_pid = 0;	/* set us up to start another */
	ip->extern_status = -1;
	ip->extern_timeout = 0;
	set_noecho(command_giver, 0);
    }
}


void finito_call(struct interactive * ip, int RetVal)
{
    if (ip->finito_call != 0 && ip->ob) {	/* do the finito call */
	command_giver = ip->ob;
	apply_clean(ip->finito_call, ip->finito_callee, make_number(RetVal));
	free_string(ip->finito_call);
	ip->finito_call = 0;
    }
}


void close_external_sockets(struct interactive * ip)
{
    /* shut the socket and everything */
    if (ip->my_ext_socket != 0) {
	shutdown(ip->my_ext_socket, 2);
	close(ip->my_ext_socket);
	unlink(ip->my_ext_addr.sun_path);	/* remove the unix filesystem
						 * socket */
	ip->my_ext_socket = 0;
    }
    if (ip->extern_socket != 0) {
	close(ip->extern_socket);
	ip->extern_socket = 0;
    }
}

/* called by SIGCHLD signal */
void child_termination()
{
    int             ProcId;
#if 0
    union wait      Status;
#else
	int	Status;
#endif
    struct interactive *Player;
do  {
    /* allow the program to terminate */
    ProcId = waitpid(-1,&Status, WNOHANG);
    if (ProcId == -1)
	{
	if (errno == ECHILD)
	    ProcId = 0;  /* ok, nothing to wait for. So I'm happy :-) */
	else
	    perror("Wait fuckup");
	}
    if (ProcId != 0) 
	{ /* search for which program had terminated */
        Player = find_extern_pid(ProcId);
        /* set "closing" status on program */
        if (Player != 0)
#if 0		/* FUCK */
	    Player->extern_status = Status.w_T.w_Retcode;
#endif
	    Player->extern_status = 0;
	}
    } while (ProcId != 0);
}


void extern_commands(char *To, char *From)
{
    char *CmdEnd;
    char *Move;
    char *MoveTo;
    int CmdSize;

*To = 0; /* make sure it's at least empty on return */
/* filter out commands following a 0x8f character and send to input */
    do  {
    /* search from here to the end of From looking for a 0x8f */
    while (*From != 0 && (unsigned char)*From != 0x8f)
	From++;
    if (*From != 0)
	{ /* got a command - find the end */
	for (CmdEnd = From; *CmdEnd != 0 && *CmdEnd != '\r' && *CmdEnd != '\n'; CmdEnd++);
	if (*CmdEnd == '\r' && *(CmdEnd+1) == '\n')
	    CmdEnd++;
	if (*CmdEnd != 0)
	    CmdEnd++;
    	/* copy this command to To */
	CmdSize = CmdEnd - From - 1;
	strncpy(To, From + 1, CmdSize);
	*(To + CmdSize) = 0;
    	/* shift the rest of the From buffer back */
	for (MoveTo = From, Move = CmdEnd; *Move != 0; MoveTo++, Move++)
	    *MoveTo = *Move;
	*MoveTo = 0;
	To += CmdSize;
	}
    } while (*From != 0);
}

#endif
