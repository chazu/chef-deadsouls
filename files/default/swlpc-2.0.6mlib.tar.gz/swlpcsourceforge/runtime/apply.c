

/*
** $Id: apply.c,v 1.6 2002/07/31 13:33:04 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/apply.c,v $
** $Revision: 1.6 $
** $Date: 2002/07/31 13:33:04 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.        
*/


#include "apply.h"

// #define APPLYDEBUG 1  

/*
 * Apply Functions.
 * apply_start(), do_apply() are hacks to make modifications easier.
 * apply_single() - apply with a single arg.
 * apply_list()   - apply with a list of arguments.
 * apply_multiple() - apply with var args. (not implemented yet - straightfw)
 *
 * Copyright (C) July 1994, August 2000 Geoff Wong.
 */

extern int overflow_flag, remote_command;
extern int total_offset, num_made;
extern byte *sPC;

/* apply stuff */
int  global_offset = 0;
int  prog_arg = 0;
int  num_made;
char *last_fun;

/* ugly static - bad for multi-threading */
Val apply_val;

static Func * apply_start(Shared *fun, Obj * ob, Obj * oldCO)
{
    Func *prog;

    if (ob->destructed)
    {
        debug_message("apply_single %s in destructed object %s\n",
                      fun->str, ob->name->str);
        return 0;
    }
    Sset_current(ob, "apply_start");  /* must be set before find_program (yuck) */
    prog = find_program(fun, ob->code, Scurrent()->code, 0, 0);

    if (!prog)
    {
        // printf("Unable to find %s in %s\n", fun->str, ob->name->str);
        // Catch(0);
        Sset_current(oldCO, "apply_start 2");
        return 0;
    }

    Catch(0);
    Push(make_object(ob));
    return prog;
}

/*
 * Apply_single sets up the stack frame for a return to the game
 * driver and invokes execute() which starts the stack machine
 * on the appropriate location.
 * - returns true if the function existed hence  
 *   left a value on the stack
 *
 * FIX:  What if it errors out and cleans up the stack?
 */

int apply_one(Shared *fun, Obj * ob, Val * arg)
{
    int  n, loc_num_made = 1;
    Func * prog;

#ifdef APPLYDEBUG
    printf("APPLY_one %s:%s\n", ob->name->str, fun->str);
#endif

    prog = apply_start(fun, ob, Scurrent());

    if (prog == NULL || prog->block == NULL) return 0;

    loc_num_made++;  /* base object on stack */
    n = prog->num_arg;

    /* do the arg */
    if (n >= 1)
    {
        if (arg)
        {
            Push(arg);
        }
        else
        {
            Push(make_space(0));
            loc_num_made = 3;
        }
    }
    while (n > 1)
    {
        Push(make_space(0));
        n--;
        loc_num_made++;
    }
    /* must be set at the end of the function so
     * recursive calls in execute() don't stuff it up */
    if (stype_check(prog->block, prog->num_arg, ob->name->str, fun->str))
    {
        num_made = do_apply(ob, fun, prog, loc_num_made);
    }
    else
    {
        num_made = 0;
        return 0;
    }

    if (num_made < 0)
    {
        num_made = 0;
        return 0;
    }

    return 1;
}

/*
 * Returns a value which must be free'd.
 * (Copied into a supplied var by assign_value)
 *
 * Not reentrant
 */
 
Val * apply_single(Shared * fun, Obj * ob, Val * arg)
{
    if (apply_one(fun, ob, arg)) 
    {
        Clean(&apply_val, num_made);
        return &apply_val;
    }
    return NULL;
}

/*
 * Note: if arg != NULL then we actually clean up 1 more
 * value on our value stack as if since we expect it to be
 * allocated by the programmer 
 */
void apply_clean(Shared * fun, Obj * ob, Val * arg)
{
    if (apply_one(fun, ob, arg)) 
    {
        clean(num_made);
        if (arg != NULL) wipe(1);
    }
}

/*
 * A zero terminated list of args;
 * Especially for call_outs with multiple args (sigh).
 */
void apply_list(Shared *fun, Obj * ob, Val ** args)
{
    int  n, loc_num_made = 1, i = 0;
    Func * prog;

    //printf("  Apply list start rCT=%d\n", (rCT - (int)control)/4);
#ifdef APPLYDEBUG
    printf("APPLY_list %s:%s\n", ob->name->str, fun->str);
#endif
    prog = apply_start(fun, ob, Scurrent());
    if (prog == NULL || prog->block == NULL) return;

    loc_num_made++;  /* base object on stack */
    n = prog->num_arg;

    // do the list 
    while (i < n && args && args[i])
    {
        Push(copy_value(args[i]));
        loc_num_made++;
        i++;
    }

    // fill with zeroes for any args we've missed 
    while (i < n)
    {
        Push(make_space(0));
        loc_num_made++;
        i++;
    }

    if (stype_check(prog->block, prog->num_arg, ob->name->str, fun->str))
    {
        num_made = do_apply(ob, fun, prog, loc_num_made);
    }
    else
    {
        num_made = -1;
    }

    // An error if num_made is set < 0 somewhere
    if (num_made < 0)
    {
        num_made = 0;
        //printf("  Apply list error rCT=%d\n", (rCT - (int)control)/4);
        return;
    }

    clean(num_made);
    //printf("  Apply list done rCT=%d\n", (rCT - (int)control)/4);
    return;
}


static int propogate_error;
/*
 * "Second part" of the apply functions. A hack.
 * requires - Catch(0), args on stack before being called.
 * The "0" return address forces the virtual machine to
 * stop execution and return control to the calling program
 *
 * It should return here and clean up after the error.
 */
int do_apply(Obj * CO, Shared * fun, Func * prog, int loc_num_made)
{
    Stack_code Result;
    char *old_fun = last_fun;
    byte *oldsPC;
    byte * prog_start = 
        (byte *) ((unsigned int) prog->block + prog->num_arg * 3);

#if 0
    printf("do_apply: %s\n", fun->str);
#endif
    propogate_error = 0;

    Pushc(prog->num_arg);           /* # of args */
    Pushc(0);                       /* return address */
    total_offset = global_offset;   /* new total offset */
    Pushc(total_offset);            /* new total offset */
    Pushc(CO);                      /* current object */
    Pushc(prog);                    /* function */
    oldsPC = SgetPC();
    SsetPC(prog_start);

    last_fun = fun->str;            /* set before and after execute */
    Result = Sexecute();
    last_fun = old_fun;             /* because apply can be recursive.. 
                                     * much to my disgust :-)      */
#if 0
    printf("complete_apply (%s): %d (%d) \n", fun->str, (int) Result, (int) oldsPC);
#endif
    if (Result == SE_overflow)
    {
        /* reset it */
        overflow_flag = 0;
        loc_num_made = -1; 
    }
    else if (Result == SE_normal)
    {
        Popcatch();
    }
    else
    {
        /* Result == SE_handled or SE_fatal          */
        /* we've already executed the catch and done */
        /* some cleaning up of the stacks            */
        if (propogate_error)
        {
#if 0
            Execcatch();
#endif
        }
        else
        {
            /* error maybe left on stack... */
            if (Result != SE_fatal) clean(1);
        }
        overflow_flag = 0;
        propogate_error = 1; 
        loc_num_made = -1;  /* ugly overloading of this var */
    }
    SsetPC(oldsPC);
    return loc_num_made;
}

/*
 * locate_program
 *
 * Given an objects and a function - locate the corresponding program
 * to run.
 */

Exec_block locate_program(Obj * ob, Shared * fun)
{
    Exec_block result;

#if 0
    printf("locate_program: %s->%s\n", ob->name->str, fun->str);
#endif

    result.prog = find_program(fun, ob->code, Scurrent()->code, NULL, 0);
    result.var_offset = global_offset;

    return result;
}


/*
 * Nasty function to actually find a function 
 * within an object.
 * 
 * result: pointer to function.
 * side effects: 
 * global_offset - global variable offset for function.
 * prog_arg - num of arguments the function accepts.
 * 
 */

extern int prog_offset_hack;

Func * find_program(Shared * fun, Class * code, Class * current, 
                Shared * inhname, int prev)
{
    Func *pr = 0, *lastpr = 0, *xpr = 0, *grandpr = 0;
    Class * prog_ob;
    int  _i;

    prog_ob = code;

    if (prev == 0)
    {  
        /* search local space */
        lastpr = 0;
#if 0
            printf("Search code %s for %s.\n", code->name->str, fun->str);
#endif
        for (xpr = code->prog; xpr; xpr = xpr->next)
        {
            if (xpr->name == fun)
            {
                if (((int) xpr->type & TY_STATIC) && (current != code))
                {
                    printf("Skipping static function in %s.\n", code->name->str);
                    grandpr = lastpr;
                    lastpr = xpr;
                    continue;
                }
#if 0
                /* move up the chain */
                if (lastpr && grandpr && (lastpr != prog_ob->prog->next))
                {
                    lastpr->next = xpr->next;
                    grandpr->next = xpr;
                    xpr->next = lastpr;
                }
#endif
                break;
            }
            grandpr = lastpr;
            lastpr = xpr;
        }
        pr = xpr;
        if (pr)
        {
            int  igs = 0;

            global_offset = igs;
#if 0
            prog_arg = pr->num_arg;
            printf("found %s at %d.\n", pr->name, pr->block);
#endif
            return pr;
        }
    }

    if (prog_ob->inherit)
    {
        /* look up the hash table */
        for (_i = 0; prog_ob->inherit[_i]; _i++)
        {
            if (inhname)
            {
                if (inhname != prog_ob->inherit[_i]->name)
                    continue;
            }
#if 0
            printf("Hfunction fun %s in %s.\n",
                   fun->str, prog_ob->inherit[_i]->name->str);
#endif
            pr = Hfunction(fun, prog_ob->inherit[_i]->name);
            if (pr)
            {
                if (prog_ob->inherit_offsets)
                {
                    global_offset = prog_ob->inherit_offsets[_i] +
                        prog_offset_hack;
                }
                else
                {
                    global_offset = 0;
                }
                prog_ob = prog_ob->inherit[_i];
                break;
            }
        }
    }

    if (!pr)
    {
        /*free_value(arg); */
        /* should return value to a null program perhaps? */
        global_offset = 0;
#if 0
        prog_arg = 0;
#endif
        return NULL;
    }
    /* Static functions may not be called from outside. */
#if 0
    prog_arg = pr->num_arg;
    printf("Hfound %s at %d.\n", pr->name, pr->block);
#endif
    return pr;
}

#if 0
/*
 * needed for inter_sscanf
 */
char * find_percent(char *str)
{
    while (1)
    {
        str = strchr(str, '%');
        if (str == 0)
            return 0;
        if (str[1] != '%')
            return str;
        str++;
    }
    return 0;
}
#endif

/*
 * All these stupid applies indicate FUCKED initial design.
 * Oh well - that's what happens with an evolving system
 * that is built from linked-lists initially.
 * 
 */
Val ** make_call_args(int have_args,...)
{
    Val **values, *arg;
    va_list args;
    int  i;

    if (have_args)
    {
        va_start(args, have_args);
        values = (Val **) malloc((have_args + 1) * sizeof(Val *));
        values[have_args] = 0;

        for (i = 0; i < have_args; i++)
        {
            arg = va_arg(args, Val *);
            values[i] = (Val *) malloc(sizeof(Val));
            assign_value(values[i], arg);
        }
        va_end(args);
    }
    else
        values = 0;
    return values;
}

Val *caught_clone_object(Shared * s)
{
    Val *ob;

#if 0
    Catch(0);
#endif
    ob = clone_object(s, 0);
#if 0
    if (!error_flag)
    {
        Popcatch();
    }
    else
    {
        error_flag = 0;
    }
#endif
    if (!ob) return Const(0);
    return ob;
}
