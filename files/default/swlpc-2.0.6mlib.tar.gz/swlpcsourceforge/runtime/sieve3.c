/*
 * fast primes generator.
 * print primes, ascending order, 1 for each change in the
 * top DIGITS_CHANGE characters in the (decimal) number.
 * quick hack by cjs@bruce/mmcg@bruce.
 */
extern double sqrt(), ceil(), log();

#define DIGITS_CHANGE 2

#define STORE 1000000

int modmap[8] = { 1, 7, 11, 13, 17, 19, 23, 29 };
int maskmap[30] =
  {	  -1, 0376,   -1,   -1,   -1,   -1,   -1, 0375,   -1,   -1,
	  -1, 0373,   -1, 0367,   -1,   -1,   -1, 0357,   -1, 0337,
	  -1,   -1,   -1, 0277,   -1,   -1,   -1,   -1,   -1, 0177 };
char store[STORE];

/*ARGSUSED*/
main(argc, argv)
int argc;
char **argv;
{
  register int max, lim, limit, prime, base, mod, mask, mult, i;
  double c;

  if(*++argv){
    max = atoi(*argv);
    if(max <= 0 || max > STORE*30)
      max = STORE*30;
    }
  else
    max = STORE*30;
  display(2, 1.0);
  display(3, 2.0);
  display(5, 3.0);
  c = 3.0;
  if(max <= 30){
    for(i = 1; i < 8 && modmap[i] <= max; i++)
      display(modmap[i], ++c);
    exit(0);
    }
  limit = (int)ceil(sqrt((double)max) / 30.0);
  lim = (max+29)/30;
  if(lim < 9)
     base = 9;
  else
     base = lim;
  while(--base > 0)
    store[base] = 0377;
  store[0] = 0376;
  mod = 0;
/*
 * Find all primes up to (at least) the square root of the max
 * prime required.
 */
  for (;;) {
    if (store[base] == 0) {
      do {
        base++;
      } while(store[base] == 0);
      if ( base > limit )
	break;
      mod = 0;
    }
    while ( (store[base] & (1 << mod)) == 0 )
      mod++;
    prime = 30 * base + modmap[mod];
    display(prime, ++c);
    for ( i = 0; i < 8; i++ ) {
      mult = prime * modmap[i];
      mask = maskmap[mult % 30];
      mult /= 30;
      while ( mult < lim ) {
	store[mult] &= mask;
	mult += prime;
      }
    }
  }
  while (base < lim) {
    if ( store[base] ) {
      for (mod = 0; mod < 8; mod++)
	if ( store[base] & (1 << mod) )
	  display(30 * base + modmap[mod], ++c);
      }
    base++;
    }
}

char old[100] = "0", new[100];

display(p, c)
int p;
double c;
{
/*   printf("%8d   %5.1f  %8.5f\n", p, c, log((float)p)/c); */
     sprintf(new, "%d\n", p);
     if (strncmp(old, new, DIGITS_CHANGE)) {
	printf(new);
	strcpy(old, new);
	}
}
