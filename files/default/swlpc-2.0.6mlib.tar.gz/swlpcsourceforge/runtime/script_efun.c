#include <unistd.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/types.h>

#include <math.h>
#include <sys/time.h>
#include <sys/stat.h>
#ifndef __WIN32__
#include <sys/resource.h>
#endif
#include "proto.h"

#include "opcodes.h"
#include "security.h"
#include "comm.h"
#include "consts.h"
#include "interpret.h"
#include "shared.h"
#include "lexer.h"
#include "comm.h"

#ifdef GO32
#include "y_tab.h"
#else
#include "y.tab.h"
#endif

/*#define MOVE_TO_HEAD */
#define DEBUG_EFUNS
#define MAX_EXT_ARGS 16

#define type_check(a,b,c,d) { if (!(a) || !((a)->type & (b))) \
{ type_error(a,b,c,d); return; } }

#define type_checkr(a,b,c,d) { if (!(a) || !((a)->type & (b))) \
{ type_error(a,b,c,d); return 0; } }

extern char load_error[];

#ifdef ARRAY_STATS
extern unsigned int total_array_size, num_arrays;

#endif

extern void *sPC;
extern int current_time;
extern int total_offset, num_made;

void
    RENAME_OBJECT(), 
    OUT_TO_TERM(), 
    NOTHING(),
    CLONE_OBJECT(), 
    THIS_OBJECT(), 
    ENVIRONMENT(), 
    DESTRUCT(), 
    SSHUTDOWN(), 
    SSCANF(), 
    RRANDOM(),
    LIVING(), 
    FIND_OBJECT(), 
    RM(), 
    IS_CLONED(), 
    ALLOCATE(), 
    SIZEOF(), 
    REALP(), 
    INTP(), 
    STRINGP(), 
    OBJECTP(), 
    POINTERP(), 
    PREVIOUS_OBJECT(), 
    EXTRACT(), 
    INT2REAL(), 
    REAL2INT(),
    CALLER(), 
    INDEX()
    ;

/*
 * Inheritance: An object X can inherit from another object Y. This is done
 * with the statement 'inherit "file";' The inherit statement will clone a
 * copy of that file, call reset in it, and set a pointer to Y from X. Y has
 * to be removed from the linked list of all objects. All variables declared
 * by Y will be copied to X, so that X has access to them.
 *
 * If Y isn't loaded when it is needed, X will be discarded, and Y will be
 * loaded separately. X will then be reloaded again.
 */

/*
 * Types are passed in as bit flags for checking here - much nicer
 * stack_error messages.
 */

char tebuff[200];

#ifndef type_check
int type_check(&arg, allowed, who, which)
     Val *arg;
     char *who;
     int  allowed, which;
{

    if (arg && (arg->type & allowed))
        return 1;
    else
#else
int type_error(Val * arg, int allowed, char *who, int which)
{
#endif
    {
        int  t;
        int  ndone = 0;
        char *sep = " ";

/*    int tmpa = allowed; */
        if (!who)
            who = "<unknown>";
        sprintf(tebuff, "Type error in %s (arg %d) - got %s, wanted",
                who, which, (arg ? typename(arg->type) : "<no param>"));
        for (t = 1; t < T_ANY; t <<= 1)
        {
            if (allowed & t)
            {
                allowed = allowed & (~t);
                if (ndone > 0 && (!allowed))
                    sep = " or ";
                sprintf(tebuff + strlen(tebuff), "%s%s", sep, typename(t));
                sep = ", ";
                ndone++;
            }
        }
        strcat(tebuff, ".\n");
/*    if (((tmpa & (~T_STRING)) == T_OBJECT) && arg && (arg->type == T_NUMBER)
 * && (arg->u.number == 0)) {
 * strcat(tebuff, "Integer was zero - destructed object?\n");
 * } */
        efun_error(tebuff);
        return 0;
    }
}

/*
 * Our table of opcode handling routines (for efuns).
 */
/* *INDENT-OFF* */

static struct {
    int tkn;
    void (*fun)();
    }
	ocl[] =
{
    { F_LOAD_SHARED_OBJECT, LOAD_SHARED_OBJECT },
    { F_UNLOAD_SHARED_OBJECT, UNLOAD_SHARED_OBJECT },
    { F_EXT_C_CALL, EXT_C_CALL },
	{ F_RENAME_OBJECT, RENAME_OBJECT },
	{ F_OUT_TO_TERM, OUT_TO_TERM },
	{ F_CLONE_OBJECT , CLONE_OBJECT  },
	{ F_IS_CLONED , IS_CLONED  },
	{ F_THIS_OBJECT , THIS_OBJECT  },
#if 0
    /* FIX */
	{ F_DESTRUCT , DESTRUCT  },
	{ F_CONTENTS , CONTENTS  },
	{ F_ENVIRONMENT , ENVIRONMENT  },
	{ F_PRESENT , PRESENT  },
#endif
	{ F_FIND_OBJECT , FIND_OBJECT  },
	{ F_ALLOCATE , ALLOCATE  },
	{ F_INT2REAL , INT2REAL  },
	{ F_REAL2INT , REAL2INT  },
	{ F_SIZEOF , SIZEOF  },
	{ F_INTP , INTP  },
	{ F_REALP , REALP  },
	{ F_STRINGP , STRINGP  },
	{ F_OBJECTP , OBJECTP  },
	{ F_POINTERP , POINTERP  },
	{ F_PREVIOUS_OBJECT , PREVIOUS_OBJECT  },
	{ F_CALLER , CALLER  },
	{ F_EXTRACT , EXTRACT  },
	{ F_INDEX , INDEX  },
};

/* *INDENT-ON* */


#define	NUM_OPS	(sizeof(ocl) / sizeof(ocl[1]))

/*
 * The +20 is for slop taken up by non-function tokens (i.e.
 * keywords and such) - there's currently 17 of them.
 * The game driver will fail on startup if you need to add more slop -
 * this is an anachronism.
 */

/*
 * This is the real table of function pointers.
 */
struct jumptable
{
    void (*func) ();
    int  numcalls;
    int  flag;
};

struct jumptable extfuncs[F_LASTOP + 1];

void call_efun(int x)
{
#if 0
    printf("call_efun: %d\n", x);
#endif
    (extfuncs[x].func) ();
}

/*
 * Install the opcode table in the oc function list
 */

void install_oc()
{
    int  x;

    for (x = 0; x <= F_LASTOP; x++)
    {
        extfuncs[x].func = NOTHING;
        extfuncs[x].numcalls = 0;
    }

    for (x = 0; x < NUM_OPS; x++)
    {
        if (ocl[x].tkn > (F_LASTOP))
            fatal("Opcode installation (%d/%d)- token value too high\n", x, ocl[x].tkn);
        extfuncs[ocl[x].tkn].func = ocl[x].fun;
    }
    initfixedints();
}

/* Ok, this is inefficient (O(N^2)), but pretty damn rare.
 * If I wanted speed, I'd use qsort.
 */

int dump_oc_profile(int top)
{
    int  x, y;
    int  div;
    int  highval;
    int  tot = 0;
    char out[100];

    for (x = 0; x <= F_LASTOP; x++)
    {
        tot += extfuncs[x].numcalls;
        extfuncs[x].flag = 0;  /* have we printed it :) */
    }
    if (!top)
        top = tot = 1;

    add_message("Opcode stats:\n");
    div = tot / top;
    highval = 0;
    for (x = 0, y = 0; x <= F_LASTOP; x++)
    {
        int  v = (extfuncs[x].numcalls / div);

        if (v)
        {
            if (++y > 5)
            {
                y = 0;
                add_message("\n");
            }
            sprintf(out, " %d: %-7d", x, v);
            add_message(out);
        }
    }
    return 0;
} 


void NOTHING()
{
    fatal("Unimplemented function called\n");
}

void IS_CLONED()
{
    Val  arg1;

    Pop(&arg1);
    type_check(&arg1, T_OBJECT, "is_cloned", 1);
    Push(make_number(arg1.u.ob->cloned != 0));
}

void CLONE_OBJECT()
{
    Val  arg1, arg2, *ret;
    char *tmp = 0;
    Obj *oldCO = Scurrent();
    Shared * stmp = NULL;

    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg1, T_STRING | T_OBJECT, "clone_object", 1);
    if (arg2.type == T_STRING)
    {
        type_check(&arg2, T_STRING, "clone_object", 2);
        /* make new name from current_object */
        tmp = (char *) malloc(arg2.u.string->length +
                              Scurrent()->name->length + 2);
        strcpy(tmp, Scurrent()->name->str);
        strcat(tmp, "/");
        strcat(tmp, arg2.u.string->str);
        stmp = string_copy(tmp);
        free(tmp);
        if (find_object2(stmp))
        {
            free_string(stmp);
            Push(Const(0));
            return;
        }
        /* check it doesn't exists already otherwise return */
    }
    if (arg1.type == T_STRING)
        ret = clone_object(arg1.u.string, stmp);
    else
        ret = ob_clone_object(arg1.u.ob->code, stmp);

    if (stmp) free_string(stmp);

    if (!ret)
    {
        efun_error("Failed to clone object (%s).\n", load_error);
        return;
    }
    Sset_current(oldCO, "clone_object");
    Push(ret);
}

void RENAME_OBJECT()
{
    Val  arg, arg2;
    Obj *o1;
    Shared *s;

    Pop(&arg2);
    Pop(&arg);
    type_check(&arg, T_OBJECT | T_STRING, "rename_object", 1);
    type_check(&arg2, T_STRING, "rename_object", 1);
    if (arg.type == T_STRING)
        o1 = find_object2(arg.u.string);
    else
        o1 = arg.u.ob;
    if (!o1)
    {
        Push(Const(0));
        return;
    }
    /* normal people have to rename things to a suffix of their own name 
     * (preferably with a preceding slash) */
    if (Scurrent()->level < GOD && strncmp(arg2.u.string->str,
                        Scurrent()->name->str, Scurrent()->name->length))
    {
        efun_error("No permission to change to %s", arg2.u.string->str);
        return;
    }

    if (find_object2(arg2.u.string))
    {
        efun_error("rename_object: already an object named %s",
                   arg2.u.string->str);
        return;
    }
    if (Scurrent()->level < o1->level)
    {
        efun_error("Not enough permission to change name of %s",
                   o1->name->str);
        return;
    }
    s = o1->name;
    remove_object_hash(o1);
    // if (o1->inherited) remove_functions(o1, o1);

    /* o1->name = string_inc_ref(arg2.u.string); */
    o1->name = shared_string_copy(arg2.u.string);

    /* obj names are in str space ... */
    free_string(s);  

/*        o1->name_length = strlen(o1->name); */
    enter_object_hash(o1);
    // if (o1->inherited) add_functions(o1, o1, 0);
    Push(make_object(o1));
}

void FIND_OBJECT()
{
    Val  arg;
    Obj *o1;

    Pop(&arg);
    type_check(&arg, T_STRING, "find_object", 1);
    o1 = find_object2(arg.u.string);
    if (!o1)
        Push(Const(0));
    else
        Push(make_object(o1));
}

void CALLER()
{
    caller();
}

#if 0
void CONTENTS()
{
    Val  arg, *ret;

    Pop(&arg);
    type_check(&arg, T_STRING | T_OBJECT, "contents", 1);
    ret = contents(&arg);
    if (!ret)
        return;  /* error */
    Push(contents(&arg));
}

void ENVIRONMENT()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_NUMBER)
    {
        arg.type = T_OBJECT;
        arg.u.ob = Scurrent();
    }
    else
    {
        type_check(&arg, T_STRING | T_OBJECT, "environment", 1);
    }
    Push(environment(&arg));
}
#endif

void THIS_OBJECT()
{
    Val *p;

#if 0
    if (Scurrent()->destructed)
        Push(Const(0));
    else
    {
#endif
        p = make_object(Scurrent());
        Push(p);
#if 0
    }
#endif
}

void PREVIOUS_OBJECT()
{
    previous_object();
}


float
     getreal(Val * v)
{
    type_checkr(v, T_REAL | T_NUMBER, "get_real (internal)", 1);
    if (v->type == T_NUMBER)
        return (float) v->u.number;
    return (float) v->u.real;
}

void REAL2INT()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_REAL | T_NUMBER, "real2int", 1);
    if (arg.type == T_NUMBER)
        Push(make_number(arg.u.number));
    else
        Push(make_number((int) (arg.u.real)));
}


void INT2REAL()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_NUMBER, "int2real", 1);
    Push(make_real(getreal(&arg)));
}

#if 0
void constinvert(Val * v)
{
    type_check(v, T_NUMBER, "constinvert (internal)", 1);
    if (v->type == T_NUMBER && v->u.number == 0)
        Push(Const(1));
    else
        return;
}
#endif

void INTP()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_NUMBER)
        Push(Const(1));
    else
        Push(Const(0));
}

void REALP()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_REAL)
        Push(Const(1));
    else
        Push(Const(0));
}

void STRINGP()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_STRING)
        Push(Const(1));
    else
        Push(Const(0));
}

void OBJECTP()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_OBJECT)
        Push(Const(1));
    else
        Push(Const(0));
}

void POINTERP()
{
    Val  arg;

#if 0
    printf("In pointerp()\n");
#endif
    Pop(&arg);
    if (arg.type == T_POINTER)
        Push(Const(1));
    else
        Push(Const(0));
}

void EXTRACT()
{
    Val  arg, arg1, arg2, *ret;
    Vec *pv;
    int  len, start, finish;
    char *newS;

    Pop(&arg2);
    Pop(&arg1);
    Pop(&arg);
    type_check(&arg2, T_NUMBER, "extract", 3);
    type_check(&arg1, T_NUMBER, "extract", 2);
    type_check(&arg, T_STRING | T_POINTER, "extract", 1);

#if 0
    printf("In EXTRACT()\n");
#endif

    if (arg1.u.number < 0)
    {
        efun_error("Second argument to extract should be >= 0\n");
        return;
    }

    start = arg1.u.number;

    /* below is kind of ugly - a backward comp. hack - FUCK! - D */
    if (!arg2.u.number && (arg2.u.number < arg1.u.number))
    {
        /* no arg (not sure nowdays :() ? -- set it to the end. */
        if (arg.type == T_STRING)
            finish = arg.u.string->length - 1;
        else
            finish = arg.u.vec->size - 1;
    }
    else
    {
        finish = arg2.u.number;
    }

    if (arg.type == T_STRING)
        len = arg.u.string->length;
    else
        len = arg.u.vec->size;

    if (finish >= len)
        finish = len - 1;

    if (finish < start || start >= len)
    {  /* urk! */
        if (arg.type == T_STRING)
            Push(make_string(""));
        else
            Push(allocate_array(0));
        return;
    }
    if (arg.type == T_STRING)
    {
        newS = malloc(finish - start + 2);
        strncpy(newS, arg.u.string->str + start, finish - start + 1);
        newS[finish - start + 1] = '\0';
        ret = make_string(newS);
#if 0
    printf("In EXTRACT() returning string: %s\n", newS);
#endif
        Push(ret);
        free(newS);
        return;
    }
    else
    {
        pv = create_vector(finish - start + 1, "EXTRACT()");
        copy_in_vector(pv, arg.u.vec, 0, start, finish - start + 1);
        pv->ref = 0;  /* because make_vector incs it by 1 */
        Push(make_vector(pv));
        return;
    }
}


void OUT_TO_TERM()
{
    Val  arg;

    if (Scurrent() == 0)
    {
        Pop(&arg);
        Push(Const(0));
        return;
    }
    Pop(&arg);
    type_check(&arg, T_STRING, "out_to_term", 1);
#if 0
    printf("out_to_term (%s): #%s#\n", Scurrent()->name, arg.u.string);
    add_output(Scurrent()->interactive, 1, arg.u.string);
#endif
    puts(arg.u.string->str);
    // printf("%s", arg.u.string->str);
    fflush(stdout);
    Push(Const(0));
}

void ALLOCATE()
{
    Val  ret;

#if 0
    printf("efun allocate().\n");
#endif
    Pop(&ret);
    type_check(&ret, T_NUMBER, "allocate", 1);
    Push(allocate_array(ret.u.number));
}


#if 0
void DESTRUCT()
{
    Val * arg, ret;
    Val *a;

    Pop(&ret);
    type_check(&ret, T_OBJECT, "destruct", 1);
    a = make_object(Scurrent());
    arg = apply_single(C("query_destruct"), ret.u.ob, a);
    if (arg)
    {
        if (arg->type == T_NUMBER && arg->u.number != 0
            && Scurrent()->level < ret.u.ob->level)
        {
            Push(Const(0));
            return;
        }
        free_value(arg);
    }
    /* need to clean up after errors - hmm */
    /* returns 0 on error ! */
    if (!destruct_object(ret.u.ob))
        return;
    Push(Const(1));
}
#endif


void SIZEOF()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_STRING | T_POINTER, "sizeof", 1);
    if (arg.type == T_STRING)
        Push(make_number(arg.u.string->length));
    else
        Push(make_number(arg.u.vec->size));
}


#if 0
void REGEXP()
{
    Val  arg1, arg2, *ret;

    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg1, T_STRING, "regexp", 1);
    type_check(&arg2, (T_STRING | T_POINTER), "regexp", 2);
    ret = lregexp(arg1.u.string->str, &arg2);
    if (!ret)
        return;  /* error */
    Push(ret);
}

/* Speed efun: could be made obsolete */
void PRESENT()
{
    Val  arg1, arg2;

    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg1, T_STRING | T_OBJECT, "present", 1);
    if (arg2.type == T_NUMBER)
    {
        arg2.type = T_OBJECT;
        arg2.u.ob = Scurrent();
    }
    type_check(&arg2, T_OBJECT, "present", 2);
    if (arg2.u.ob->destructed)
    {
        efun_error("present() on destructed object.\n");
        return;
    }
    Push(object_present(&arg1, arg2.u.ob));
}
#endif

/* Speed efun() */
void INDEX()
{
    Val  arg1, arg2, arg3, arg4;

    Pop(&arg4);
    Pop(&arg3);
    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg4, T_NUMBER, "index", 4);
    type_check(&arg3, T_NUMBER, "index", 3);
    /* type_check(&arg2, T_ANY, "index", 2); */
    type_check(&arg1, T_STRING | T_POINTER, "index", 1);
    Push(make_number(
                 search_array(&arg1, &arg2, arg3.u.number, arg4.u.number)));
}


