/*
 *                 Author:  Christopher G. Phillips
 *              Copyright (C) 1993 All Rights Reserved
 *
 *                              NOTICE
 *
 * Permission to use, copy, modify, and distribute this software and
 * its documentation for any purpose and without fee is hereby granted
 * provided that the above copyright notice appear in all copies and
 * that both the copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * The author makes no representations about the suitability of this
 * software for any purpose.  This software is provided ``as is''
 * without express or implied warranty.
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <gdbm.h>
#include "leak.h"

#undef malloc
#undef realloc
#undef free
#undef calloc

#define FILE_GDBMFILENAME	"filedbm"
#define MEMORY_GDBMFILENAME	"memdbm"

int	leak_logging = 1;

typedef char	*DPTR;

static GDBM_FILE	filedbm = NULL;
static GDBM_FILE	memdbm = NULL;
static int	nextfile = -1;
static int	dbms_zapped = 0;

struct memdata {
	size_t	size;
	int	file;
	int	line;
};

static void
opendbmfile(GDBM_FILE *dbmp, /*const*/ char *file)
{
	if (*dbmp == NULL && (*dbmp = gdbm_open(file, O_RDWR | O_CREAT,
	  S_IRUSR | S_IWUSR, GDBM_NEWDB, 0)) == NULL) {
		perror("dbm_open");
		exit(1);
	}
}

static int
file2int(const char *file)
{
	datum	key, data;

	key.dptr = (DPTR)file;
	key.dsize = strlen(file) + 1;
	data = gdbm_fetch(filedbm, key);
	if (data.dptr) {
		int	i;

		(void)memcpy(&i, data.dptr, sizeof i);
		return i;
	} else {
		++nextfile;
		data.dptr = (DPTR)&nextfile;
		data.dsize = sizeof nextfile;
		if (gdbm_store(filedbm, key, data, GDBM_INSERT) < 0) {
			perror("dbm_store");
			exit(1);
		}
		return nextfile;
	}
}

static char *
int2file(int file)
{
	datum	key, data;
	int	i;

	for (key = gdbm_firstkey(filedbm); key.dptr;
	  key = gdbm_nextkey(filedbm, key)) {
		data = gdbm_fetch(filedbm, key);
		if (data.dptr == NULL) {
			perror("dbm_fetch");
			continue;
		}
		(void)memcpy(&i, data.dptr, sizeof i);
		if (i == file)
			return key.dptr;
	}
	return "???";
}

static void
leak_fclear(void)
{
	if (filedbm)
		(void)dbm_close(filedbm);
	(void)remove(FILE_GDBMFILENAME ".dir");
	(void)remove(FILE_GDBMFILENAME ".pag");
	filedbm = NULL;
}

void
leak_clear(void)
{
	if (memdbm)
		(void)gdbm_close(memdbm);
	(void)remove(MEMORY_GDBMFILENAME ".dir");
	(void)remove(MEMORY_GDBMFILENAME ".pag");
	memdbm = NULL;
}

void
leak_insert(const void *p, size_t size, const char *file, int line, int mode)
{
	struct memdata	md;
	datum		key, data;

	if (!dbms_zapped) {
		leak_clear();
		leak_fclear();
		dbms_zapped = 1;
	}
		
	if (!filedbm)
		opendbmfile(&filedbm, FILE_GDBMFILENAME);
	if (!memdbm)
		opendbmfile(&memdbm, MEMORY_GDBMFILENAME);

	md.file = file2int(file);

	md.size = size;
	md.line = line;
	key.dptr = (DPTR)&p;
	key.dsize = sizeof p;
	data.dptr = (DPTR)&md;
	data.dsize = sizeof md;

	if (gdbm_store(memdbm, key, data, mode) == -1) {
		perror("dbm_store");
		exit(1);
	}
}

void
leak_delete(const void *p, const char *file, int line)
{
	struct memdata	md;
	datum		key, data;

	if (!dbms_zapped) {
		leak_clear();
		leak_fclear();
		dbms_zapped = 1;
	}

	key.dptr = (DPTR)&p;
	key.dsize = sizeof p;

	if (!memdbm)
		opendbmfile(&memdbm, MEMORY_GDBMFILENAME);
	if (gdbm_delete(memdbm, key) == -1) {
		fprintf(stderr,
		  "free unmalloced pointer %p from \"%s\", line %d\n", p, file,
		  line);
	}
}

void
leak_dump(void)
{
	struct memdata	md;
	datum		key, data;
	void		*addr;
	int		do_title = 1;

	if (!filedbm)
		opendbmfile(&filedbm, FILE_GDBMFILENAME);
	if (!memdbm)
		opendbmfile(&memdbm, MEMORY_GDBMFILENAME);

	for (key = gdbm_firstkey(memdbm); key.dptr; 
				key = gdbm_nextkey(memdbm, key)) {
		data = gdbm_fetch(memdbm, key);
		if (data.dptr == NULL) {
			perror("dbm_fetch");
			continue;
		}
		if (do_title) {
			int	i;

			printf("Nonfreed blocks:\n");
			printf("Address \tSize\tLine\tFile\n");
			for (i = 0; i < 36; i++)
				putchar('-');
			putchar('\n');
			do_title = 0;
		}
		/*
		 * Copy the key and data
		 * because they may be overwritten in int2file.
		 */
		md = *(struct memdata *)data.dptr;
		addr = *(void **)key.dptr;
#ifndef sun
		printf("%08p\t%d\t%d\t%s\n", addr,
#else
		printf("%08x\t%d\t%d\t%s\n", (int)addr,
#endif
		  md.size, md.line, int2file(md.file));
	}
}

void *
leak_malloc(size_t size, const char *file, int line)
{
	void	*ptr = malloc(size);

	if (leak_logging && ptr)
		leak_insert(ptr, size, file, line, GDBM_INSERT);

	return ptr;
}

void *
leak_realloc(void *oldptr, size_t size, const char *file, int line)
{
	void	*newptr = realloc(oldptr, size);

	if (leak_logging) {
		if (!size && oldptr)
			leak_delete(oldptr, file, line);
		else if (newptr) {
			if (newptr == oldptr)
				leak_insert(newptr, size, file, line,
				  GDBM_REPLACE);
			else {
				if (oldptr)
					leak_delete(oldptr, file, line);
				leak_insert(newptr, size, file, line,
				  GDBM_INSERT);
			}
		}
	}

	return newptr;
}

void
leak_free(void *ptr, const char *file, int line)
{
	free(ptr);

	if (leak_logging && ptr)
		leak_delete(ptr, file, line);
}

void *
leak_calloc(size_t s, size_t t, const char *file, int line)
{
	void	*ptr = calloc(s, t);

	if (leak_logging && ptr)
		leak_insert(ptr, s * t, file, line, GDBM_INSERT);

	return ptr;
}

void
dump_malloc_data() {
#if 0
add_message("Using leak malloc\n");
#endif
}

