/*
 * Stats.h - interface to the stats package.
 * Provides some macros -
 *    STAT_INIT(stat, flags, type, package, printname)
 *    STAT_INC(stat), STAT_DEC(stat)
 *    STAT_ADD(stat), STAT_SUB(stat)
 *
 * STAT_INIT should be called from your package's initialisation
 * routine to register each stat with the stats package (it passes
 * the #defined name and variable declaration).  The "stat" parameter
 * should have been created using the %token comment hack (generates
 * a #define entry; should use an enum type, but have more control over
 * non-recompilation if we use #defines).
 * NB: STAT_ADD, etc, can all be used before STAT_INIT to alleviate
 * some obvious startup programming difficulties.
 */

extern struct stats {
	int value;
	int flags;	/* usage type */
	char * type;	/* memory, etc */
	char * package;	/* package generating those stats */
	char * printfmt;/* and how to show it */
	}
	    **stat_table;

#define	STAT_TOTAL_TYPE		0x1	/* should this be added to totals for that type? */
#define	STAT_TOTAL_PACK		0x2	/* in totals for the package? */

#define	STAT_INIT(name, flags, usetype, package, printfmt)	\
	register_stat(name, flags, usetype, package, printfmt);

#define	STAT_INC(x)	stat_table[x].value++;
#define	STAT_DEC(x)	stat_table[x].value--;

#define	STAT_ADD(x, v)	stat_table[x].value += (v);
#define	STAT_SUB(x, v)	stat_table[x].value -= (v);

extern void register_stat _P((int, int, char *, char *, char *));

/* Grab the definitions of stat values, for people who forget */
#include "stats.Gen.h"
