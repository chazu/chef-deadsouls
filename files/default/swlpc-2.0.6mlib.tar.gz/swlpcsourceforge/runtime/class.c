//
// Some simple functions to support 
// classes (independent of objects)
//
// Author: Geoff Wong, September 2001
//         geoff@shattered.org
//

#include "lpc.h"
#include <assert.h>
#include "object.h"
#include "function.h"
#include "hash.h"
#include "ehash.h"

// #define CLASS_DEBUG 

void add_class_ref(Class * code, const char * from)
{
#if 0
    if (code->name)
        printf("Adding class ref %s from %s\n", code->name->str, from);
    else
        printf("Adding class ref to unknown from %s\n", from);
#endif
    code->ref++;
}

void free_class(Class * code, const char * from)
{
    int i = 0;

#ifdef CLASS_DEBUG
    printf("Attempt to free class %s (%d)\n", code->name->str, code->ref);
#endif
    assert(code->ref > 0);
    code->ref--;
    if (code->ref > 0) return;
        
    // remove it from the class table
    if (!remove_class(code))
    {
        printf("UNABLE to free class %s\n", code->name->str);
    }

    // Free global tables
    free_global_tables(code);
    
    // Ok - free up stuff it inherits.
    if (code->inherit != NULL)
    {
        while (code->inherit[i++] != 0) free_class(code->inherit[i-1], from);
        free(code->inherit);
        code->inherit = NULL;
        // CHECK:
        free(code->inherit_offsets);
        code->inherit_offsets = NULL;
    }

    // Free the program 
    free_prog(code->prog);
    code->prog = NULL;

    free_string(code->name);
    code->name = NULL;

    free(code);
}

Class * get_empty_class()
{
    Class * ret;

    ret = malloc(sizeof(Class));
    memset(ret, '\0', sizeof(Class));

    return ret;
}


// Need a hash table arrangement for classes and rapid
// class lookup

#define CLASS_TABLE_SIZE 7103
Hash_table * class_table;

int class_ele_hash(void * ele)
{
    Class * code; 

    code = (Class *)ele;
    return esumstr(code->name);
}


int class_key_hash(void * key)
{
    Shared * str;

    str = (Shared *)key;
    return esumstr(str);
}

int class_match(void * ele, void * key)
{
    Class * code; 
    Shared * str;

    code = (Class *)ele;
    str = (Shared *)key;

    return (code->name == str);
}

void init_class_table()
{
    class_table = make_hash_table(CLASS_TABLE_SIZE, class_ele_hash,
                    class_key_hash, class_match);
}

Class * find_class(Shared * name)
{
    Class * ret;
    ret = find_hash(class_table, name);
#ifdef CLASS_DEBUG
    //if (ret) printf("Found class: %s\n", name->str);
    //else printf("CLASS NOT FOUND: %s\n", name->str);
#endif
    return ret;
}

int remove_class(Class * code)
{
    int ret;
#ifdef CLASS_DEBUG
    printf("Removing class: %s (%d)\n", code->name->str, code->ref);
#endif
    ret = remove_hash(class_table, code->name);
    if (ret)
    {
        if (code->inherited) remove_functions(code,code);
    }
#ifdef CLASS_DEBUG
    else
    {
        printf("FAILED to remove class: %s\n", code->name->str);
    }
#endif
    return ret;
}

Shared * new_class_name(Shared * str)
{
    static int i;
    char *p = malloc(str->length + 10);  /* +10 is a LOT of names! */
    Shared * q;
    do
    {
        (void) sprintf(p, "%s#%d", str->str, i);
        q = string_copy(p);
        i++;
    }
    while (find_class(q));
    free(p);
    free_string(str);
    return q;
}

void rename_class(Class * code)
{
    // Remove
    remove_class(code);

    // Rename it
    code->name = new_class_name(code->name);

    // Re-add.
    add_class(code);
}

int add_class(Class * code)
{
    int ret = 0;
    if (code == NULL) return 0;

    if (find_class(code->name))
    {
#ifdef CLASS_DEBUG
        printf("Adding an already existing class: %s\n", code->name->str);
#endif
    }
    else
    {
#ifdef CLASS_DEBUG
        printf("Adding class: %s (%d)\n", code->name->str, code->ref);
#endif
        ret = add_hash(class_table, code);
    }

#ifdef CLASS_DEBUG
    if (!ret)
    {
        printf("FAILED to add class: %s\n", code->name->str);
    }
#endif

    return ret;
}

// Class - function  hash table stuff
void add_functions(Class * code, Class * which_obj, short offset)
{
    int  _i;
    Func *pr;

    for (pr = code->prog; pr; pr = pr->next)
    {
        add_Hfunction(pr, which_obj->name, (int) offset);
    }
    if (code->inherit)
    {
        for (_i = 0; code->inherit[_i]; _i++)
        {
            add_functions(code->inherit[_i], which_obj,
                          offset + code->inherit_offsets[_i]);
        }
    }
}

void remove_functions(Class * obj, Class * which_obj)
{
    int  _i;
    Func *pr;

    for (pr = obj->prog; pr; pr = pr->next)
    {
        remove_Hfunction(pr->name, which_obj->name);
    }
    if (obj->inherit)
    {
        for (_i = 0; obj->inherit[_i]; _i++)
        {
            remove_functions(obj->inherit[_i], which_obj);
        }
    }
}

void free_all_classes()
{
    int i;
    Hash_element tmp;
    Class * tmpc;

    for (i = 0; i < class_table->size; i++)
    {
        tmp = class_table->table[i];
        while (tmp != NULL)
        {
            if (tmp)
            {
                tmpc = (Class *)tmp->element;
                tmp = tmp->next;
                free_class(tmpc, "free_all_classes");
            }
        }
    }
}

