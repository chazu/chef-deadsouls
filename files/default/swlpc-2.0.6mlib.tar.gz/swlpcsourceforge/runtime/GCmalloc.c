

/*
** $Id: GCmalloc.c,v 1.1.1.1 2001/09/11 04:12:24 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/GCmalloc.c,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:24 $
** $State: Exp $
**
** Author: Mike McGaughey
** Copyright(C) 1993-1998
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.        
*/

/*
 * Don't include anything else, they fuck this file.
 */

/* 
 * These defines mimic those under which GC was made.  Failure
 * to fix them isn't fatal, but may result in wierd stats.
 * CFLAGS= -O -DALL_INTERIOR_POINTERS -DSILENT -DGATHERSTATS
 */

#define ALL_INTERIOR_POINTERS
#define	SILENT
#define	GATHERSTATS
/* #define	FIND_LEAK */

#include <gc/gc_priv.h>

/* GC malloc stub; just returns "no stats" */

#define in_KB(x)	(((float)(x)) * sizeof(GC_word) / 1024)
void dump_malloc_data() 
{ 
	float tot_time = 0;
	float last_time = 0;
	float last_duration = 0;
	clock_t now;
	char buff[10000];

	GET_TIME(now);
	sprintf(buff, "Garbage Collection: Heap size: %1.1fK\n"
		      "Currently:\n"
		      "\tIn use: %1.1fK atomic, %1.1fK composite\n"
		      "\tTotal GCs: %lu; Total time: %1.2fs\n"
		      "Since Last GC:\n"
		      "\tAllocated: %1.1f\n"
		      "\tFragmentation loss: %1.1f\n"
		      "\tExplicitly freed: %1.1f\n"
		      "Last GC:\n"
		      "\tOccurred %1.2fs ago; duration %1.2fs\n"
		      "Before last GC:\n"
		      "\tAlloced (total): %1.1f\n"
		      ,
		      in_KB(GC_heapsize) / sizeof(GC_word),	/* it's in bytes */
		      in_KB(GC_atomic_in_use),
		      in_KB(GC_composite_in_use),
		      GC_gc_no,
		      tot_time,
		      in_KB(GC_words_allocd),
		      in_KB(GC_words_wasted),
		      in_KB(GC_mem_freed),
		      last_time,
		      last_duration,
		      in_KB(GC_words_allocd_before_gc)
		      );
	add_message(buff);
}

