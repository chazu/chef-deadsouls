/*
 *                 Author:  Christopher G. Phillips
 *              Copyright (C) 1993 All Rights Reserved
 *
 *                              NOTICE
 *
 * Permission to use, copy, modify, and distribute this software and
 * its documentation for any purpose and without fee is hereby granted
 * provided that the above copyright notice appear in all copies and
 * that both the copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * The author makes no representations about the suitability of this
 * software for any purpose.  This software is provided ``as is''
 * without express or implied warranty.
 */

#ifndef H_LEAK
#define H_LEAK

#include <sys/types.h>

extern int	leak_logging;
extern void	leak_dump(void);
extern void	leak_clear(void);

extern void	*leak_malloc(size_t, const char *, int);
extern void	*leak_realloc(void *, size_t, const char *, int);
extern void	leak_free(void *, const char *, int);
extern void	*leak_calloc(size_t, size_t, const char *, int);

#ifdef FIND_LEAKS

#define malloc(s)	leak_malloc(s, __FILE__, __LINE__)
#define realloc(p, s)	leak_realloc(p, s, __FILE__, __LINE__)
#define free(p)		leak_free(p, __FILE__, __LINE__)
#define calloc(s, t)	leak_calloc(s, t, __FILE__, __LINE__)

#endif /* FIND_LEAKS */

#endif /* H_LEAK */
