

/*
** $Id: consts.c,v 1.2 2002/05/19 09:13:26 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/consts.c,v $
** $Revision: 1.2 $
** $Date: 2002/05/19 09:13:26 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1993-1998
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.        
*/

#include <stdio.h>
#include "stack.h"

/* when changing this make sure consts.h is corrected too! */
char * constant_strings[] = { 
"*InitGlobals",
"*NukeDestruct",
"FindObject",
"RO/emulate",
"RO/shut",
"RO/void",
"What ?",
"add_weight",
"bad.log",
"can_put_and_get",
"catch_action",
"catch_input",
"catch_output",
"catch_shout",
"catch_tell",
"compile_error",
"dgram_recv",
"drop",
"exit",
"external_restore",
"flush_output",
"get",
"heart_beat",
"id",
"init",
"insert",
"logon",
"new_logon",
"query_destruct",
"query_homepwd",
"query_no_external_restore",
"query_no_external_save",
"query_pwd",
"query_real_name",
"query_soul",
"query_term_type",
"query_weight",
"query_wiz",
"quit",
"reset",
"secure/connect",
"secure/connect2",
"secure/master",
"set_prompt",
"set_this_player",
"shut",
"this_player",
"valid_read",
"valid_write", 
0
};

Shared ** str_consts = NULL;
static int const_length = 0;

void
init_str_consts(void)
{
int i;
	for (const_length = 0; constant_strings[const_length] != NULL;
				 const_length++);
	str_consts = (Shared **)malloc(const_length * sizeof(char *));
	for (i = 0; i < const_length; i++) {
		str_consts[i] = string_copy(constant_strings[i]);
	}
}

Shared *
C(char * str)
{
    int min = 0, max = const_length - 1, half, v = 0;

	if (!str || *str == 0) 
    {
		fprintf(stderr, "Constant string \"%s\" not found!\n", str);
		fatal("String constant fuckup.\n");
	}

	half = (min + max + 1) / 2;
	while (*str != constant_strings[half][0] || 
			(v = strcmp(str, constant_strings[half]))) {
	    if (max == half || min == half) {
		/* bad - constant not found! */
		fprintf(stderr, "Constant string \"%s\" not found!\n", str);
		fatal("String constant fuckup.\n");
		}
	    if (*str > constant_strings[half][0] || v > 0) {
		    min = half;
		    half = (min + max + 1) / 2;
	    }
	    else if (*str < constant_strings[half][0] || v < 0) {
		    max = half;
		    half = (min + max) / 2;	
	    }
	    v = 0;
	}
	return str_consts[half];	
}
