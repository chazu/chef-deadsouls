/*
 * Function and code interface.
 *
 * Each function in an object (or type) has a
 *	name - the string name used to call it
 *	arguments - for each argument we store its possible types and possibly
 *		    some checking code for the function header
 *	
 */

struct function {
	char * name;
	struct type_def 
	int nargs;	/* num args installed into local variables */
	struct type * rettype;
	struct argtype * arglist;
	struct code * code;
	}
