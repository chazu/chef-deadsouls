

/*
** $Id: fsecure.h,v 1.1.1.1 2001/09/11 04:12:30 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/fsecure.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:30 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _FSECURE_H
#define _FSECURE_H

#include "stack.h"
#include "apply.h"
#include "gd_config.h"

void 
    init_object_su(Obj *ob, Shared *origname, int addon)
    ;

int 
    force_no_su(Shared *fname),
    get_object_level(Shared *o, int add),
    lower_level(Obj *o1, Obj *o2),
    o_append_ok(Obj * ob, Shared * file),
    o_dir_read_ok(Obj *ob, Shared *file),
    o_read_ok(Obj *ob, Shared *file),
    o_save_ok(Obj *ob, Shared *file),
    o_write_ok(Obj * ob, Shared *file),
    p_append_ok(Shared *suname, int olevel, Shared *file),
    p_read_ok(Shared *suname, int olevel, Shared *file),
    p_write_ok(Shared *suname, int olevel, Shared *file),
    set_file_su(Shared *fname, int val),
    setuid_me(Obj *from, Obj *to, int level, Shared *name),
    valid_filename(Shared *str)
    ;

Shared 
    * check_file_name(Shared *file, int writeflg, Obj *who),
    * get_wname(Shared *obname);

#endif
