#include <../config.h>
#include <unistd.h>
#ifdef HAVE_CRYPT_H
#include <crypt.h>
#endif
#include <ctype.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>

#ifndef __WIN32__
#include <arpa/inet.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <sys/resource.h>
#endif

#include <math.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <dirent.h>
#include <assert.h>
#include "proto.h"

#include "comm.h"
#include "consts.h"
#include "interpret.h"
#include "shared.h"
#include "obj.h"
#include "lexer.h"

#ifdef GO32
#include "y_tab.h"
#else
#include "y.tab.h"
#endif

#include "opcodes.h"
#include "security.h"

/*#define MOVE_TO_HEAD */
/* #define DEBUG_EFUNS */
#define MAX_EXT_ARGS 16

#define type_check(a,b,c,d) { if (!(a) || !((a)->type & (b))) \
{ type_error(a,b,c,d); return; } }

#define type_checkr(a,b,c,d) { if (!(a) || !((a)->type & (b))) \
{ type_error(a,b,c,d); return 0; } }

extern char load_error[];

#ifdef ARRAY_STATS
extern unsigned int total_array_size, num_arrays;

#endif

extern Shared *last_verb;
extern int current_time;
extern int total_offset, num_made;

extern int command_for_object(Shared * str, Obj * ob);
extern int remove_file(Shared *path);

int  subhash(Val * v);

#ifdef BIT_STRINGS
void SET_BIT(), TEST_BIT(),
#endif

void
SETUID(), QUERY_FILE(), QUERY_LEVEL(), QUERY_SU_NAME(), THROW(),
RENAME_OBJECT(), WRITE(), OUT_TO_TERM(),
SENDTO(), MOVE_OBJECT(), OUT_BINARY(), QUERY_LOAD_AVERAGE(),  HASH_VALUE(),
TOGGLE_ECHO();

void
ATOI(), ATOR(), CLONE_OBJECT(), THIS_OBJECT(), SAVE_OBJECT(), RESTORE_OBJECT(),
ENVIRONMENT(), PRESENT(), DESTRUCT(), STRLEN(),
SSHUTDOWN(), SSCANF(), ENABLE_COMMANDS(), RRANDOM(),
 xCRYPT(), LS(), FIND_LIVING();

void TELL_OBJECT(), LED(), LIVING(), LOWER_CASE(), CAPITALIZE(), SSNOOP(),
SET_IP_NUMBER(), FIND_OBJECT(), RM(),
IS_CLONED(), TIME(), QUERY_IP_NUMBER(), NOTHING(),
CREATOR(), NCALL_OUT(), CALL_OUT(), REMOVE_CALL_OUT(), ALLOCATE(),
SIZEOF();

void
REALP(), INTP(), STRINGP(), OBJECTP(), POINTERP(), USERS(), 
PREVIOUS_OBJECT(), EXTRACT(), FILE_NAME(), QUERY_HOST_NAME(),
EXPLODE(), xMKDIR(), RMDIR(), FIND_PLAYER(),
INTERACTIVE(), FIND_CALL_OUT(), CP(), xRENAME(), DISASS_FUNC(),
GRAB_FILE(), INT2REAL(), REAL2INT();

void
WRITE_FILE(), CALLER(), REMOTE_COMMAND(), QUERY_SNOOP(), IMPLODE(),
FILE_SIZE(), EXTERNAL_PROGRAM(), INDEX(), CONTENTS(), NOTHING(),
GREP(), FUNCTION_EXISTS(), SWITCH_INTERACTIVE(), SUID_FILE(), REGEXP();

/*
 * Inheritance: An object X can inherit from another object Y. This is done
 * with the statement 'inherit "file";' The inherit statement will clone a
 * copy of that file, call reset in it, and set a pointer to Y from X. Y has
 * to be removed from the linked list of all objects. All variables declared
 * by Y will be copied to X, so that X has access to them.
 *
 * If Y isn't loaded when it is needed, X will be discarded, and Y will be
 * loaded separately. X will then be reloaded again.
 */

/*
 * Types are passed in as bit flags for checking here - much nicer
 * stack_error messages.
 */

char tebuff[200];

#ifndef type_check
int type_check(&arg, allowed, who, which)
     Val *arg;
     char *who;
     int  allowed, which;
{

    if (arg && (arg->type & allowed))
        return 1;
    else
#else
int type_error(Val * arg, int allowed, char *who, int which)
{
#endif
    {
        int  t;
        int  ndone = 0;
        char *sep = " ";

/*    int tmpa = allowed; */
        if (!who)
            who = "<unknown>";
        sprintf(tebuff, "Type error in %s (arg %d) - got %s, wanted",
                who, which, (arg ? typename(arg->type) : "<no param>"));
        for (t = 1; t < T_ANY; t <<= 1)
        {
            if (allowed & t)
            {
                allowed = allowed & (~t);
                if (ndone > 0 && (!allowed))
                    sep = " or ";
                sprintf(tebuff + strlen(tebuff), "%s%s", sep, typename(t));
                sep = ", ";
                ndone++;
            }
        }
        strcat(tebuff, ".\n");
/*    if (((tmpa & (~T_STRING)) == T_OBJECT) && arg && (arg->type == T_NUMBER)
 * && (arg->u.number == 0)) {
 * strcat(tebuff, "Integer was zero - destructed object?\n");
 * } */
        efun_error(tebuff);
        return 0;
    }
}

/*
 * Our table of opcode handling routines (for efuns).
 */
/* *INDENT-OFF* */

static struct {
    int tkn;
    void (*fun)();
    }
    ocl[] =
{
    { F_LOAD_SHARED_OBJECT, LOAD_SHARED_OBJECT },
    { F_UNLOAD_SHARED_OBJECT, UNLOAD_SHARED_OBJECT },
    { F_EXT_C_CALL, EXT_C_CALL },
    { F_EXTRACT , EXTRACT  },
    { F_OUT_TO_TERM, OUT_TO_TERM },
    { F_OUT_BINARY, OUT_BINARY },
    { F_THIS_OBJECT , THIS_OBJECT  },
    { F_CLONE_OBJECT , CLONE_OBJECT  },
    { F_IS_CLONED , IS_CLONED  },
    { F_FILE_NAME , FILE_NAME  },
    { F_DESTRUCT , DESTRUCT  },
    { F_SHUTDOWN , SSHUTDOWN  },

    { F_SETUID, SETUID },
    { F_SUID_FILE, SUID_FILE },
    { F_QUERY_FILE, QUERY_FILE },
    { F_QUERY_LEVEL, QUERY_LEVEL },
    { F_QUERY_SU_NAME, QUERY_SU_NAME },

    { F_RENAME_OBJECT, RENAME_OBJECT },

    { F_ATOI,    ATOI },
    { F_ATOR,    ATOR },
    { F_HASH_VALUE , HASH_VALUE  },
    { F_SAVE_OBJECT , SAVE_OBJECT  },
    { F_RESTORE_OBJECT , RESTORE_OBJECT  },

    { F_ENVIRONMENT , ENVIRONMENT  },
    { F_PRESENT , PRESENT  },
    { F_MOVE_OBJECT , MOVE_OBJECT  },
    { F_ENABLE_COMMANDS , ENABLE_COMMANDS  },
    { F_LIVING , LIVING  },
    { F_RANDOM , RRANDOM  },
    { F_TOGGLE_ECHO, TOGGLE_ECHO },
    { F_SENDTO, SENDTO },
#if 0
    { F_LS , LS  },
    { F_RM , RM  },
    { F_CP , CP  },
    { F_MKDIR , xMKDIR  },
    { F_RMDIR , RMDIR  },
    { F_WRITE_FILE , WRITE_FILE  },
    { F_GRAB_FILE, GRAB_FILE },
#endif
    { F_RM , RM  },
    { F_LS , LS  },
    { F_MKDIR , xMKDIR  },
    { F_RMDIR , RMDIR  },
    { F_CP , CP  },
    { F_RENAME , xRENAME  },
    { F_GRAB_FILE, GRAB_FILE },
    { F_WRITE_FILE , WRITE_FILE  },
    { F_FILE_SIZE , FILE_SIZE  },
    { F_STRLEN , STRLEN  },
    { F_EXPLODE , EXPLODE  },
    { F_IMPLODE , IMPLODE  },
    { F_LOWER_CASE , LOWER_CASE  },
    { F_CAPITALIZE , CAPITALIZE  },
    { F_SET_IP_NUMBER , SET_IP_NUMBER  },
    { F_QUERY_IP_NUMBER , QUERY_IP_NUMBER  },
    { F_QUERY_HOST_NAME , QUERY_HOST_NAME  },
    { F_SNOOP , SSNOOP  },
    { F_FIND_OBJECT , FIND_OBJECT  },
    { F_TIME , TIME  },

    { F_CALL_OUT , CALL_OUT  },
    { F_NCALL_OUT , NCALL_OUT  },
    { F_FIND_CALL_OUT , FIND_CALL_OUT  },
    { F_REMOVE_CALL_OUT , REMOVE_CALL_OUT  },

    { F_ALLOCATE , ALLOCATE  },
    { F_INT2REAL , INT2REAL  },
    { F_REAL2INT , REAL2INT  },

    { F_SIZEOF , SIZEOF  },
    { F_INTP , INTP  },
    { F_REALP , REALP  },
    { F_STRINGP , STRINGP  },
    { F_OBJECTP , OBJECTP  },
    { F_POINTERP , POINTERP  },

    { F_USERS , USERS  },
    { F_INDEX , INDEX  },
    { F_CONTENTS , CONTENTS  },
    { F_CREATOR , CREATOR  },

    { F_CALLER , CALLER  },
    { F_PREVIOUS_OBJECT , PREVIOUS_OBJECT  },
    { F_EXTERNAL_PROGRAM , EXTERNAL_PROGRAM  },

    { F_QUERY_SNOOP , QUERY_SNOOP  },
    { F_SWITCH_INTERACTIVE , SWITCH_INTERACTIVE  }
};

/* *INDENT-ON* */


#define    NUM_OPS    (sizeof(ocl) / sizeof(ocl[1]))

/*
 * The +20 is for slop taken up by non-function tokens (i.e.
 * keywords and such) - there's currently 17 of them.
 * The game driver will fail on startup if you need to add more slop -
 * this is an anachronism.
 */

/*
 * This is the real table of function pointers.
 */
struct jumptable
{
    void (*func) ();
    int  numcalls;
    int  flag;
};

struct jumptable extfuncs[F_LASTOP + 1];

void call_efun(int x)
{
#if 0
    printf("call_efun: %d\n", x);
#endif
    (extfuncs[x].func) ();
}

/*
 * Install the opcode table in the oc function list
 */

void install_oc()
{
    int  x;

    for (x = 0; x <= F_LASTOP; x++)
    {
        extfuncs[x].func = NOTHING;
        extfuncs[x].numcalls = 0;
    }

    for (x = 0; x < NUM_OPS; x++)
    {
        if (ocl[x].tkn > (F_LASTOP))
            fatal("Opcode installation (%d/%d)- token value too high\n", x, ocl[x].tkn);
        extfuncs[ocl[x].tkn].func = ocl[x].fun;
    }
    initfixedints();
}

/* Ok, this is inefficient (O(N^2)), but pretty damn rare.
 * If I wanted speed, I'd use qsort.
 */

int dump_oc_profile(int top)
{
    int  x, y;
    int  div;
    int  highval;
    int  tot = 0;
    char out[100];

    for (x = 0; x <= F_LASTOP; x++)
    {
        tot += extfuncs[x].numcalls;
        extfuncs[x].flag = 0;  /* have we printed it :) */
    }
    if (!top)
        top = tot = 1;

    add_message("Opcode stats:\n");
    div = tot / top;
    highval = 0;
    for (x = 0, y = 0; x <= F_LASTOP; x++)
    {
        int  v = (extfuncs[x].numcalls / div);

        if (v)
        {
            if (++y > 5)
            {
                y = 0;
                add_message("\n");
            }
            sprintf(out, " %d: %-7d", x, v);
            add_message(out);
        }
    }
    return 0;
} 

void NOTHING()
{
    fatal("Unknown opcode executed\n");
}

void ATOI()
{
    Val  arg;
    int  i;

    Pop(&arg);
    type_check(&arg, T_STRING, "atoi", 1);
    i = atoi(arg.u.string->str);
    Push(make_number(i));
}

void ATOR()
{
    Val  arg;
    float i;

    Pop(&arg);
    type_check(&arg, T_STRING, "ator", 1);
    i = atof(arg.u.string->str);
    Push(make_real(i));
}

void SUID_FILE()
{
    Val  arg, arg1;

    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_STRING, "setuid_file", 1);
    type_check(&arg1, T_NUMBER, "setuid_me", 2);
    if (!o_write_ok(Scurrent(), arg.u.string))
    {
        efun_error("suid_file(%s) - no permission\n", arg.u.string->str);
        return;
    }
    Push(make_number(set_file_su(arg.u.string, arg1.u.number)));
}

void SETUID()                   /* setuid(object, level, name) */
{
    Val  arg, arg1, arg2;

    Pop(&arg2);
    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_OBJECT, "setuid_me", 1);
    type_check(&arg1, T_NUMBER, "setuid_me", 2);
#if 0
    printf("set_uid_me(%s,%d) (from %s).\n", arg.u.ob->name->str, arg1.u.number,
        Scurrent()->name->str);
#endif
    if (arg2.type == T_STRING)
    {
        Push(make_number(setuid_me(Scurrent(), arg.u.ob,
                                   arg1.u.number, arg2.u.string)));
    }
    else if ((arg2.type == T_NUMBER) && !arg2.u.number)
    {
        Push(make_number(setuid_me(Scurrent(), arg.u.ob,
                                   arg1.u.number, Scurrent()->su_name)));
    }
    else
    {
        Push(make_number(setuid_me(Scurrent(), arg.u.ob,
                                   arg1.u.number, 0)));
    }
}

void QUERY_LEVEL()              /* query an object's level */
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_OBJECT, "query_su_level", 1);
    Push(make_number(arg.u.ob->level));
}

void QUERY_SU_NAME()            /* query an object's suname */
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_OBJECT, "query_su_name", 1);
    if (arg.u.ob->su_name)
        Push(share_string(arg.u.ob->su_name));
    else
        Push(Const(0));
}

void QUERY_FILE()               /* get access perms on a file */
{
    Val  arg, arg1, ob, *ret;
    Obj *iob = Scurrent();

    Pop(&ob);
    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_STRING, "query_file", 1);
    type_check(&arg1, T_STRING, "query_file", 2);
    if (ob.type == T_OBJECT)
    {
        iob = ob.u.ob;
    }
    if (!strcmp(arg1.u.string->str, "r"))
        ret = make_number(o_read_ok(iob, arg.u.string));
    else if (!strcmp(arg1.u.string->str, "w"))
        ret = make_number(o_write_ok(iob, arg.u.string));
    else if (!strcmp(arg1.u.string->str, "a"))
        ret = make_number(o_append_ok(iob, arg.u.string));
    else
    {
        efun_error("Bad mode string (\"%s\") in query_file()\n",
                   arg1.u.string->str);
        return;
    }
    Push(ret);
}

void IS_CLONED()
{
    Val  arg1;

    Pop(&arg1);
    type_check(&arg1, T_OBJECT, "is_cloned", 1);
    Push(make_number(arg1.u.ob->cloned != 0));
}

void CLONE_OBJECT()
{
    Val  arg1, arg2, *ret = NULL;
    char *tmp = NULL;
    Shared * stmp = NULL;
    //Obj *oldCO = Scurrent();

    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg1, T_STRING, "clone_object", 1);
    if (arg2.type == T_STRING)
    {
        type_check(&arg2, T_STRING, "clone_object", 2);
        /* make new name from current_object */
        tmp = (char *) malloc((arg2.u.string->length) +
                              (Scurrent()->name->length) + 2);
        if (!tmp) 
        {
            fatal("CLONE_OBJECT: unable to allocate object.\n");
            return;
        }
        strcpy(tmp, Scurrent()->name->str);
        strcat(tmp, "/");
        strcat(tmp, arg2.u.string->str);
        stmp = string_copy(tmp);
        free(tmp);
        if (find_object2(stmp))
        {
            free_string(stmp);
            Push(Const(0));
            return;
        }
        /* check it doesn't exists already otherwise return */
    }
    if (arg1.type == T_STRING) ret = clone_object(arg1.u.string, stmp);
    // else ret = ob_clone_object(arg1.u.ob, stmp);

    if (stmp) free_string(stmp);

    if (!ret)
    {
        efun_error("Failed to clone object (%s).\n", arg1.u.string->str);
        return;
    }

    // Sset_current(oldCO, "clone_object");
    Push(ret);
}

void SAVE_OBJECT()
{
    Val  * arg, arg1, arg2, *cob = 0;

    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg1, T_STRING, "save_object", 1);
    if (arg2.type == T_OBJECT)
    {
        if (Scurrent()) cob = make_object(Scurrent());
        arg = apply_single(C("query_no_external_save"), arg2.u.ob, cob);
        if (arg)
        {
            if (arg->type == T_NUMBER && arg->u.number)
            {
                Push(Const(0));
                return;
            }
            free_value(arg);
        }
    }
    else
    {
        arg2.type = T_OBJECT;
        arg2.u.ob = Scurrent();
    }
    if (!o_save_ok(Scurrent(), arg1.u.string))
    {
        efun_error(
                  "save_object(\"%s\") - no write permission on savefile\n",
                      arg1.u.string->str);
        return;
    }
    else
    {
        Push(make_number(save_object(arg2.u.ob,
                                     arg1.u.string->str, (FILE *) 0)));
    }
}

//#define DEBUG_RENO 

void RENAME_OBJECT()
{
    Val  arg, arg2;
    Obj *o1;
    Shared * s;

#ifdef DEBUG_RENO
    printf("entered RENAME_OBJECT\n");
#endif
    Pop(&arg2);
    Pop(&arg);
    type_check(&arg, T_OBJECT | T_STRING, "rename_object", 1);
    type_check(&arg2, T_STRING, "rename_object", 1);
    if (arg.type == T_STRING)
    {
        o1 = find_object2(arg.u.string);
    }
    else
    {
        o1 = arg.u.ob;
    }

    if (!o1)
    {
        Push(Const(0));
        return;
    }

    /* normal people have to rename things to a suffix of their own name
     * (preferably with a preceding slash) */
    if ((Scurrent()->level < GOD) && (string_ncmp(arg2.u.string, Scurrent()->name, Scurrent()->name->length)))
    {
        efun_error("No permission to change to %s", arg2.u.string->str);
        return;
    }

    if (find_object2(arg2.u.string))
    {
        efun_error("rename_object: already an object named %s",
                   arg2.u.string->str);
        return;
    }
    if (Scurrent()->level < o1->level)
    {
        efun_error("Not enough permission to change name of %s", o1->name->str);
        return;
    }

    s = o1->name;
    remove_object_hash(o1);
    o1->name = shared_string_copy(arg2.u.string);
    free_string(s);  

#ifdef DEBUG_RENO 
    printf("RENAME_OBJECT(from %s to %s)\n", o1->name->str, arg2.u.string->str);
#endif

    enter_object_hash(o1);
    Push(make_object(o1));
#ifdef DEBUG_RENO
    printf("finished RENAME_OBJECT\n");
#endif
}

void FIND_OBJECT()
{
    Val  arg;
    Obj *o1;

    Pop(&arg);
    type_check(&arg, T_STRING, "find_object", 1);
    o1 = find_object2(arg.u.string);
    if (!o1)
        Push(Const(0));
    else
        Push(make_object(o1));
}

int write_file(Shared *file, Shared * str)
{
    FILE           *f;

    f = fopen(file->str, "a");
    if (f == 0) return 0;
    fwrite(str->str, str->length, 1, f);
    fclose(f);
    force_no_su(file);
    return 1;
}

void WRITE_FILE()
{
    Val  arg, arg1;

    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_STRING, "write_file", 1);
    type_check(&arg1, T_STRING, "write_file", 2);

    if (!o_write_ok(Scurrent(), arg.u.string))
    {
            efun_error("Can't write to %s\n", arg.u.string->str);
            return;
    }
    if (write_file(arg.u.string, arg1.u.string))
            Push(Const(1));
    else
            Push(Const(0));
}


// Only here because master uses it ..
int file_size(Shared *file)
{
    struct stat     st;

    if (stat(file->str, &st) == -1) return -1;
    if (S_IFDIR & st.st_mode) return -2;
    return st.st_size;
}

void FILE_SIZE()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_STRING, "file_size", 1);
    if (!o_read_ok(Scurrent(), arg.u.string))
        Push(Const(-1));
    else
        Push(make_number(file_size(arg.u.string)));
}

void RESTORE_OBJECT()
{
    Val  * arg, arg1, arg2, *cob = 0;

    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg1, T_STRING, "restore_object", 1);
    if (arg2.type == T_OBJECT)
    {
        type_check(&arg2, T_OBJECT, "restore_object", 2);
        if (Scurrent()) cob = make_object(Scurrent());
        arg = apply_single(C("query_no_external_restore"), arg2.u.ob, cob);
        if (arg)
        {
            if (arg->type == T_NUMBER && arg->u.number)
            {
                Push(Const(0));
                return;
            }
            free_value(arg);
        }
    }
    else
    {
        arg2.type = T_OBJECT;
        arg2.u.ob = Scurrent();
    }
    if (!o_read_ok(Scurrent(), arg1.u.string))
    {
        efun_error("Restore_object(\"%s\") - no read permission on savefile\n",
                   arg1.u.string->str);
        return;
    }
    Push(make_number(
                     restore_object(arg2.u.ob, arg1.u.string->str, (FILE *) 0)));
}

void CALLER()
{
    caller();
}

void CONTENTS()
{
    Val  arg, *ret;

    Pop(&arg);
    type_check(&arg, T_STRING | T_OBJECT, "contents", 1);
    ret = contents(&arg);
    if (!ret)
        return;  /* error */
    Push(contents(&arg));
}

void LIVING()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_OBJECT, "living", 1);
    if (arg.u.ob->destructed) Push(Const(0));
    Push(make_number(arg.u.ob->enable_commands));
}

void CREATOR()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_OBJECT, "creator", 1);
    if (arg.u.ob->su_name == 0)
        Push(Const(0));
    else
        Push(share_string(arg.u.ob->su_name));
}

void SSHUTDOWN()
{
    if (Scurrent()->level < SHUTDOWN)
    {
        efun_error("No permission to shutdown.\n");
        return;
    }
    startshutdowngame();
    Push(Const(0));
}

void EXPLODE()
{
    Val  arg, arg1;

    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_STRING, "explode", 1);
    type_check(&arg1, T_STRING, "explode", 2);
    if (arg1.u.string->length == 0)
    {
        efun_error("Attempted to explode on a zero length splitting string\n");
        return;
    }
    Push(explode_string(arg.u.string, arg1.u.string));
}

void IMPLODE()
{
    Val  arg, arg1;

    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_POINTER, "implode", 1);
    type_check(&arg1, T_STRING, "implode", 2);
    Push(implode_string(arg.u.vec, arg1.u.string));
}

#ifndef SCRIPT
void QUERY_SNOOP()
{
    Val  arg,  * arg1, *ret;

    Pop(&arg);
    type_check(&arg, T_OBJECT, "query_snoop", 1);
    if (arg.u.ob->interactive == 0)
    {
        /* can't snoop non-interactive */
        Push(Const(0));
        return;
    }
    ret = query_snoop(arg.u.ob);
    if (!ret || ret->type != T_OBJECT)
    {
        Push(Const(0));
        return;
    }
    arg1 = apply_single(C("query_wiz"), ret->u.ob, 0);
    if (arg1) 
    {
        if (arg1->type != T_OBJECT)
        {
            free_value(arg1);
            Push(Const(0));
            return;
        }
    }
    if (Scurrent()->level < arg1->u.ob->level)
        Push(Const(0));
    else
        Push(ret);

    free_value(arg1);
}

void QUERY_IP_NUMBER()
{
    Val  arg;
    char *tmp;

    Pop(&arg);
    tmp = query_ip_number(arg.u.ob);
    if (tmp == 0)
        Push(Const(0));
    else
        Push(make_string(tmp));
}

void QUERY_HOST_NAME()
{
    extern char *query_host_name();
    char *tmp;

    tmp = query_host_name();  /* returns const pointer */
    Push(make_string(tmp));
}
#endif

void ENVIRONMENT()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_NUMBER)
    {
        arg.type = T_OBJECT;
        arg.u.ob = Scurrent();
    }
    else
    {
        type_check(&arg, T_STRING | T_OBJECT, "environment", 1);
    }
    Push(environment(&arg));
}

void THIS_OBJECT()
{
#if 1
    if (Scurrent() == NULL || Scurrent()->destructed)
    {
        Push(Const(0));
    }
    else
    {
#endif
        Push(make_object(Scurrent()));
#if 1
    }
#endif
}

void PREVIOUS_OBJECT()
{
    previous_object();
}

void TIME()
{
    Push(make_number((int) time(0l)));
}

float getreal(Val * v)
{
    type_checkr(v, T_REAL | T_NUMBER, "get_real (internal)", 1);
    if (v->type == T_NUMBER)
        return (float) v->u.number;
    return (float) v->u.real;
}

void REAL2INT()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_REAL | T_NUMBER, "real2int", 1);
    if (arg.type == T_NUMBER)
        Push(make_number(arg.u.number));
    else
        Push(make_number((int) (arg.u.real)));
}


void INT2REAL()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_NUMBER, "int2real", 1);
    Push(make_real(getreal(&arg)));
}

/*
 * The checking for non null pointers here hangs on tenterhooks :)
 */
void HASH_VALUE()
{
    Val  a;

    Pop(&a);
    Push(make_number(abs(subhash(&a))));
}

#define addhash(h, i) (((h) * P1 + (i) * P2 + P3) % HUGE_PRIME)
/* relies on no recursive arrays */
int  subhash(Val * v)
{
    int  h = 0;
    int  x;

    if (!v)
        return 0;
    h = v->type;
    switch (v->type)
    {
        case T_NUMBER:
        case T_REAL:
        case T_OBJECT:
            return addhash(h, v->u.number);
        case T_STRING:
            return addhash(h, LPC_StrHash(v->u.string, HUGE_PRIME));
        case T_POINTER:
            h = addhash(h, v->u.vec->size);
            for (x = 0; x < v->u.vec->size; x++)  /* sigh - really values */
                h = addhash(h, subhash(&v->u.vec->item[x]));
            return h;
    }
    fatal("Subhash: unknown type (%d) in hash");
    return 0;
}

#if 0
void constinvert(Val * v)
{
    type_check(v, T_NUMBER, "constinvert (internal)", 1);
    if (v->type == T_NUMBER && v->u.number == 0)
        Push(Const(1));
    else
        return;
}
#endif

void INTP()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_NUMBER)
        Push(Const(1));
    else
        Push(Const(0));
}

void REALP()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_REAL)
        Push(Const(1));
    else
        Push(Const(0));
}

void STRINGP()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_STRING)
        Push(Const(1));
    else
        Push(Const(0));
}

void OBJECTP()
{
    Val  arg;

    Pop(&arg);
    if (arg.type == T_OBJECT)
        Push(Const(1));
    else
        Push(Const(0));
}

void POINTERP()
{
    Val  arg;

#if 0
    printf("In pointerp()\n");
#endif
    Pop(&arg);
    if (arg.type == T_POINTER)
        Push(Const(1));
    else
        Push(Const(0));
}

void EXTRACT()
{
    Val  arg, arg1, arg2, *ret;
    Vec *pv;
    int  len, start, finish;
    char *newS;

    Pop(&arg2);
    Pop(&arg1);
    Pop(&arg);
    type_check(&arg2, T_NUMBER, "extract", 3);
    type_check(&arg1, T_NUMBER, "extract", 2);
    type_check(&arg, T_STRING | T_POINTER, "extract", 1);

#if 0
    printf("In EXTRACT()\n");
#endif

    if (arg1.u.number < 0)
    {
        efun_error("Second argument to extract should be >= 0\n");
        return;
    }

    // Find the length 
    if (arg.type == T_STRING)
    {
        len = arg.u.string->length;
    }
    else
    {
        len = arg.u.vec->size;
    }

    // Set the start
    start = arg1.u.number;

    /* below is kind of ugly - a backward comp. hack - FUCK! - D */
    if ((arg2.u.number == 0) && (arg2.u.number < start))
    {
        finish = len - 1;
    }
    else
    {
        finish = arg2.u.number;
    }


    if (finish >= len)
        finish = len - 1;

    // Special (silly) cases
    if ((len == 0) || (start >= len) || (finish < start)) 
    {
        if (arg.type == T_STRING)
            Push(make_string(""));
        else
            Push(allocate_array(0));

        return;
    }

    if (arg.type == T_STRING)
    {
        newS = malloc(finish - start + 2);
        memcpy(newS, arg.u.string->str + start, finish - start + 1);
        newS[finish - start + 1] = '\0';
        ret = make_nstring(newS, finish-start+1);
#if 0
    printf("In EXTRACT() returning string: %s\n", newS);
#endif
        Push(ret);
        //assert(ret->u.string->length >= 0);
        //assert(ret->u.string->length < 100000);
        free(newS);
        return;
    }
    else
    {
        pv = create_vector(finish - start + 1, "EXTRACT()");
        copy_in_vector(pv, arg.u.vec, 0, start, finish - start + 1);
        pv->ref = 0;  /* because make_vector incs it by 1 */
        Push(make_vector(pv));
        return;
    }
}

void FILE_NAME()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_OBJECT, "file_name", 1);
    Push(share_string(arg.u.ob->name));
}

#ifndef SCRIPT
/* Obsolete */
void USERS()
{
    Push(users());
}

/* Schedule Events in the future */

void CALL_OUT()
{
    int  i, r, have_args = 0;
    Val  arg, arg1, arg2;

#if 1
    Val **val_list;

    have_args = Popc();  /* pop the control stack */
    have_args -= 2;  /* obj, func ( args ) */
    if (have_args < 0)
    {
        efun_error("Not enough args to call_out().\n");
        return;
    }
    if (have_args)
    {
        val_list = (Val **) malloc((have_args + 1) * sizeof(Val *));
        val_list[have_args] = 0;

        while (have_args--)
        {
            Pop(&arg2);
            val_list[have_args] = (Val *) malloc(sizeof(Val));
            assign_value(val_list[have_args], &arg2);
        }
    }
    else
        val_list = 0;

#else
    Pop(&arg2);
#endif
    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_STRING, "call_out", 1);
    type_check(&arg1, T_NUMBER | T_REAL, "call_out", 2);
    if (arg1.type == T_NUMBER)
    {
        i = arg1.u.number;
        r = 0;
    }
    else
    {
        i = (int) arg1.u.real;
        r = (arg1.u.real - i) * 1000000;
        if (r < 0)
        {
            r += 1000000;
            i += 1;
        }
    }
    if (i < 0 || (i < 1 && r < 100000))
    {
        i = 0;
        r = 100000;  /* minimum 0.1s delay */
    }

    if (!new_call_out(Scurrent(), arg.u.string, i, r, val_list))
    {
        efun_error("Too many call_outs already!\n");
        return;
    }

    Push(Const(0));
}

/* FIX: */
void NCALL_OUT()
{
    Val  argo, arg, arg1, arg2;

    Obj *ob = 0;
    int  i, r;

    Pop(&argo);
    type_check(&argo, T_STRING | T_OBJECT, "ncall_out", 1);
    if (argo.type == T_OBJECT)
        ob = 0;
    else
        ob = find_object2(argo.u.string);
    if (ob == 0)
    {
#if 1
        efun_error("Failed to find obj(%s) in ncall_out.\n",
                   argo.u.string->str);
#endif
        return;
    }

    Pop(&arg1);
    type_check(&arg1, T_NUMBER | T_REAL, "call_out", 3);

    Pop(&arg);
    type_check(&arg, T_STRING, "ncall_out", 2);

    Pop(&arg2);
    if (arg1.type == T_NUMBER)
    {
        i = arg1.u.number;
        r = 0;
    }
    else
    {
        i = (int) arg1.u.real;
        r = (arg1.u.real - i) * 1000000;
        if (r < 0)
        {
            r += 1000000;
            i += 1;
        }
    }
    if (i < 0 || (i < 1 && r < 100000))
    {
        i = 0;
        r = 100000;  /* minimum 0.1s delay */
    }
#if 0
    new_call_out(ob, arg.u.string, i, r, arg2);
#endif
    Push(Const(0));
}

void SENDTO()
{
    Val  arg, tmp;
    int  a, b, c, d, port;
    char buff[DG_BUFF];
    int  bl;

    if (Scurrent()->level < SEND_DATAGRAM)
    {
        efun_error("Bad call to send_to() by a untrusted object. Calling object must be at least level %d.\n", SEND_DATAGRAM);
        return;
    }
    Pop(&arg);
    type_check(&arg, T_NUMBER | T_REAL | T_POINTER | T_STRING, "send_to", 6);
    tmp.type = T_NUMBER;
    tmp.u.number = 0;
    assign_value(&tmp, &arg);
    bl = buff_write_val(buff, DG_BUFF, &tmp);
    assign_value(&tmp, Const(0));  /* no space leaks */

    Pop(&arg);
    type_check(&arg, T_NUMBER, "send_to", 5);
    port = arg.u.number;
    Pop(&arg);
    type_check(&arg, T_NUMBER, "send_to", 4);
    d = arg.u.number;
    Pop(&arg);
    type_check(&arg, T_NUMBER, "send_to", 3);
    c = arg.u.number;
    Pop(&arg);
    type_check(&arg, T_NUMBER, "send_to", 2);
    b = arg.u.number;
    Pop(&arg);
    type_check(&arg, T_NUMBER, "send_to", 1);
    a = arg.u.number;
    if (bl < 0)
        Push(make_number(bl));
    bl = do_dg_write(a, b, c, d, port, buff, bl);
    Push(make_number(bl));
}

/* Event support */
void REMOVE_CALL_OUT()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_STRING, "remove_call_out", 1);
    Push(make_number(
                        remove_call_out(Scurrent(), arg.u.string)));
}

void FIND_CALL_OUT()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_STRING, "find_call_out", 1);
    Push(make_number(
                        find_call_out(Scurrent(), arg.u.string)));
}
#endif

void OUT_TO_TERM()
{
    Val  arg;

    if (Scurrent() == 0 || Scurrent()->interactive == 0)
    {
        Pop(&arg);
        Push(Const(0));
#ifdef DEBUG_EFUNS
    if (Scurrent())
        printf("OUT_TO_TERM A (%s)\n", Scurrent()->name->str);
    else
        printf("OUT_TO_TERM A\n");
#endif
        return;
    }
    Pop(&arg);
    type_check(&arg, T_STRING, "out_to_term", 1);
#ifdef DEBUG_EFUNS
    printf("out_to_term (%s): #%s#\n", Scurrent()->name->str, arg.u.string->str);
#endif
    /* FIX: */
    add_output(Scurrent()->interactive, 1, arg.u.string);
    Push(Const(0));
}

void OUT_BINARY()
{
    Val  arg;

    if (Scurrent() == 0 || Scurrent()->interactive == 0)
    {
        Pop(&arg);
        Push(Const(0));
        return;
    }
    Pop(&arg);
    type_check(&arg, T_STRING, "out_binary", 1);
#if 0
    printf("out_binary(%s): #length %d#\n", Scurrent()->name, arg.u.string->length);
#endif

    binary_output(Scurrent()->interactive, arg.u.string->str, arg.u.string->length);
    Push(Const(0));
}

void MOVE_OBJECT()
{
    Val  arg, arg2;
    Obj *o1, *o2;

    Pop(&arg2);
    Pop(&arg);
    type_check(&arg, T_STRING | T_OBJECT, "move_object", 1);
    type_check(&arg2, T_STRING | T_OBJECT, "move_object", 2);
    if (arg.type == T_OBJECT)
    {
        o1 = arg.u.ob;
    }
    else
    {
        o1 = find_object(arg.u.string);
        if (o1 == 0)
        {  
            /* an error has occurred! */
            efun_error("Failed to load %s (%s).\n", arg.u.string->str,
                       load_error);
            return;
        }
    }
    if (arg2.type == T_OBJECT)
    {
        o2 = arg2.u.ob;
    }
    else
    {
        o2 = find_object(arg2.u.string);
        if (o2 == 0)
        {
            efun_error("Failed to load %s (%s).\n", arg2.u.string->str,
                       load_error);
            return;
        }
    }
#if 1
    if (((Obj *) o1)->destructed)
    {
        efun_error("move_object() on destructed object.\n");
        return;
    }
#endif
    if (((Obj *) o2)->destructed)
    {
        Push(Const(0));
/*             efun_error("move_object() to destructed object.\n"); */
        return;
    }
#if 0
    printf("efun move_object(%s, %s).\n", o1->name->str, o2->name->str);
#endif
    if (move_object(o1, o2))
        return;
    else
        Push(Const(0));
}

#ifndef SCRIPT
void SSNOOP()
{
    Val  arg1;

    Pop(&arg1);
    type_check(&arg1, (T_NUMBER | T_OBJECT), "snoop", 1);

    if (!(Scurrent()->interactive))
    {
        efun_error("snoop() by non interactive object.\n");
        return;
    }

    if (arg1.type == T_OBJECT)
        set_snoop(Scurrent(), arg1.u.ob);
    else
        set_snoop(Scurrent(), 0);
    Push(Const(0));
}
#endif

void ALLOCATE()
{
    Val  ret;

#if 0
    printf("efun allocate().\n");
#endif
    Pop(&ret);
    type_check(&ret, T_NUMBER, "allocate", 1);
    Push(allocate_array(ret.u.number));
}

#define MyStrcpy(to, what)      strncpy(to, what, sizeof(to) - 1) ; to[sizeof(to) - 1] = 0
void EXTERNAL_PROGRAM()
{
    Val  * arg, arg1, arg2, arg3;
    Val  a1, a2, a3;
    char ExtArg[MAX_EXT_ARGS][80];
    int  usestdio = 1, envc, ArgCount;
    char *infile = 0, *outfile = 0, *errfile = 0;
    char *ExtArgv[MAX_EXT_ARGS], ExtEnv[10][160];
    char *ExtEnvp[10], finito[160], ProgName[160], SocketName[160];

    if (command_giver == 0 || command_giver->interactive == 0)
    {
        Push(Const(0));
        return;
    }
    strcpy(SocketName, EXTPROG_SOCKDIR);
    strcat(SocketName, "/");
    strcat(SocketName, command_giver->su_name->str);
    envc = 0;
    ExtEnvp[envc] = ExtEnv[envc];
    strcpy(ExtEnv[envc], "SOCKET=");
    strcat(ExtEnv[envc], SocketName);
    arg = apply_single(C("query_term_type"), command_giver, 0);
    if (arg)
    {
        if (arg->type == T_STRING)
        {
            /* make an entry for the TERM */
            envc++;
            ExtEnvp[envc] = ExtEnv[envc];
            strcpy(ExtEnv[envc], "TERM=");
            strcat(ExtEnv[envc], arg->u.string->str);
        }
        free_value(arg);
    }
    /* TERMCAP = /pippin0/pub/zik/.termcap */
    envc++;
    ExtEnvp[envc] = ExtEnv[envc];
    strcpy(ExtEnv[envc], "TERMCAP=");
    strcat(ExtEnv[envc], TERMCAP_PATH);

    envc++;
    ExtEnvp[envc] = ExtEnv[envc];
    strcpy(ExtEnv[envc], "MUDLIB=");  /* MUDLIB=... */
    strcat(ExtEnv[envc], MUD_LIB);

    if (Scurrent()->level >= GOD)
    {  /* security hack */
        arg = apply_single(C("query_pwd"), Scurrent(), 0);
        if (arg)
        {
            if (arg->type == T_STRING)
            {
                /* make an entry for the MUDPWD */
                envc++;
                ExtEnvp[envc] = ExtEnv[envc];
                strcpy(ExtEnv[envc], "MUDPWD=");
                strcat(ExtEnv[envc], arg->u.string->str);
            }
            free_value(arg);
        }
    }
    {  /* is a wiz so has a * home directory */
        envc++;
        ExtEnvp[envc] = ExtEnv[envc];
        strcpy(ExtEnv[envc], "MUDHOME=");
        strcat(ExtEnv[envc], MUD_LIB);
        strcat(ExtEnv[envc], "/players/");
        strcat(ExtEnv[envc],
               command_giver->interactive->ob->su_name->str);
#if 0
        /* security hack */
        if (Scurrent()->level < GOD)
        {
            envc++;
            ExtEnvp[envc] = ExtEnv[envc];
            strcpy(ExtEnv[envc], ExtEnv[envc - 1]);
        }
#endif
    }
    if (Scurrent()->level >= GOD)
    {  /* security hack */
        arg = apply_single(C("query_homepwd"), Scurrent(), 0);
        if (arg)
        {
            if (arg->type == T_STRING)
            {
                /* make an entry for the MUDPWD */
                envc++;
                ExtEnvp[envc] = ExtEnv[envc];
                strcpy(ExtEnv[envc], "MUDHOMEPWD=");
                strcat(ExtEnv[envc], arg->u.string->str);
            }
            free_value(arg);
        }
    }
    ExtEnvp[++envc] = 0;
    /* get the program name to execute */
    Pop(&a3);
    type_check(&a3, T_NUMBER | T_STRING, "external_program", 6);
    Pop(&a2);
    type_check(&a2, T_NUMBER | T_STRING, "external_program", 5);
    Pop(&a1);
    type_check(&a1, T_NUMBER | T_STRING, "external_program", 4);
    Pop(&arg3);
    type_check(&arg3, T_POINTER, "external_program", 3);
    Pop(&arg2);
    type_check(&arg2, T_STRING, "external_program", 2);
    Pop(&arg1);
    type_check(&arg1, T_STRING, "external_program", 1);
    if (Scurrent()->level < GOD && strchr(arg1.u.string->str, '/') != 0)
    {
        efun_error("First parameter to external_program() should be program name.\n");
        return;
    }
    ExtArgv[0] = ExtArg[0];
    strncpy(ExtArg[0], arg1.u.string->str, sizeof(ExtArgv[0]) - 1);
    strcpy(ProgName, EXTPROG_DIR);
    strcat(ProgName, "/");
    strncat(ProgName, arg1.u.string->str, 158 - strlen(ProgName));
    ProgName[159] = 0;
    /* get the finito call */
    MyStrcpy(finito, arg2.u.string->str);
    /* get all the arguments to the call */

    for (ArgCount = 0; ArgCount < arg3.u.vec->size && ArgCount
         < MAX_EXT_ARGS - 1; ArgCount++)
    {
        struct value *sv;

        sv = &arg3.u.vec->item[ArgCount];
        if (sv == 0 || sv->type != T_STRING)
        {
            efun_error("External program parameter 3 should be a vector of strings.\n");
            return;
        }
        ExtArgv[ArgCount + 1] = ExtArg[ArgCount + 1];
        MyStrcpy(ExtArg[ArgCount + 1], sv->u.string->str);
    }
    ExtArgv[ArgCount + 1] = 0;
/* Grok file I/O params - they are: infile, outfile, errfile (all strings).
 * If infile == -1, use zik's socket hack (by setting usestdio
 * to 0 before calling start_external), otherwise generate
 * FDs as follows:
 *    If param is a string, using the object's permissions, try to open it,
 *    creating an FD.  Otherwise, use the terminal socket, giving a (-1) to
 *    start_external (which indicates that the I/O should be pumped through
 *    the user's socket).  Start_external closes the mud's copies of the
 *    FDs after forking the child.
 */
    if (a1.type == T_NUMBER && a1.u.number == -1)
        usestdio = 0;
    if (a1.type == T_STRING)
    {
        usestdio = 1;
        if (!o_read_ok(Scurrent(), a1.u.string))
        {
            efun_error("external_program stdin (%s): no read permission\n", a1.u.string->str);
            return;
        }
        infile = a1.u.string->str;
    }
    if (a2.type == T_STRING)
    {
        if (!o_write_ok(Scurrent(), a2.u.string))
        {
            efun_error("external_program stdout (%s): no write permission\n", a2.u.string->str);
            return;
        }
        outfile = a2.u.string->str;
    }
    if (a3.type == T_STRING)
    {
        if (!o_write_ok(Scurrent(), a3.u.string))
        {
            efun_error("external_program stderr (%s): no write permission\n", a3.u.string->str);
            return;
        }
        errfile = a3.u.string->str;
    }
#if 1
    printf("Running external program :%s\n", arg1.u.string->str);
#endif

#ifndef __WIN32__
    (void) start_external(arg1.u.string->str, SocketName, ExtArgv,
                       ExtEnvp, finito, usestdio, infile, outfile, errfile);
#endif
    Push(Const(0));
}


#if 0
void xCRYPT()
{
    Val  arg, arg1;
    Val *ret;
    char salt[2];
    char *choice =
    "abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVXYZ0123456789./";

    Pop(&arg1);
    Pop(&arg);
    type_check(&arg, T_STRING, "crypt", 1);
    type_check(&arg1, T_STRING, "crypt", 2);
    if (arg1.type == T_STRING && strlen(arg.u.string->str) >= 2)
    {
        salt[0] = arg1.u.string->str[0];
        salt[1] = arg1.u.string->str[1];
    }
    else
    {
#ifdef HAVE_SRANDOM
        salt[0] = choice[random() % strlen(choice)];
        salt[1] = choice[random() % strlen(choice)];
#else /* use time instead  */
        salt[0] = choice[time(0l) % strlen(choice)];
        salt[1] = choice[time(0l) % strlen(choice)];
#endif /* SRANDOM */
    }
#ifdef HAVE_CRYPT_H
    ret = make_string(crypt(arg.u.string->str, salt));
#else
    ret = share_string(arg.u.string);
#endif
    Push(ret);
}
#endif

void DESTRUCT()
{
    Val * arg, ret;

    Pop(&ret);
    type_check(&ret, T_OBJECT, "destruct", 1);
    arg = apply_single(C("query_destruct"), ret.u.ob, make_object(Scurrent()));

    if (arg)
    {
        if (arg->type == T_NUMBER && arg->u.number != 0
            && Scurrent()->level < ret.u.ob->level)
        {
            Push(Const(0));
            return;
        }
        free_value(arg);
    }

    /* need to clean up after errors - hmm */
    /* returns 0 on error ! */
    if (!destruct_object(ret.u.ob)) return;

    Push(Const(1));
}

void RRANDOM()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_NUMBER, "random", 1);
    if (arg.u.number <= 0)
    {
        Push(Const(0));
        return;
    }
#ifdef HAVE_SRANDOM
    Push(make_number((random() >> 2) % arg.u.number));
#else
    Push(make_number((arg.u.number >> 2 + time(0l)) % arg.u.number));
#endif /* SRANDOM */
}


void STRLEN()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_STRING, "strlen", 1);
    Push(make_number(arg.u.string->length));
}

void SIZEOF()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_STRING | T_POINTER, "sizeof", 1);
    if (arg.type == T_STRING)
        Push(make_number(arg.u.string->length));
    else
        Push(make_number(arg.u.vec->size));
}

/* Speed function */
void LOWER_CASE()
{
    Val  arg, *ret;

    Pop(&arg);
    type_check(&arg, T_STRING, "lowercase", 1);
    {
        int  i;
        char *s = malloc(1 + arg.u.string->length);

        strcpy(s, arg.u.string->str);
        for (i = arg.u.string->length - 1; i >= 0; i--)
            if (isalpha(s[i]))
                s[i] |= 'a' - 'A';
        ret = make_string(s);
        free(s);
    }
    Push(ret);
}

/* relay daemon support */
void SET_IP_NUMBER()
{
    Val  num, obj;
    Obj *o;
    char *s;

    Pop(&obj);
    Pop(&num);
    type_check(&num, T_STRING | T_NUMBER, "set_ip_number", 1);
    if (num.type == T_NUMBER)
        s = 0;
    else
        s = num.u.string->str;
    type_check(&obj, T_OBJECT, "set_ip_number", 2);
    if (Scurrent()->level < 10000)
    {
        Push(Const(0));
        return;
    }
    if (obj.u.ob)
        o = obj.u.ob;
    else
        o = Scurrent();
    if (!o->interactive)
    {
        Push(Const(0));
        return;
    }
    set_ip_number(s, o);
    Push(Const(1));
}


/* Speed function */
void CAPITALIZE()
{
    Val  arg, *ret = 0;

    Pop(&arg);
    type_check(&arg, T_STRING, "capitalize", 1);
    if (arg.u.string->str[0] == '\0')
    {
        Push(share_string(arg.u.string));
        return;
    }
    if (islower(arg.u.string->str[0]))
    {
        char *s = malloc(1 + arg.u.string->length);

        strcpy(s, arg.u.string->str);
        s[0] += 'A' - 'a';
        ret = make_string(s);  /* add it to string table again */
        free(s);
        Push(ret);
        return;
    }
    Push(share_string(arg.u.string));
}

struct list_files_
{
    Shared * fname;
    int  size;                  /* File size */
    int  last_written;
};

typedef struct list_files_ LSFILES;

int
     pstrcmp(LSFILES ** p1, LSFILES ** p2)
{
    return string_cmp((*p1)->fname, (*p2)->fname);
}

/*
 * List files in a directory. The standard 'ls' could be used, but it takes
 * too much time. Prepared for flag decoding.
 *
 * Rewritten so that it is much simplier, with the addition of regexp ()
 * as an efun :L
 * Now returns an array:
 *    ({ ({files}) , ({ corresponding size }), ({ last time the file was written})  })
 * Done this way to allow easy searches on filenames
 */

#define PATH_SIZE 100

#include <limits.h>
Val * list_files(Shared * path)
{
    int  num, offset, max_files = 128, truncated = 0;
    DIR *dirp;
    struct dirent *de;

    Val *ret;
    struct vector *subname, *subsize, *subtime;
    LSFILES **names;
    struct stat st;
    char path2[PATH_SIZE], tmppath[160];

    if (!path) return 0;

    if (path->length >= PATH_SIZE)
    {
        efun_error("Path too long for ls(). Path was (%s)\n", path->str);
        return 0;
    }

    if (path->str[0] == '/')
    {
        efun_error("Invalid use of ls() efun. Illegal leading slash.\n");
        return 0;
    }
    if (path->str[0] == '\0')
        strcpy(path2, ".");
    else
        strcpy(path2, path->str);

    offset = strlen(path2) + 1;

    if (stat(path2, &st) == -1)
    {
        extern int sys_nerr;
        /* extern char *sys_errlist[]; */

        /* Failed. Let them know the errno.
         * The likely problem was that the directory didnt exist */
        efun_error("stat() failed in ls(). Errmessage was (%s)\n",
                   errno < sys_nerr ? sys_errlist[errno] : "unknown error");
        return 0;
    }
    dirp = opendir(path2);
    if (dirp == NULL)
    {
        efun_error("No such directory '%s'\n", path2);
        return 0;
    }
    num = 0;
    /*
     * First step, find the number of file names.
     * and copy the names into a space. Also copy in their sizes.
     * Its a damn pity we dont know how many there is going to be,
     *   would make things alot simplier
     */
    names = (LSFILES **) malloc(max_files * sizeof(LSFILES *));
    strcpy(tmppath, path2);
    strcat(tmppath, "/");
    for (de = readdir(dirp); de; de = readdir(dirp))
    {
        if ((strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0))
            continue;
        strcpy(&tmppath[offset], de->d_name);
        if (stat(tmppath, &st) != -1)
        {
            if (S_IFDIR & st.st_mode)
            {  /* Directory */
                strcat(tmppath, "/");
            }
            else if (S_IEXEC & st.st_mode)
            {  /* mud file has special permissions */
                strcat(tmppath, "*");
            }
        }
        names[num] = (LSFILES *) malloc(sizeof(LSFILES));
        names[num]->fname = string_copy(&tmppath[offset]);
        names[num]->size = (int) st.st_size / 1024 + ((int) st.st_size % 1024 > 0);
        names[num]->last_written = st.st_mtime;

        num++;
        if (num >= max_files)
        {
            if (max_files < MAX_ARRAY_SIZE / 2)
            {
                max_files *= 2;  /* Lets just double the space */
            }
            else
            {
                truncated = 1;
                break;
            }
            names = (LSFILES **) realloc((LSFILES **) names, max_files *
                                         sizeof(LSFILES *));
        }

    }

    /* Sort the names. */
    qsort(names, num, sizeof(LSFILES *), pstrcmp);

    ret = allocate_array(3);

    ret->u.vec->item[0].type = T_POINTER;
    ret->u.vec->item[0].u.vec = create_vector(num, "simulate.c:list_files()");
    ret->u.vec->item[1].type = T_POINTER;
    ret->u.vec->item[1].u.vec = create_vector(num, "simulate.c:list_files()");
    ret->u.vec->item[2].type = T_POINTER;
    ret->u.vec->item[2].u.vec = create_vector(num, "simulate.c:list_files()");
    subname = ret->u.vec->item[0].u.vec;
    subsize = ret->u.vec->item[1].u.vec;
    subtime = ret->u.vec->item[2].u.vec;
    while (num--)
    {
        subname->item[num].type = T_STRING;
        subname->item[num].u.string = names[num]->fname;
        subsize->item[num].type = T_NUMBER;
        subsize->item[num].u.number = names[num]->size;
        subtime->item[num].type = T_NUMBER;
        subtime->item[num].u.number = names[num]->last_written;
        free(names[num]);
    }
    if (truncated)
        add_message("***TRUNCATED***\n");
    free((LSFILES **) names);
    closedir(dirp);
    return ret;
}



void LS()
{
    Val *ret, arg;

    Pop(&arg);
    type_check(&arg, T_STRING, "ls", 1);
    if (!o_dir_read_ok(Scurrent(), arg.u.string))
    {
        /* ls is spec read */
        efun_error("Illegal path\n");
        return;
    }
    ret = list_files(arg.type == T_STRING ? arg.u.string : NULL);
    if (!ret)
        Push(Const(0));
    else
        Push(ret);
}

int remove_file(Shared * path)
{
    if (!o_write_ok(Scurrent(), path)) return 0;

    if (unlink(path->str) == -1)
    {
/*    add_message("No such file: %s\n", path); */
        return 0;
    }
    return 1;
}



void RM()
{
    Val  ret;

    Pop(&ret);
    type_check(&ret, T_STRING, "rm", 1);
    if (!o_write_ok(Scurrent(), ret.u.string))
    {
        efun_error("rm(): No write permission.\n");
        return;
    }
    if (remove_file(ret.u.string))
        Push(Const(1));
    else
        Push(Const(0));
}

void xMKDIR()
{
    Val  arg;

    Pop(&arg);
    type_check(&arg, T_STRING, "mkdir", 1);
    if (!o_write_ok(Scurrent(), arg.u.string))
    {
        efun_error("mkdir(): no write permission\n");
        return;
    }
    if (mkdir(arg.u.string->str, 0770) == -1)
    {
        efun_error("mkdir(): invalid path\n");
        return;
    }
    Push(Const(1));
}

void RMDIR()
{
    Val  ret;

    Pop(&ret);
    type_check(&ret, T_STRING, "rmdir", 1);
    if (o_write_ok(Scurrent(), ret.u.string) &&
        rmdir(ret.u.string->str) != -1)
        Push(Const(1));
    else
        Push(Const(0));
}


int copy_file(Shared *src, Shared *dst)
{
    FILE *src_f, *dst_f;
    int  c;

    if (!o_read_ok(Scurrent(), src)) return 0;
    if (!o_write_ok(Scurrent(), dst)) return 0;

    src_f = fopen(src->str, "r");
    if (src_f == 0)
        return 0;
    dst_f = fopen(dst->str, "w");
    if (dst_f == 0)
    {
        fclose(src_f);
        return 0;
    }
    force_no_su(dst);
    while ((c = fgetc(src_f)) != EOF)
        fputc(c, dst_f);
    fclose(src_f);
    fclose(dst_f);
    return 1;
}

void CP()
{
    Val  src, dst;

    Pop(&dst);
    Pop(&src);
    type_check(&src, T_STRING, "cp", 1);
    type_check(&dst, T_STRING, "cp", 2);
    if (!o_read_ok(Scurrent(), src.u.string))
        efun_error("cp(): no read permission\n");
    if (!o_write_ok(Scurrent(), dst.u.string))
    {
        efun_error("cp(): no write permission\n");
        return;
    }
    if (copy_file(src.u.string, dst.u.string))
        Push(Const(1));
    else
        Push(Const(0));
}

int rename_file(Shared *src, Shared *dst)
{
    extern int sys_nerr;
    /* extern char *sys_errlist[]; */

    if (!o_write_ok(Scurrent(), src)) return 0;
    if (!o_write_ok(Scurrent(), dst)) return 0;

    if (rename(src->str, dst->str) == -1)
    {
        add_message("rename: %s\n",
                    errno < sys_nerr ? sys_errlist[errno] : "unknown error");
        return 0;
    }
    return 1;
}


void xRENAME()
{
    Val  src, dst;

    Pop(&dst);
    Pop(&src);
    type_check(&src, T_STRING, "mv", 1);
    type_check(&dst, T_STRING, "mv", 2);
    if ((!o_write_ok(Scurrent(), src.u.string)) ||
        (!o_write_ok(Scurrent(), dst.u.string)))
    {
        efun_error("rename(): no permission.\n");
        return;
    }
    if (rename_file(src.u.string, dst.u.string))
        Push(Const(1));
    else
        Push(Const(0));
}


#define READ_FILE_MAX_SIZE 60000

Val * char_grab_file(Shared * file, int from, int to)
{
    FILE *f;
    char *buf = 0;
    int  i;
    Val * ret;

    if (!file) return Const(0);

    if (from < 0) from = 0;
    if (to <= 0) to = from + READ_FILE_MAX_SIZE - 1;
    if (from > to) from = to;

    i = file_size(file);
    if (i < 0)
        return Const(0);
    if (i < to)
        to = i;

    f = fopen(file->str, "r");
    if (f == 0)
        return Const(0);
    buf = malloc(to - from + 2);
    fseek(f, (long) from, SEEK_SET);
    i = fread(buf, 1, (to - from + 1), f);
    buf[i] = '\0';
#if 0
    printf("grab_file grabbed:\n%s\n", buf);
#endif
    fclose(f);
    ret = share_string(string_ncopy(buf,i));
    free(buf);
    return ret;
}


/* File access: all should come through grab_file (reading that is) */
void GRAB_FILE()
{
    Val  gfile, f, t;

    Pop(&t);
    Pop(&f);
    Pop(&gfile);
    type_check(&gfile, T_STRING, "grab_file", 1);
    type_check(&f, T_NUMBER, "grab_file", 2);
    type_check(&t, T_NUMBER, "grab_file", 3);
    if (t.u.number == 0)
        t.u.number = -1;
    if (!o_read_ok(Scurrent(), gfile.u.string))
    {
        efun_error("grab_file(%s): no read permission\n", gfile.u.string->str);
        return;
    }
#if 1
    if (f.u.number > t.u.number && t.u.number > 0)
    {
        efun_error("grab_file(%s): from line > to line!\n", gfile.u.string->str);
        return;
    }
#endif
    Push(char_grab_file(gfile.u.string, f.u.number, t.u.number));
}


void TOGGLE_ECHO()
{
    if (Scurrent() == 0) return;
    if (Scurrent()->level < GOD)
    {
        efun_error("Only god level objects can toggle_echo().\n");
        return;
    }
    if (Scurrent()->interactive == 0)
    {
        efun_error("Only interactive objects can toggle_echo().\n");
        return;
    }

    set_noecho(Scurrent(), !Scurrent()->interactive->noecho);
    Push(Const(0));
}

#if 0
void REGEXP()
{
    Val  arg1, arg2, *ret;

    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg1, T_STRING, "regexp", 1);
    type_check(&arg2, (T_STRING | T_POINTER), "regexp", 2);
    ret = lregexp(arg1.u.string, &arg2);
    if (!ret) return;  /* error */
    Push(ret);
}
#endif

/* Stupid efun: should be replaced with in-lpc support */
void ENABLE_COMMANDS()
{
    enable_commands(1);
    Push(Const(0));
}

/* Speed efun: could be made obsolete */
void PRESENT()
{
    Val  arg1, arg2;

    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg1, T_STRING | T_OBJECT, "present", 1);
    if (arg2.type == T_NUMBER)
    {
        arg2.type = T_OBJECT;
        arg2.u.ob = Scurrent();
    }
    type_check(&arg2, T_OBJECT, "present", 2);
    if (arg2.u.ob->destructed)
    {
        efun_error("present() on destructed object.\n");
        return;
    }
    Push(object_present(&arg1, arg2.u.ob));
}


#if 0
/* Stupid efun */
void xCTIME()
{
    Val  arg;
    long tmp;
    char *cp, *s;

    Pop(&arg);
    type_check(&arg, T_NUMBER, "ctime", 1);
    tmp = arg.u.number;
    s = ctime(&tmp);
    /* Now strip the newline. */
    cp = strchr(s, '\n');
    if (cp)
        *cp = '\0';
    Push(make_string(s));
}
#endif

/* Speed efun() */
void INDEX()
{
    Val  arg1, arg2, arg3, arg4;

    Pop(&arg4);
    Pop(&arg3);
    Pop(&arg2);
    Pop(&arg1);
    type_check(&arg4, T_NUMBER, "index", 4);
    type_check(&arg3, T_NUMBER, "index", 3);
    /* type_check(&arg2, T_ANY, "index", 2); */
    type_check(&arg1, T_STRING | T_POINTER, "index", 1);
    Push(make_number(
                 search_array(&arg1, &arg2, arg3.u.number, arg4.u.number)));
}

void SWITCH_INTERACTIVE()
{
    Val  arg1;
    int  i;

#ifdef DEBUG_EFUNS
    printf("SWITCH_INTERACTIVE\n");
#endif

    if (command_giver == 0)
    {
        Push(Const(0));
        return;
    }

    if (Scurrent() && (Scurrent()->level < GOD))
    {
        Push(Const(0));
        return;
    }
#ifdef DEBUG_EFUNS
    printf("SWITCH_INTERACTIVE C\n");
#endif

    Pop(&arg1);
    if (!(arg1.u.ob))
    {
        Push(Const(0));
        return;
    }

    flush_output(command_giver->interactive, 0);
    // Do we really need to add_ref to this object?
    i = replace_interactive(arg1.u.ob);
    Push(make_number(i));
}

