

/*
** $Id: trans.h,v 1.1.1.1 2001/09/11 04:12:41 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/trans.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:41 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _TRANS_H
#define _TRANS_H

int buff_read_val(unsigned char *buff, int len, Val *to);
int buff_write_val(unsigned char * buff, int len, Val *from);

#endif
