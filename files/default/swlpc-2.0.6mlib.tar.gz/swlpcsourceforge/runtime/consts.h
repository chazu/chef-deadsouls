
/*
** $Id: consts.h,v 1.1.1.1 2001/09/11 04:12:28 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/consts.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:28 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _CONSTS_H
#define _CONSTS_H

#define EMPTY 0
#define ID 21
#define INIT 22
#define NUKE 1


#include "stralloc.h"

extern Shared * C(char *);

#endif

