
/*
** $Id: ehash.h,v 1.3 2003/05/25 14:39:41 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/ehash.h,v $
** $Revision: 1.3 $
** $Date: 2003/05/25 14:39:41 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1998
** geoff@serc.rmit.edu.au
*/

#ifndef _EHASH_H
#define _EHASH_H

/*
** Structs for an external hash table
** First the bucket for holding elements and then the table
** definition itself.
*/

typedef struct HASH_ELEMENT 
{
    void * element;
    struct HASH_ELEMENT * next;
} * Hash_element;


typedef struct HASH_TABLE 
{
    int entries;
    int size;
    int (*hash_element)(void * element);
    int (*hash_key)(void * key);
    int (*match)(void * element, void * key);
    Hash_element * table;
} Hash_table;

extern Hash_table * make_hash_table(int size, int (*numelement)(), 
                    int (*numkey)(), int (*match)());
    /* hash table constructor */

extern void   free_hash_table(Hash_table * HT);
    /* hash table destructor */

extern int    remove_hash(Hash_table * HT, void * key);
    /* remove a key from the hash table */

extern int    add_hash(Hash_table * HT, void * element);
    /* add a key to the hash table */

extern void * find_hash(Hash_table * HT, void * key);
    /* find a key in the hash table */

extern int    hash_upsize(Hash_table * HT);
    /* increase the size of the hash table */

extern unsigned int esumstr(const Shared *s);
    /* return a raw hashable value (of the given string) */

#endif
