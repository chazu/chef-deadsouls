/*
	A quick hack for varargs - you get the general
	idea: needs to be fixed for the specific machine
	in question.

	- paritcular where the var args start in relation to 
	  the last parameter &
	- how to access a param using va_arg (NB: mud doesn't use this).

	Geoff
*/

#ifndef _VARARGS_H
#define _VARARGS_H

#ifdef  __cplusplus
extern "C" {
#endif

typedef void 	*va_list;

#define va_start(_X, _P) 	_X = (void *) (&_P)+1
#define va_end(_X)
#define va_arg(_L, _type) 	((_type *)(_L += sizeof (_type)))[-1] 
                                                                                
#ifdef  __cplusplus                                                             
}                                                                               
#endif                                                                          
                                                                                
#endif  

