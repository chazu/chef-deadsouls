
/*
** $Id: apply.h,v 1.2 2001/10/01 15:08:07 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/apply.h,v $
** $Revision: 1.2 $
** $Date: 2001/10/01 15:08:07 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/


#ifndef _APPLY_H
#define _APPLY_H

#include "proto.h"
#include "hash.h"
#include "stack.h"


void 
    apply_clean(Shared * fun, Obj * ob, Val * arg),
    apply_list(Shared * fun, Obj * ob, Val ** args),
    delayed_apply(Shared * fun, Obj * ob, Val * arg)
    ;

int 
    apply_one(Shared * fun, Obj * ob, Val * arg),
    do_apply(Obj * ob, Shared * fun, Func * prog, int loc_num_made)
    ;

char 
    * find_percent(char *str)
    ;

Val 
    * apply_single(Shared * fun, Obj * ob, Val * arg),
    * caught_clone_object(Shared *s),
    ** make_call_args(int have_args,...)
    ;

Func 
    * find_program(Shared *fun, Class *, Class *, Shared * inhname, int prev)
    ;

Exec_block locate_program(Obj * ob, Shared * fun);
    /* External call handler */

#endif
