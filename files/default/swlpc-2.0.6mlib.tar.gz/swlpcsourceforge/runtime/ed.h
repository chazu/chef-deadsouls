
#ifndef _ED_H
#define _ED_H

#include "regexp.h"

#define MAXFNAME 256        /* max file name size */
#define MAXLINE 512         /* max number of chars per line */


struct line {
    int             l_stat; /* empty, mark */
    struct line    *l_prev;
    struct line    *l_next;
    char            l_buff[1];
};
typedef struct line LINE;


struct ed_buffer {
    struct object * ed_object;	/* for remote eds - confers file permissions */
    Shared          * callback;	/* called in ed_object on quit */
    int             diag;	    /* diagnostic-output? flag */
    int             truncflg;	/* truncate long line flag */
    int             eightbit;	/* save eighth bit */
    int             nonascii;	/* count of non-ascii chars read */
    int             nullchar;	/* count of null chars read */
    int             truncated;	/* count of lines truncated */
    char            fname[MAXFNAME];
    int             fchanged;	/* file-changed? flag */
    int             nofname;
    int             mark['z' - 'a' + 1];
    regexp         *oldpat;

    LINE            Line0;
    int             CurLn;
    LINE           *CurPtr;	/* CurLn and CurPtr must be kept in step */
    int             LastLn;
    int             pflag;
    int             Line1, Line2, nlines;
    int             nflg;	/* print line number flag */
    int             lflg;	/* print line in verbose mode */
    int             pflg;	/* print current line after each command */
    int             appending;
};


#endif

