
#include "proto.h"
#include "apply.h"
#include "consts.h"
#include "stralloc.h"

/*
 * This file implements delayed calls of functions. Static functions can not
 * be called this way.
 * 
 * Allocate the structures several in one chunk, to get rid of malloc overhead.
 */

/*
 * Modified to use absolute times, when storing call outs. The original
 * implementation used a complex system of relative times (delta times) that
 * caused a lot of overhead and some hard to trace bugs.
 * 
 * Additional fixes: 1. call out delay is now limited to >= 1 to avoid infinite
 * loops 2. current_object is now handled correctly 3. eval_cost will be set
 * to zero, before calling a function
 * 
 * Modifications made by:   Mika Liljeberg  (liljeberg@hylk.helsinki.fi)
 * Modification date:        8.12.1990
 * 
 * More fixes:            14.12.1990 4. free_call() now removes the
 * reference to the object itself 5. remove_call_out() now returns 0 for an
 * overdue call out
 * 
 * Version 2.4.4 changes    6.1.1991
 * Version 2.4.4-US changes    -- geoff@bruce.cs.monash.edu.au
 * Version omega (:) change  -- geoff@bruce.cs.monash.edu.au July 1993.
 * more changes July 1994 (multiple args etc)
 *            geoff@goanna.cs.rmit.edu.au
 */

#define CHUNK_SIZE    20
#define MAX_CALL_OUTS    8000

extern int      num_made, current_time, current_time_us;
#ifdef EVAL_COST
extern int eval_cost;
#endif

struct call {
    int             abstime;    /* Why muck about with deltas? */
    int            absus;    /* microseconds */
    Shared         *function;
    Obj  *ob;
    struct call    *next;
    Obj  *cmdgvr;
    Val        ** values;
};

#if 0
struct struct call *call_list_free;
#endif

static struct call *call_list;
static int      num_call;
int num_add = 0;
int num_cut = 0;
int num_checks = 0;

extern Val * copy_value(Val *);

/*
 * Free a call out structure.
 */
static void 
free_call(struct call *cop)
{
    int i = 0;

    if (cop->values) 
    {
        while (cop->values[i]) 
        {
            free_value(cop->values[i]);
            free(cop->values[i]);
            i++;        
        }
        free(cop->values);
        cop->values = 0;
    }

    if (cop->function) free_string(cop->function);
    cop->function = 0;

    // if (cop->ob->ref == 1) remove_object_hash(cop->ob);
    //free_object(cop->ob, "call_out (free1)");

    if (cop->cmdgvr != NULL) free_object(cop->cmdgvr, "call_out (free2)");
    cop->next = 0;
    free(cop);
    num_call--;
}

/*
 * Setup a new call out.
 */
int 
new_call_out(Obj * ob, Shared * fun, int call_time, int call_us, Val ** args)
{
    struct call    *cop, **copp;

    /* a nasty hack */
    if (num_call > MAX_CALL_OUTS && fun != C("*NukeDestruct")) return 0;

    update_current_time();
    call_time += current_time;
    call_us += current_time_us;
    if (call_us >= 1000000) 
    {
        call_us -= 1000000;
        call_time++;
    }

    cop = (struct call *)malloc(sizeof(struct call));
    num_call++;

    cop->function = shared_string_copy(fun);
    cop->ob = ob;
    add_ref(ob, "call_out");
    cop->abstime = call_time;
    cop->absus = call_us;
    // Should this really be set to this_player()?
    cop->cmdgvr = command_giver;
    if (command_giver != NULL)  
    {
        add_ref(cop->cmdgvr, "cmdgiv in call_out");
    }
    cop->values = 0;
    if (args) cop->values = args;
    num_add++;
    for (copp = &call_list; *copp && ((*copp)->abstime < call_time
        || ((*copp)->abstime == call_time && (*copp)->absus <= call_us));
            copp = &(*copp)->next);
    cop->next = *copp;
    *copp = cop;
    return 1;
}

/* return time left to first call out in queue, in microseconds (maximum
 * 10 mins - integers).  Used to determine how long to wait in the select
 * in the main player input loop (if nothing's happening, we'll use exact
 * call-out times).  Assumes times have been updated.
 */
int first_call_time_us() 
{
    int diff;

    if ((!call_list) || (call_list->abstime - current_time > 600))
        return 1000000 * 10 * 60;

    diff = (call_list->abstime - current_time) * 1000000 + (call_list->absus - current_time_us);
    /* printf("first call: %f\n", (float) diff/1000000); */
    if (diff > 0)
        return diff;
    return 0;
}

/*
 * See if there are any call outs to be called.
 */
#define MAX_PROCESS    10
void call_out()
{
    extern Obj *command_giver;
    struct call    *cop;
    Obj  *save_command_giver;
    Obj  *save_current_object = Scurrent();
    int count = 0;

    save_command_giver = command_giver;
    if (save_current_object) add_ref(save_current_object, "call_out");
    update_current_time();
    while (call_list && (call_list->abstime < current_time
          || (call_list->abstime == current_time &&
          call_list->absus <= current_time_us))
    && count++ < MAX_PROCESS) 
    {
        /* Move the first call_out out of the chain. */
        update_current_time();
        cop = call_list;
        call_list = call_list->next;
        num_cut++;
        if (!cop->ob->destructed) 
        {
        /*
         * We have to catch an error here, locally. It is not good if the
         * error is catched globally, as the current call out wouldn't be
         * removed.
         */

        /* we *used* to set cmdgvr to cop->ob when it was enabled, else nil. */
            command_giver = cop->cmdgvr;
            if (cop->function == C("*NukeDestruct")) 
            {
                /* we added one on entry! */
                free_object(cop->ob, "call_out (free1)");
                total_destruct(cop->ob);
            }
            else 
            {
                if (set_timer(MAX_LOOP_TIME))
                {

#if 0
                    printf("CALL_OUT: Scurrent=%s\n", cop->ob->name);
#endif
                    /* set the current object for call_outs? */
                    Sset_current(cop->ob, "call_out");
                    /* back-hack - set this_player() */
                    if (cop->cmdgvr && !cop->cmdgvr->destructed)
                    {
                        Shared * thisp = C("set_this_player");
                        extern Obj * Emulate;
                        apply_clean(thisp, Emulate, make_object(cop->cmdgvr));
                    }
                    apply_list(cop->function, cop->ob, cop->values);
                    Sset_current(save_current_object, "call_out 2");
                }
                reset_timer(MAX_LOOP_TIME);
                free_object(cop->ob, "call_out (free1)");
            }
        }
        else
        {
            free_object(cop->ob, "call_out (free1)");
        }
        free_call(cop);
    }
    num_checks++;
    command_giver = save_command_giver;
    if (save_current_object) free_object(save_current_object, "call_out");
}

/*
 * Throw away a call out. First call to this function is discarded. The time
 * left until execution is returned. -1 is returned if no call out pending.
 */
int 
remove_call_out(Obj *ob, Shared * fun)
{
    struct call   **copp, *cop;
    int             delay;

    for (copp = &call_list; *copp; copp = &(*copp)->next)
    {
        if ((*copp)->ob == ob && (*copp)->function == fun) 
        {
            cop = *copp;
            *copp = cop->next;
            delay = cop->abstime > current_time ?
            cop->abstime - current_time : 0;
            free_call(cop);
            return delay;
        }
    }
    return -1;
}

int 
find_call_out(Obj *ob, Shared * fun)
{
    struct call   **copp, *cop;
    int             delay = 0;

    for (copp = &call_list; *copp; copp = &(*copp)->next)
    {
        if ((*copp)->ob == ob && (*copp)->function == fun) 
        {
            cop = *copp;
            /*delay = cop->abstime - current_time; */
            delay = cop->abstime > current_time ?
            cop->abstime - current_time : 0;
            return delay;
        }
    }
    return -1;
}

void delayed_apply(Shared *fun, Obj * ob, Val * arg)
{
    Val ** val_list;

#if 1
    /* we could make this take multiple args.. */
    val_list = make_call_args(1, arg);
    new_call_out(ob, fun, 0, 0, val_list);
#else
    new_call_out(ob, fun, 0, 0, arg);
#endif
}

int 
print_call_out_usage()
{
    int             i;
    struct call    *cop;

    for (i = 0, cop = call_list; cop; cop = cop->next)
    i++;
    add_message("call out      %6d %6d (length %d) (add:%d, cut:%d)\n", num_call,
        num_call * sizeof(struct call), i, num_add, num_cut);
    return num_call * sizeof(struct call);
}

int dump_all_callouts(FILE *p)
{
    struct call * cop;
    update_current_time();

    fprintf(p, "Active call out list\n");
    for (cop = call_list; cop; cop = cop->next) 
    {
        fprintf(p, "%s:%s (%d.%d)\n", cop->ob->name->str,
                 cop->function->str, cop->abstime - current_time,
             cop->absus - current_time_us);       
    }
    fprintf(p, "\n");
    return 0;
}

void init_Cheap()
{
}

void free_Cheap()
{
}



