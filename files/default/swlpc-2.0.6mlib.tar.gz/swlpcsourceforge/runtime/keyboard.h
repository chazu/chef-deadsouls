
/*
	The current keyboard state.
*/
typedef enum {
	keyboard_off,
	keyboard_raw,
	keyboard_direct,
	keyboard_line,
} Keyboard;
