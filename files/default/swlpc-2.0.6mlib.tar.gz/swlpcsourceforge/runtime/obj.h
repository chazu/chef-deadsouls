

/*
** $Id: obj.h,v 1.2 2001/10/30 13:06:20 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/obj.h,v $
** $Revision: 1.2 $
** $Date: 2001/10/30 13:06:20 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _ROBJ_H
#define _ROBJ_H

#include "stralloc.h"

#if 0
static void 
    replace_newline(char *str),
    restore_newline(char *str)
    ;
#endif

int
    hash_living_name(char *str)
    ;


void
    add_ref(Obj *ob, char *from),
    do_tell_npc(char *fun, Obj *ob, char *str),
    dump_all_objects(int type),
    free_object(Obj *ob, char *from),
    set_living_name(Obj *ob, char *str),
    remove_living_name(Obj *ob),
    tell_npc(Obj *ob, char *str),
    tell_object(Obj * ob, char *str)
    ;

int 
    emit_object(FILE *f, Obj *o),
    emit_string(FILE *f, char *s),
    emit_value(FILE *f, Val *v),
    emit_vector(FILE *f, struct vector *v),
    emit_new_string(FILE *f, const char *s),
    read_new_string(FILE *f, char *buff, Val *v),
    read_object(FILE *f, char *buff, Val *v),
    read_string(FILE *f, char *buff, Val *v),
    read_value(FILE *f, char *buff, Val *v),
    read_vector(FILE * f, char *buff, Val *v),
    skip_object(FILE * f, char *buff),
    skip_vector(FILE * f, char *buff),
    restore_object(Obj *ob, const char *file, FILE *flag),
    save_object(Obj *ob, const char *file, FILE *flag),
    find_variable(Obj * ob, char * buff, int offset)
    ;


char 
    * global_by_num(Obj *ob, int vnum) 
    ;


Obj 
    * find_living_object(Shared * str, int player),
    * get_empty_object(int),
    * find_object(Shared *),
    * find_object2(Shared *),
    * find_object_cstr(char *)
    ;


#endif
