
/*
	LPC Profiling module; works by alarming every second
	and gathering statistics on whether or not the stack
	machine is executing at that time. If it is it determines
	in what object:function and adds this to the profile 
	data. This data can be accessed via the PROFILE()
	efun which returns the raw data for processing.
	(oh well - you gotta use dumpallobj at the moment).

	This only works if the GD is started with lpc profiling on.

	Copyright (C) 1994 July, Geoff Wong
	email: geoff@goanna.cs.rmit.edu.au
	snail: 39 Fulton St, St Kilda 3183, Victoria, Australia.

	All code contained herein was written by Geoff Wong.
	The code may not be copied without explicit permission
	from the author (Geoff Wong).
	The code may not be used as part of a package or a service 
	requiring monetary recompense without explicit written permission
	from the author (Geoff Wong).
*/

/* It's not working yet :-) */

extern int executing;
/* this gets called by the alarm */
int doing_prog = 0, doing_other = 0;
profile()
{
	if (executing) {
		doing_prog++;
		if (Scurrent()) Scurrent()->prof++;
	}
	else {
		doing_other++;	
	}
	signal(SIGUSR1, profile);
}
