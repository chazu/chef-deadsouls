/*
** $Id: mud_funs.c,v 1.10 2003/06/02 10:42:29 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/mud_funs.c,v $
** $Revision: 1.10 $
** $Date: 2003/06/02 10:42:29 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#include <ctype.h>
#include <strings.h>
#include <assert.h>
#include <time.h>
#include "security.h"

#include "proto.h"
#include "regexp.h"
#include "lexer.h"
#include "y.tab.h"
#include "opcodes.h"
#include "consts.h"
#include "hash.h"
#include "fsecure.h"
#include "lpc.h"
#include "comm.h"

extern char **str_consts;
extern Shared *last_verb, *current_verb;
extern Shared * make_new_name(Shared * str);
extern Obj * Emulate;


void ppdum() {}

/*
 * Remove an object.
 * The destruct is automatically call_out'ed by .1 second to allow
 * currently executing code to finish.
 * 
 * If the object is inherited, it must not be destructed. So we just rename it
 * to something new. Thus will all pointers to this object continue to work,
 * and new objects that need this object will load a new copy.
 */
int destruct_object(Obj * ob)
{
#if 1
    Val * arg;
    assert(ob!=NULL);
#else
    Val * arg = NULL;
#endif

    // is this secure?
    if (Scurrent())
    {
        arg = apply_single(C("query_destruct"), ob, make_object(Scurrent()));
        if (arg && arg->type == T_NUMBER && arg->u.number != 0
            && Scurrent()->level < ob->level)
        {
            return 0;
        }
        // free_value(arg); -- ?
    }
    else
    {
        arg = apply_single(C("query_destruct"), ob, make_number(0));
    }

    if (ob->destructed)
    {
        efun_error("Attempting to destruct a destructed object.\n");
        return 0;
    }

    // Backward compat hack - update a class with the same
    // name as the class it's cloned from 
    if (ob->name == ob->code->name)
    {
        rename_class(ob->code);
    }

    /* FRONT of call_out queue! */
    new_call_out(ob, C("*NukeDestruct"), 0, 0, 0);
    return 1;
}

void total_destruct(Obj * ob)
{
    Obj *pp, *last, *before;
    Shared * cexit = C("exit");

#if 0
    /* NOTE: debugging */
    printf("total_destruct (object): %s (%d)\n", ob->name->str, ob->ref);
#endif

    /* nuke objects inside us still. */
    for (pp = ob->contains; pp; pp = pp->next_inv)
    {
        destruct_object(pp);
        pp->super = 0;  /* hmm?? */
    }

    /* so dropped objects cant get at us! */
    /* NOTE: perhaps this should be after ob->super is cleaned out? */
    ob->destructed = 1;  
    
    /*
     * Remove us out of this current room (if any). Remove all sentences
     * defined by this object from all objects here.
     */
    if (ob->super)
    {
        if (ob->super->enable_commands && !ob->super->destructed)
            apply_clean(cexit, ob->super, make_object(ob));

        last = 0;
        before = 0;
        for (pp = ob->super->contains; pp; pp = pp->next_inv)
        {
            if (pp == ob) before = last;
            last = pp;
            if (pp->enable_commands && !pp->destructed)
                apply_clean(cexit, pp, make_object(ob));
        }
        if (before)
            before->next_inv = ob->next_inv;  /* remove from inventory */
        else
            ob->super->contains = ob->next_inv;
    }

    /*
     * Now remove us out of the list of all objects. This must be done last,
     * because an error in the above code would halt execution.
     */

    remove_object_hash(ob);

#if 0
    if (ob->living_name) remove_living_name(ob);
#endif

    ob->super = 0;
    ob->next_inv = 0;
    ob->contains = 0;
    ob->enable_commands = 0;
    if (ob->interactive) remove_interactive(ob);

    /*
     * We must deallocate variables here, not in 'free_object()'. That is
     * because one of the local variables may point to this object, and
     * deallocation of this pointer will also decrease the reference count of
     * this object. Otherwise, an object with a variable pointing to itself,
     * would never be freed. Just in case the program in this object would
     * continue to execute, change string and object variables into the
     * number 0.
     */

#if 1
    if (ob->variables)
    {
        /*
         * Deallocate variables in this object. The space of the variables
         * are not deallocated until the object structure is freed in
         * free_object().
         */
        int  i;

        for (i = 0; i < ob->code->num_variables; i++)
        {
            free_value(&ob->variables[i]);
            ob->variables[i].type = T_NUMBER;
            ob->variables[i].u.number = 0;
        }
    }
#endif

    free_object(ob, "total_destruct");
}

/*
 * now gives the string to catch_shout if the monster is still swapped in,
 * catch_scream if it was an emergency.  Good for those special purpose
 * monsters... monsters cannot shout at each other (they shouldnt scream, as
 * it is logged).
 */
void shout_string(Shared *str)
{
    shout_to_players(str);
}

/*
 * This will enable an object to use commands normally only accessible by
 * interactive players. Also check if the player is a wizard. Wizards must
 * not affect the value of the wizlist ranking.
 */

void enable_commands(int num)
{
    if (!Scurrent()) return;
#if 0
    printf("enable_commands on %s\n", Scurrent()->name->str);
#endif
    Scurrent()->enable_commands = num;
}


Val * contents(Val * arg)
{
    Obj *ob = Scurrent();
    Val *ret;
    int  count;

    if (arg->type & T_NUMBER)
        ob = Scurrent();
    else if (arg->type == T_STRING)
        ob = find_object2(arg->u.string);
    else if (arg->type == T_OBJECT)
        ob = arg->u.ob;
    if (ob == 0)
    {
        efun_error("No object in contents()");
        return 0;
    }
    if (ob->contains == 0)
        return allocate_array(0);
    {
        Obj *to;

#ifdef MAXHACK
        for (to = ob->contains, count = 0; to && count < MAXHACK; to = to->next_inv)
#else
        for (to = ob->contains, count = 0; to; to = to->next_inv)
#endif
            if (!to->destructed)
                count++;
    }
    ret = allocate_array(count);
#ifdef MAXHACK
    for (count = 0, ob = ob->contains; ob && count < MAXHACK; ob = ob->next_inv)
#else
    for (count = 0, ob = ob->contains; ob; ob = ob->next_inv)
#endif
    {
        /* assign_value(ret->u.vec->item[count], ob); */
        if (!ob->destructed)
        {
            ret->u.vec->item[count].type = T_OBJECT;
            ret->u.vec->item[count].u.ob = ob;
            add_ref(ob, "contents");
            count++;
        }
    }
#ifdef MAXHACK
    if (count == MAXHACK)
        printf("contents() found fucked inventory on %s\n", ob->name);
#endif
    return ret;
}


/*
 * Transfer an object. The object has to be taken from one inventory list and
 * added to another. The main work is to update all command definitions,
 * depending on what is living or not. Note that all objects in the same
 * inventory are affected.
 */
int move_object(Obj * item, Obj * dest)
{
    Obj **pp, *ob, *save_cmd = NULL;
    Val * tv;
    Shared * cinit = C("init");
    Shared * cexit = C("exit");
    Shared * cinsert = C("insert");
    Shared * thisp = C("set_this_player");

#if 0
    /* checked for in interpret.c */
    if (dest->destructed)
    {
        efun_error("Destructed destination for move_object.\n");
        return 1;
    }
#endif

    // Prepatory stuff
    tv = apply_single(C("this_player"), Emulate, 0);

    if (tv->u.ob != NULL)
    {
        save_cmd = tv->u.ob;
        add_ref(save_cmd, "save_cmd");
        free_value(tv);
    }


    /* Recursive moves are not allowed. */
    for (ob = dest; ob; ob = ob->super)
    {
        if (ob == item) return 0;
    }

    // tell the destination we're "coming" :)
    // NB: perhaps we need to rationlise init() in every object?
    apply_clean(cinsert, dest, make_object(item));
    
    // if we're inside something - exit
    if (item->super)
    {
        int  okey = 0;

        /* if it's a living leaving an object */
        apply_clean(thisp, Emulate, make_object(item));
        if (!item->super->destructed)
            apply_clean(cexit, item->super, make_object(item));

        if (item->enable_commands && !item->destructed)
        {
            apply_clean(cexit, item, make_object(item->super));
        }

        /* it's an object leaving the 'scope' of others */
        for (pp = &item->super->contains; *pp;)
        {
            if (*pp != item)
            {
                if ((*pp)->enable_commands && !(*pp)->destructed) 
                    apply_clean(cexit, (*pp), make_object(item));

                if (item->enable_commands && !item->destructed)
                    apply_clean(cexit, item, make_object(*pp));

                pp = &(*pp)->next_inv;
                continue;
            }
            *pp = item->next_inv;
            okey = 1;
        }

        if (!okey)
        {
            efun_error("Failed to find object %s in super list\n",
            /*of %s.\n", */ item->name);
            /*, item->super->name); */
            return 1;
        }
    }
    item->next_inv = dest->contains;
    dest->contains = item;
    item->super = dest;

    /*
     * Setup the new commands. The order is very important, as commands in
     * the room should override commands defined by the room.
     */
    if (item->enable_commands)
    {
        apply_clean(thisp, Emulate, make_object(item));
        apply_clean(cinit, dest, make_object(item));
    }

    /*
     * Run init of the item once for every present player, and for the
     * environment (which can be a player).
     */
#ifdef MAXHACK
    for (xx = 0, ob = dest->contains; ob && xx < MAXHACK; xx++, ob = ob->next_inv)
#else
    for (ob = dest->contains; ob; ob = ob->next_inv)
#endif
    {
        if (ob == item) continue;
        if (ob->enable_commands)
        {
            apply_clean(thisp, Emulate, make_object(ob));
            apply_clean(cinit, item, make_object(ob));
        }
        if (item->enable_commands)
        {
            apply_clean(thisp, Emulate, make_object(item));
            apply_clean(cinit, ob, make_object(item));
        }
    }
#ifdef MAXHACK
    if (xx == MAXHACK)
        printf("move_object() found fucked inventory on %s\n", dest->name);
#endif
    if (dest->enable_commands)
    {
        apply_clean(thisp, Emulate, make_object(dest));
        apply_clean(cinit, item, make_object(dest));
    }

    if (save_cmd != NULL) 
    {
        apply_clean(thisp, Emulate, make_object(save_cmd));
        free_object(save_cmd, "move_object");
    }

    return 0;
}

/*
 * This one is called from HUP.
 */
int  game_is_being_shut_down = 0;

void startshutdowngame()
{
    game_is_being_shut_down = 1;
}

/*
 * This one is called from the command "shutdown". We don't call it directly
 * from HUP, because it is dangerous when being in an interrupt.
 */
void shutdowngame()
{
    Obj *object;

    if (!game_is_being_shut_down && !command_giver)
        return;
    if (game_is_being_shut_down)
    {
        debug_message("Game shutdown via HUP signal\n");
    }
    else
    {
        debug_message("Game shut down by %s.\n", (command_giver->su_name ?
                                                  command_giver->su_name->str :
                                                  "(game driver)"));

    }
    shout_string(string_copy("Game driver shouts: Shutting down immediately.\n"));
    fprintf(stderr, "Driver shutdown.\n");
    ipc_remove();
    object = find_object_cstr(OBJ_MASTER);
    if (object)
    {
        apply_clean(C("quit"), object, 0);
    }
    remove_all_players();  /* master should have done this */
/* need to exit from game from here.. */
}

void slow_shut_down(int minutes)
{
    Obj *ob;
    Val  v;

    /* doesn't load OBJ_SHUT - must be pre-loaded */
    /* bad to try and load if we're out of mem!   */
    ob = find_object_cstr(OBJ_SHUT);
    if (!ob)
    {
        shout_string(string_copy("! Game driver shouts: Out of memory!\n"));
        startshutdowngame();
        return;
    }
    shout_string(string_copy("! Game driver shouts: The memory is getting low !\n"));
    v.type = T_NUMBER;
    v.u.number = minutes;
    apply_clean(C("shut"), ob, &v);
}

int match_string(char *match, char *str)
{
    int  i;

  again:
    if (*str == '\0' && *match == '\0')
        return 1;
    switch (*match)
    {
        case '?':
            if (*str == '\0')
                return 0;
            str++;
            match++;
            goto again;
        case '*':
            match++;
            if (*match == '\0')
                return 1;
            for (i = 0; str[i] != '\0'; i++)
                if (match_string(match, str + i))
                    return 1;
            return 0;
        case '\0':
            return 0;
        case '\\':
            match++;
            if (*match == '\0')
                return 0;
            /* Fall through ! */
        default:
            if (*match == *str)
            {
                match++;
                str++;
                goto again;
            }
            return 0;
    }
}

Val *users()
{
    Obj *ob;
    extern int num_player;      /* set by comm1.c */
    int  i;
    Val *ret;

    ret = allocate_array(num_player);
    for (i = 0; i < num_player; i++)
    {
        ret->u.vec->item[i].type = T_OBJECT;
        ret->u.vec->item[i].u.ob = ob = get_interactive_object(i);
        add_ref(ob, "users");
    }
    return ret;
}
