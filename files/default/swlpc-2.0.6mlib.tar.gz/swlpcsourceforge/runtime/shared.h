
/*
** $Id: shared.h,v 1.1.1.1 2001/09/11 04:12:40 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/shared.h,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:40 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _SHARED_H
#define _SHARED_H

extern Val Callvlist(void * func, int args, Val ** a);

extern void 
    EXT_C_CALL(),
    LOAD_SHARED_OBJECT(),
    UNLOAD_SHARED_OBJECT()
    ;

#endif

