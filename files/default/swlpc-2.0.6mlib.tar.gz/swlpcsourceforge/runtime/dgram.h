

/*
** $Id: dgram.h,v 1.2 2003/01/16 04:04:30 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/dgram.h,v $
** $Revision: 1.2 $
** $Date: 2003/01/16 04:04:30 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** mmcg@cs.monash.edu.au
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
*/

#ifndef _DGRAM_H
#define _DGRAM_H

#if 0
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
/* #include <sys/un.h> */
#include <arpa/inet.h>
#endif
#include "comm.h"
#include <errno.h>

#include "value.h"
#include "trans.h"
#include "gd_config.h"

int 
    do_dg_read(int s),
    do_dg_write(int a,int b,int c,int d,int port,char *buf, int len),
    do_dg_retry(),
    retry_send(struct sockaddr_in *addr, char * buf, int len)
    ;

extern int dgram_sock;

#endif

