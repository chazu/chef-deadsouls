
/*
** $Id: ehash.c,v 1.5 2003/05/25 14:39:41 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/ehash.c,v $
** $Revision: 1.5 $
** $Date: 2003/05/25 14:39:41 $
** $State: Exp $
**
** Authors: Geoff Wong and Michael McGaughey
** Emails: geoff@cs.rmit.edu.au, mmcg@cs.monash.edu.au
** Copyright(C) 1993, 1996, 1998
** geoff@serc.rmit.edu.au
*/

#include <stdlib.h>
#include <stdio.h>
#include "proto.h"
#include "ehash.h"

/* s - string, maxn - maximum # of chars, hashs - htable size */
unsigned int esumstr(const Shared *s)
{
    register unsigned int h = 0;
    register unsigned char *p;
    register unsigned l = s->length;
#if 0
    p = ((unsigned char *)s) - 1;
    do {
    h = h * 3 + (*++p);
    } while (*p);
#else
    p = s->str;
    while (l) 
    {
        h = h * 3 + *p;
        p++;
        l--;
    }
#endif
    /* nb: h is unsigned, so this is positive */
    return (h/3);
}

Hash_element new_bucket()
{
    Hash_element tmp;
    tmp = (Hash_element) malloc(sizeof(struct HASH_ELEMENT));
    tmp->next = NULL;
    tmp->element = NULL;
    return tmp;
}

void free_bucket(Hash_element e)
{
    free(e);
}

/* 
 * Make a hash table with an initial size and a 
 * pointer to the hashing function to be used
 */

Hash_table * make_hash_table(int size, int (*hashelement)(), 
            int (*hashkey)(), int (*match)())
{
    Hash_table * ret;
    int i;

    ret = (Hash_table *) malloc(sizeof(struct HASH_TABLE));
    ret->table = (Hash_element *) malloc(size * sizeof(struct HASH_ELEMENT));
    ret->size = size;
    ret->entries = 0;
    ret->hash_element = hashelement;
    ret->hash_key = hashkey;
    ret->match = match;
    for (i = 0; i < size; i++) 
    {
        ret->table[i] = NULL;
    }
    return ret;
}

/* clean it up */
void free_hash_table(Hash_table * HT)
{
    /* FIX: free all the buckets */
    free(HT->table);
    free(HT);
}

int remove_hash(Hash_table * HT, void * key)
{
    int h;
    Hash_element tmp, last;

    h = (*(HT->hash_key))(key) % HT->size; 

    tmp = HT->table[h];
    last = NULL;
    while (tmp != NULL)
    {
        if ((*(HT->match))(tmp->element, key))
        {
            /* remove it from the chain */
            if (last != NULL) 
            {
                last->next = tmp->next;
                free_bucket(tmp);
            }
            else
            {
                // NOTE: was only this: HT->table[h] = NULL;
                HT->table[h] = tmp->next;
                free_bucket(tmp);
            }
            HT->entries--;
            return 1;
        }
        last = tmp;
        tmp = tmp->next;
    }
    return 0;
}

/*
 * Add an element to the table
 * returns 0 if it already exists
 * returns 1 for a successful addition
 */

int add_hash(Hash_table * HT, void * element)
{
    int h;
    Hash_element tmp;

    h = (*(HT->hash_element))(element) % HT->size;

    tmp = new_bucket();
    tmp->element = element;
    tmp->next = HT->table[h];
    HT->table[h] = tmp;
    HT->entries++;
    
    return 1;    
}


void * find_hash(Hash_table * HT, void * key)
{
    int h;
    Hash_element tmp;

    h = (*(HT->hash_key))(key) % HT->size;

    tmp = HT->table[h];
    while (tmp != NULL) 
    {
        if ((*(HT->match))(tmp->element,key))
        {
            /* function found */
            return tmp->element;
        }
        tmp = tmp->next;
    }
    return 0;
}
