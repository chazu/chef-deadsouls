/*
**
** $Source: /cvsroot/swlpc/swlpc/runtime/lpc.c,v $
** $Revision: 1.4 $
** $Date: 2003/03/23 22:59:33 $
** $State: Exp $
**
** Author: Geoff Wong
**         geoff@serc.rmit.edu.au
** Copyright (C) 1999
** See the file "Copying" distributed with this file.
**
** A "shell" capable LPC (alternative main to Mud main).  
** 
** Initially non-interactive.
** Later allow line-by-line LPC (global scope of some kind)
*/

#include <time.h>
#include <sys/time.h>
#include <sys/types.h>  /* for umask et al */
#include <sys/stat.h>  /* for umask et al */
#ifndef __WIN32__
#include <sys/resource.h>
#endif
#include <signal.h>
#include <errno.h>
#include "proto.h"
#include "interpret.h"
#include "lpc.h"
#include "stack.h"
#include "apply.h"
#include "consts.h"
#include "class.h"

/* catch_value is for * catch/throw */
static Val *catch_value; 
double consts[5];

/* debugging stuff */
static FILE * debugfp;
int  d_flag = 0;         

#ifdef YYDEBUG
extern int yydebug;
#endif

/* profiling stuff */
int  profile_it = 0;
char *profbuf = 0;
#ifdef C_PROFILE
extern etext(), eprol();
#endif

/* possible chroot */
char mud_lib[256];              
char *zero;

/* global stuff - declared but not used. */
Obj * Master = 0;
Obj * Emulate = 0;
//int remote_command = 0;
int Wiz_Mud = 0;

/*
 * Name: initialise()
 * Purpose: initialise key tables etc throughout the engine
 */
void initialise()
{
    int  i;

    umask(UMASK);

    init_strings();
    init_str_consts();
    install_optable();
    init_lex_space();
    init_class_table();
    init_Otable();
    debugfp = stderr;
    if (debugfp)
    {
        force_no_su(C(DEBUG_LOG));
        Serror_stream(debugfp);
    }

#ifdef C_PROFILE
    if (profile_it)
    {
        profbuflen = (char *) etext - (char *) eprol;
        profbuf = (char *) malloc(profbuflen);
        profil((char *) profbuf, profbuflen, (char *) eprol, 0x10000);
    }
#endif

    /* Random stuff */
#ifdef HAVE_SRANDOM
    srandom(time(0));
#else
    fprintf(stderr, "No random generator specified!\n");
#endif /* SRANDOM */
    install_oc();
    for (i = 0; i < sizeof consts / sizeof consts[0]; i++)
        consts[i] = 0;  /*exp (-i / 900.0); */

    /* Key constants */
    init_str_consts();
    Sinit_stack();
    Sset_external_handler(call_efun);
    Sset_program_handler(locate_program);
    zero = (char *) malloc(sizeof(char) * 4);

    catch_value = Const(0);

}

/*
 * Name: script
 * Purpose:  start up an object, load it and run "main"
 *      Later this will be changed to run 'loose' code rather
 *      than a main function. Also eventually will run interactively.
 */

int script(const char * name, FILE * fp, Val * lpcargv)
{
    Obj * ob;
    Class * code;
    Shared * sname = string_copy(name);

    LPC_set_line(0);
    LPC_set_file(name);

    /* Use the compiler library */
    code = LPC_compile(sname, fp, 1);
    if (code == NULL) return 0;

    ob = instantiate_class(code);
    if (ob == NULL) return 0;

    /* Now assign lpcargv */
    if (lpcargv != NULL && ob->variables != NULL)
    {
        assign_value(&(ob->variables[0]), lpcargv);
    }

    apply_clean(C("*InitGlobals"), ob, NULL);

    return 1;
}

int main(int argc, char **argv)
{
    int i;
    FILE * fp;
    char * name;
    Val * lpcargv = NULL;

    mud_lib[0] = '\0';

    /* initialise some key global values */
    strcpy(mud_lib, MUD_LIB);

    /* parse command line parameters */
    for (i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "-m") == 0)
        {
            /* chroot */
            i++;
            strcpy(mud_lib, argv[i]);
        }
#ifdef YYDEBUG
        else if (strcmp(argv[i], "-y") == 0)
        {
            yydebug = 1;
        }
#endif
        else break;
    }

    /* Ok - get the script file name */
    if (i < argc)
    {
        name = str_copy(argv[i]);
        fp = fopen(name, "r");
        if (fp == NULL)
        {
            fprintf(stderr, "Unable to read script %s.\n", argv[i]);
            exit(1);
        }
        i++;
    }
    else
    {
        fp = stdin;
        name = str_copy("lpshell");
    }

    /* chroot() only works if we're root - but a good safety feature */
    /* chdir(mud_lib); */
#ifndef __WIN32__
    chroot(mud_lib); 
#endif

#if 0
    printf("main: Initialising tables.\n");
#endif
    initialise();

    /* build an array of remained argv's */
    if (i <= argc)
    {
        int j, count = 0;

        lpcargv = allocate_array(argc-i);
        for (j = i; j < argc; j++)
        {
            assign_value(&(lpcargv->u.vec->item[count++]), make_string(argv[j]));
        }
    }

    /* MAIN LOOP */
    if (script(name, fp, lpcargv)) return 0;

    exit(1);
}

static int no_debug_loop = 0;

#define MAX_MESSAGE 1024
void debug_message(const char *fmt,...)
{
    char a[MAX_MESSAGE];
    static int writes_until_close = 64;
    static char *debug_log = NULL;

    va_list args;

    va_start(args, fmt);
    vsprintf(a, fmt, args);
    va_end(args);

    if (debug_log == NULL)
    {
#ifndef DEBUG_LOG
        char name[100];

        gethostname(name, sizeof name);
        debug_log = (char *) malloc(strlen(name) + 11);
        strcpy(debug_log, name);
        strcat(debug_log, ".debug.log");
#else
        debug_log = string_copy(DEBUG_LOG)->str;
#endif
    }
    if (writes_until_close == 0)
    {
        debugfp = stderr;
        if (debugfp)
        {
            force_no_su(C(DEBUG_LOG));
            Serror_stream(debugfp);
        }
        writes_until_close = 64;
    }
    if (debugfp == NULL)
    {
        perror(debug_log);
        /* abort (); */
        /* should notify the game driver */
        if (!no_debug_loop)
        {
            no_debug_loop = 1;
            /* apply_clean(Master, C("alert"), make_string(a));
             * wipe(1); */
            no_debug_loop = 0;
        }
    }
    (void) fprintf(debugfp, a);
    (void) fflush(debugfp);
    if (--writes_until_close == 0)
    (void) fclose(debugfp);

#if 0
    if (command_giver)
        add_message("%s", a);
#endif
}

void debug_message_value(Val * v)
{
    if (v == 0)
    {
        debug_message("<NULL>");
        return;
    }
    switch (v->type)
    {
        case T_NUMBER:
            debug_message("%d", (char *) v->u.number);
            return;
        case T_STRING:
            debug_message("\"%s\"", v->u.string);
            return;
        case T_POINTER:
            debug_message("POINTER(%s)", "you want me to print it?");
            return;
        case T_OBJECT:
            debug_message("OBJ(%s)", v->u.ob->name);
            return;
        default:
            fatal("<INVALID>\n");
            return;
    }
}

