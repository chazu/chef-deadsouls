

/*
** $Id: dgram.c,v 1.2 2003/01/30 04:11:02 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/dgram.c,v $
** $Revision: 1.2 $
** $Date: 2003/01/30 04:11:02 $
** $State: Exp $
**
** Author: Mike McGaughey
** Copyright(C) 1993-1998
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.        
*/

#include <stdlib.h>
#include "stack.h"
#include "dgram.h"
#include "consts.h"
#include "proto.h"

#if AUTO_RETRY

/*
	Auto retry stuff

	. Circular buffers for send/receive.
	. Can be receiving from many clients.
	. Can send to many clients.

	Copyright Geoff Wong 1995
*/
struct buffer {
	char * string;	
	int len;
    	struct sockaddr_in sock;
	int frame;
	unsigned char age;
	unsigned char retry;
};

struct rbuff {
	struct sockaddr_in sock;
	int frame;
}

#define RESEND_AGE 64
#define BUFFER_SIZE 256
#define MAX_RETRY  5

typedef struct buffer * Buffer;
typedef struct rbuff * Rbuffer;

Buffer send_buffer[BUFFER_SIZE];
Rbuffer receive_buffer[BUFFER_SIZE];

int send_start = 0, send_finish = 0;
int rec_start = 0, rec_finish = 0;

do_dg_retry()
{
	int i, e;
	/* age send_buffer */
	for (i = send_start; i < send_finish; i++) {
		e = i % BUFFER_SIZE;
		if (send_buffer[e].frame) {
			send_buffer[e].age++;
		/* re-send if necessary */
			if (send_buffer[e].age > RESEND_AGE) {
			    retry_send(&(send_buffer[e].sock),
				send_buffer[e].string, 
				send_buffer[e].len);
			    send_buffer[e].age = 0;
			    send_buffer[e].retry++;
			    if (send_buffer[e].retry > MAX_RETRY) {
				/* nuke me! (give up) */
				send_buffer[e].frame = 0;
				if (i == send_start) send_start++;
			    }
			}
		}
	}
}
#endif

/*
	Function called when something is waiting.
*/
int do_dg_read(int s)
{
    Obj * oldCO = Scurrent();
    char dbuff[DG_BUFF];
    struct sockaddr_in from;
    int fromlen = sizeof(from);
    int nb;


    nb = recvfrom(s, &(dbuff[0]), DG_BUFF, 0, (struct sockaddr *)&from, &fromlen);
    if (nb < 0) {
	perror("recvfrom (dgram)");
	return 0;
	}

#if AUTO_RETRY
	{
		int i;
	/* check for ACKs/frame_number */
	/* if found remove from re-send list */
		if (dbuff[0] == ACK) {
			/* don't resend */
			if (dbuff[1] < rec_start || dbuff[1] > rec_finish) {
				/* ignore ? */
			}
			else if (send_buffer[dbuff[1] % 256].frame ==
							 dbuff[1].frame)
				send_buffer[dbuff[1] %256].frame = 0;	
		}
	/* check frame number - if we've already received it */
	/* send an ACK! else add to receive_buffer */
		else {
			/* add to received buffer */
			receive_buffer[i].frame = dbuff[1];	
			receive_buffer[i].sock = from;
			/* send ACK */
			retry_send(&from, ACK, fromlen);
		}
	}
#endif

/*    { int x ; printf("\n"); for (x=0; x<nb; x++) printf("%d ",dbuff[x]); printf("\n"); }  */
/* package up the incoming message for the mudlib datagram serv.
 * Passed to DATAGRAM_SERVER as:
 *	datagram_recv ( ({ a, b, c, d, port }), status, val )
 *	if it came from (a.b.c.d:port) and was read (by buff_read_val) as val.
 *	status is the return code from buff_read_val - (-2) if it thinks
 *	it was truncated, other negatives for errors.
 */
    Sset_current(find_object_cstr(OBJ_DATAGRAM_SERV), "dgram");
    if (Scurrent()) {
	    Val * marr = allocate_array(5);
	    Val ** val_list, dg_data,status;

/* 
 * the mips compiler is good about unsigned chars, etc.
 * if you get problems with these, suspect yours.
 */

#ifndef Sunos
	/* is this the wrong way around?? */
	    marr->u.vec->item[0].u.number = (from.sin_addr.s_addr) & 0xff;
	    marr->u.vec->item[1].u.number = (from.sin_addr.s_addr >> 8) & 0xff;
	    marr->u.vec->item[2].u.number = (from.sin_addr.s_addr >> 16) & 0xff;
	    marr->u.vec->item[3].u.number = (from.sin_addr.s_addr >> 24) & 0xff;
#else
	    marr->u.vec->item[0].u.number = from.sin_addr.S_un.S_un_b.s_b1;
	    marr->u.vec->item[1].u.number = from.sin_addr.S_un.S_un_b.s_b2;
	    marr->u.vec->item[2].u.number = from.sin_addr.S_un.S_un_b.s_b3;
	    marr->u.vec->item[3].u.number = from.sin_addr.S_un.S_un_b.s_b4;
#endif
	    marr->u.vec->item[4].u.number = ntohs(from.sin_port);
	    status.type = T_NUMBER;
	    status.u.number = buff_read_val(dbuff, nb,&dg_data); 
	    val_list = make_call_args(3, marr, &status, &dg_data );
	    new_call_out(Scurrent(), C("dgram_recv"), 0, 0, val_list);
	    // wipe (1);
    	Sset_current(oldCO, "dgram 2");
	}
	else { 
	    perror ("Couldnt find OBJ_DATAGRAM_SERV : "); 
	}
    Sset_current(oldCO, "dgram 3");
    return 0;
}

/*
 * Send `buf' down a datagram socket - to (a.b.c.d:e).
 */

int do_dg_write(int a,int b,int c,int d,int port,char *buf, int len)
{
    struct sockaddr_in t;
    int tolen = sizeof(t);
    int nb;

#if 0
	if (a == 130 && b == 194 && c != 64 )
		return 0;
#endif

#ifndef Sunos

/*    t.sin_addr = make_inet_addr(a,b,c,d);  */
	/* is this the wrong way around?? */
    t.sin_addr.s_addr = a + (b << 8) + (c << 16) + (d << 24);

#else
    t.sin_addr.S_un.S_un_b.s_b1 = a;
    t.sin_addr.S_un.S_un_b.s_b2 = b;
    t.sin_addr.S_un.S_un_b.s_b3 = c;
    t.sin_addr.S_un.S_un_b.s_b4 = d;
#endif
    t.sin_port = htons(port);
    t.sin_family = AF_INET;

#if 0
    printf("sendto %d.%d.%d.%d:%d (%d)", a,b,c,d,port, t.sin_addr.s_addr);
    { int x ; printf("\n"); for (x=0; x<len; x++) printf("%d ",buf[x]); printf("\n"); }
#endif
    nb = sendto(dgram_sock, buf, len, 0, (struct sockaddr *)&t, tolen);
    if (nb < 0) {
	perror("sendto (dgram) ");
    	printf("sendto failed %d.%d.%d.%d:%d (%d)\n", a,b,c,d,port,
						 t.sin_addr.s_addr);
	return errno;
    }
#if AUTO_RETRY
    else {
	send_buffer[send_finish++] = ;
    }
#endif
    return 0;
}
    

#if AUTO_RETRY
retry_send(struct sockaddr_in *addr, char * buf, int len)
{
    nb = sendto(dgram_sock, buf, len, 0, (struct sockaddr *)&t, tolen);
    if (nb < 0) {
	perror("sendto (dgram) ");
    	printf("sendto failed %d.%d.%d.%d:%d (%d)\n", a,b,c,d,port,
						 t.sin_addr.s_addr);
	return errno;
    }
}

#endif

