/*
** $Id: comm.h,v 1.4 2003/02/23 10:27:38 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/comm.h,v $
** $Revision: 1.4 $
** $Date: 2003/02/23 10:27:38 $
** $State: Exp $
**
** See the file "Copying" distributed with this file.
*/

#ifndef _COMM_H
#define _COMM_H

#include <sys/types.h>
#include <sys/time.h>
#ifdef __WIN32__
#include <winsock2.h>
#define ioctl(A,B,C) ioctlsocket(A,B,C)
#else
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include "ed.h"
#endif
 
#include "../config.h"
#include "stralloc.h"
#ifdef HAVE_ZLIB_H
#include "zlib.h"
#endif

// Some Network Constants
#define MAX_TEXT_IN 2048
#define MAX_TEXT_OUT 65536
#define OUTPUT_BUFFER_SIZE 4096

struct interactive 
{
    int             socket;
    struct object   *ob;		/* Points to the associated object */

    // Flag stuff
    char            closing;	/* True when closing this socket. */
    char            noecho;	    /* Don't echo lines */
    char            snoopcheck;

#ifndef GO32
#ifndef SINGLE_USER_DRIVER
    struct sockaddr_in addr;	/* real incoming address */
#endif
#endif
    Shared * ipaddr;		/* where they originally came from */

    struct interactive *snoop_on, *snoop_by; /* shouldn't be in driver */

    int             my_ext_socket;	/* socket for external program comms */

#ifdef HAVE_ZLIB_H
    z_stream * my_z_stream;  /* compression stream */
#endif

#ifndef __WIN32__
    struct sockaddr_un my_ext_addr;	/* address for our socket */
    struct sockaddr_un extern_addr;	/* address for external socket */
    struct ed_buffer * ed_buffer;
#endif

    // External Program Interface Stuff
    int             extern_socket;	/* socket connected to */
    int             extern_pid;	/* the process number of the external program */
    char          **args;	/* arguments to external program */
    char          **env;	/* environment to external program */
    Shared         *finito_call;/* the routine to call on completion */
    struct object  *finito_callee;	/* the object to call the routine in */
    int             extern_status;	/* exit code of program or -1 if not
					 * finshed */
    int             extern_timeout;	/* timeout for external programs */

    // Input Buffer
    char            text[MAX_TEXT_IN];
    int             text_start;	/* where we are up to in player cmd buffer */
    int             text_end;	/* first free char in buffer */

    // Output Buffer (currently only for compression)
    char            output[OUTPUT_BUFFER_SIZE];
    int             out_start;
    int             out_end;
};

typedef struct interactive Interactive;

#define MAX_SOCKET_PACKET_SIZE	255	/* Wild guess, was 1024 */
#define EXTERN_TIMEOUT 50	        /* number of heartbeats to wait before
				                    * aborting external programs after exit */

void 
    add_output(struct interactive * ip, int filter_eol, Shared * buff),
    binary_output(struct interactive * ip, unsigned char *, unsigned int),
    add_message(const char *fmt, ...),
    clear_notify(),
    flush_players(),
    flush_output(struct interactive *ip, int p),
    ipc_remove(),
    new_player(int which, int new_socket, struct sockaddr_in *addr, int len),
    notify_no_command(),
    prepare_ipc(),
    remove_all_players(),
    remove_interactive(Obj *ob),
    set_notify_fail_message(Shared * str),
    set_prompt(char *str),
    set_snoop(Obj * me, Obj * you),
    shout_to_players(Shared * str),
    show_info_about(char * str, char * room, struct interactive *i)
    ;

int 
    get_message(char *buff, int size),
    mk_bnd_sock(int ty, int proto, int port_number),
    replace_interactive(Obj *ob),
    set_ip_number(char *s, Obj *o),
    set_noecho(Obj *ob, int noecho),
    snoop_ok(struct interactive *on),
    update_io(int quick)
    ;

char 
    * query_host_name(),
    * query_ip_number(Obj *ob)
    ;

Obj
    * get_interactive_object(int i)
    ;

Val 
    * query_snoop(Obj *ob)
    ;

struct interactive *
    find_extern_pid(int ProcId)
    ;


#endif
