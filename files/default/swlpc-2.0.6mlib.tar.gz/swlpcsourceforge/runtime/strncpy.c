/*
 * Just to see if we can fiddle the assembly to make it faster
 */

char * strncpy(char * t, char * f, int n) {
    register char * nt;
    nt = t;
    while ((n--) > 0 && (*(nt++) = *(f++)))
	;
    return t;
    }
