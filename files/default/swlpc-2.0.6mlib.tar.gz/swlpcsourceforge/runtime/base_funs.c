/*
** $Id: base_funs.c,v 1.3 2003/03/24 00:29:16 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/base_funs.c,v $
** $Revision: 1.3 $
** $Date: 2003/03/24 00:29:16 $
** $State: Exp $
**
** Author: Mike McGaughey & Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
** mmcg@cs.monash.edu.au
**
** See the file "Copying" distributed with this file.
*/

#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#include <ctype.h>
#include <strings.h>
#include <time.h>
#include "security.h"

#include "proto.h"
#include "lexer.h"
#include "y.tab.h"
#include "opcodes.h"
#include "consts.h"
#include "hash.h"
#include "fsecure.h"
#include "comm.h"

Val *explode_string(Shared *shstr, Shared *del)
{
    int num = 0, len;
    char * p, * beg;
    char * buff;
    char * str = shstr->str;
    int slen = shstr->length;
    Val * ret;

    len = del->length;

    if (slen >= len)
    {
        // Skip leading 'del' strings, if any.
        while ((memcmp(str, del->str, len) == 0))
        {
            str += len;
            if ((str - shstr->str) == slen) return Const(0);
            else if ((str - shstr->str) < len) break;
        }

        // fix length
        slen = slen - (str - shstr->str);

        // Find number of occurences of the delimiter 'del'.
        for (p = str; (p-str) <= (slen-len);)
        {
            if (memcmp(p, del->str, len) == 0)
            {
                num++;
                p += len;
            }
            else
                p++;
        }

        // Compute number of array items. It is either number of delimiters, or,
        // one more.
        if ((memcmp(str + slen - len, del->str, len) != 0)) num++;
    }
    else
    {
        num++;
    }

    // adjust for new length
    buff = malloc(slen + 1);
    ret = allocate_array(num);

    for (p = str, beg = str, num = 0; (p-str) <= (slen-len);)
    {
        if (memcmp(p, del->str, len) == 0)
        {
            memcpy(buff, beg, p - beg);
            buff[p - beg] = '\0';
            if (num >= ret->u.vec->size)
            {
                debug_message("Array size exceeded in explode (%s)!\n",
                              Scurrent()->name);
                free(buff);
                return ret;
            }
            assign_value(&ret->u.vec->item[num], make_nstring(buff, p - beg));
            num++;
            beg = p + len;
            p = beg;
        }
        else
        {
            p += 1;
        }
    }

    // Copy last occurence, if there was not a 'del' at the end. 
    if ((beg-str) < slen)
    {
        assign_value(&ret->u.vec->item[num], make_nstring(beg, slen-(beg-str)));
    }

    free(buff);
    return ret;
}

Val *implode_string(struct vector * arr, Shared * del)
{
    int  size, i, num, tot;
    char *p, *q;
    Val *ret;

    for (i = 0, size = 0, num = 0; i < arr->size; i++)
    {
        if (arr->item[i].type == T_STRING)
        {
            size += arr->item[i].u.string->length;
            num++;
        }
    }
    if (num == 0) return Const(0);
    tot = size + (num - 1) * del->length;
    p = malloc(tot + 1);
    q = p;
    p[0] = '\0';
    for (i = 0, size = 0, num = 0; i < arr->size; i++)
    {
        if (arr->item[i].type == T_STRING)
        {
            if (num > 0)
            {
                memcpy(p, del->str, del->length);
                p += del->length;
            }
            memcpy(p, arr->item[i].u.string->str, 
                                arr->item[i].u.string->length);
            p += arr->item[i].u.string->length;
            num++;
        }
    }
    q[tot] = '\0';
    ret = make_nstring(q, tot);
    free(q);
    return ret;
}

int search_array(Val * a, Val * s, int start, int skip)
{
    struct vector *arr;
    char *str;
    int  i;

    if (skip <= 0) skip = 1;

    if (a->type == T_POINTER)
    {
        arr = a->u.vec;
        for (i = start; i < arr->size; i += skip)
        {
            if (arr->item[i].type == T_STRING && s->type == T_STRING)
                if (arr->item[i].u.string == s->u.string
                /*|| !strcmp(arr->item[i].u.string, s->u.string) */ )
                    return i;
            /* should be ok with shared strings */
            /* if (!strcmp(arr->item[i].u.string,s->u.string)) return i; */
            if (arr->item[i].type == T_NUMBER && s->type == T_NUMBER)
                if (arr->item[i].u.number == s->u.number)
                    return i;
            if (arr->item[i].type == T_REAL && s->type == T_REAL)
                if (arr->item[i].u.real == s->u.real)
                    return i;
            if (arr->item[i].type == T_POINTER && s->type == T_POINTER)
                if (arr->item[i].u.vec == s->u.vec)
                    return i;
            if (arr->item[i].type == T_OBJECT && s->type == T_OBJECT)
                if (arr->item[i].u.ob == s->u.ob)
                    return i;
        }
        return -1;
    }
    else if (a->type == T_STRING)
    {
        int  j;

        if (a->u.string->length < start) return -1;
        str = a->u.string->str;

        if (s->type != T_STRING)
        {
            int m;

            m = s->u.number;

            for (j = start; j < a->u.string->length; j++)
            {
                if (str[j] == m)
                    return j;
                
            }
        }
        else
        {
            int  x;
            char * m;

            m = s->u.string->str;
            x = s->u.string->length;

            for (j = start; j < a->u.string->length; j++)
            {
                if (!memcmp(&(str[j]), m, x))
                    return j;
            }

        }
        return -1;
    }
    else
        return -1;
}


#define HOST_NAME_LEN 128

char           *
query_host_name()
{
    static char     name[HOST_NAME_LEN];

    gethostname(name, sizeof name);
    name[sizeof name - 1] = '\0';	/* Just to make sure */
    return name;
}

