#include "proto.h"
/*
 * Write statistics about objects on file.
 */


static int value_size(struct value *v)
{
    int i, total;

    switch(v->type) {
    case T_OBJECT:
    case T_NUMBER:
	return 0;
    case T_STRING:
	return v->u.string->length + 8; /* Includes some malloc overhead. */
    case T_POINTER:
	for (i=0, total = 0; i < v->u.vec->size; i++) {
	    total += value_size(&v->u.vec->item[i]) + sizeof (struct value);
	}
	return total;
    default:
	fatal("Illegal type %d\n", v->type);
    }
    return 0;
}

static int data_size(Obj * ob)
{
    int total = 0, i;

    for (i = 0; i < ob->num_variables; i++)
	total += value_size(&ob->variables[i]) + sizeof (struct value);
    return total;
}

void dumpstat() 
{
    FILE *f;
    Obj * ob;

    f = fopen("OBJ_DUMP", "w");
    if (f == 0)
	return;
    add_message("Dumping to OBJ_DUMP ...");
#if 0
    for (ob = obj_list; ob; ob = ob->next_all) {
	int tmp;
	if (ob->prog->num_ref == 1 || !ob->cloned)
	    tmp = ob->swap_size;
	else
	    tmp = 0;
	fprintf(f, "%-30s %5d ref %2d\n", ob->name->str,
		data_size(ob) + sizeof (struct object), ob->ref);
    }
#endif
    add_message("done.\n");
    fclose(f);
}
