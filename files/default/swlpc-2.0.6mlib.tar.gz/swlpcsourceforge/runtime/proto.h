
//#ifndef _GNU_C_
//#define inline
//#define __inline__
//#endif

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#if 1
#include <stdarg.h> 	/* if your system needs this */
#else
#include "varargs.h"
#endif
#include "../config.h"
#include "gd_config.h"
#include "object.h"
#include "stack.h"
#include "apply.h"

/* #define const	*//* define if your compiler doesn't have "const" */
/* #define signed   *//* define if your compiler doesn't have "signed" */

#ifdef __WIN32__
/* in case your libraries are retarded (sysV) */
#define bcopy(src,dest,len)     (memmove((dest), (src), (len)))
#define bzero(dest,len)         (memset((dest), (char)0, (len)))
#define bcmp(b1,b2,n)           (memcmp((b1), (b2), (n)))
#define index(s,c)              strchr((s), (c))
#define rindex(s,c)             strrchr((s), (c))
#define random()                rand()
#define srandom(_X)             srand(_X)
#define gettimeofday(_X,_TZ)        ((_X)->tv_usec = 0, time(&(_X)->tv_sec))
#define link(_X,_Y)             rename(_X,_Y)
#endif

char 
 	*dump_trace(void),
	*query_ip_number (struct object *),
	*find_percent(char *)
    ;

Shared
	*function_exists (Shared *, struct object *)
    ;

struct lexical_string	*lex_str_copy(char *);
struct lnode *linearise(struct lnode *, int);

unsigned char
	* code_size_fix(struct function_def *);

int 	special_parse (char *), 
	yyparse(void), 
	do_write(struct value *),
 	stype_check(unsigned char *, int, char *, char *),
	count_value_ref (struct object *),
	say (struct value *, struct value *),
	tell_room (struct object *, struct value *),
	destruct_object (struct object *),
	search_array (struct value *, struct value *, int, int),
	parse_command (char *, struct object *, int),
	legal_path (char *),
	print_call_out_usage(void),
	swap (struct object *),
	move_object(struct object *, struct object *),
    query_idle (struct object *),
	copy_in_vector (struct vector *, struct vector *, int, int, int ),
	apply_as_ob (char *, struct object *, struct value *),
	copy_file(Shared *, Shared *),
	rename_file(Shared *, Shared *),
	write_file(Shared *, Shared *),
	file_size(Shared *),
	Pushc(int),
	remove_call_out (struct object *, Shared *), 
	find_call_out(struct object *, Shared *),
	new_call_out(Obj *, Shared *, int, int , Val **),
    set_timer(int),
    dump_all_callouts(FILE *p),
    first_call_time_us(),
    new_call_out(Obj *, Shared *, int, int, Val **),
    dump_oc_profile(int)
    ;

void	
    logon(struct object *),
	fatal(const char *, ...),
    terminal_error(void),
    catchable_error(void),
    exec_halt(void),
    backend(void),
	add_message (const char *, ...),
	debug_message (const char *, ...),
	efun_error(const char *, ...),
	stack_error(const char *, ...),
	clean(int),
	Clean(struct value *, int),
    enable_commands(int),
	init_Cheap(void),
	free_Cheap(void),
	init_lex_space(void),
	init_str_consts(void),
	free_lex_space(void),
	total_destruct(struct object *),
	emits(unsigned char),
	emit(unsigned char, unsigned char),
	emit16(unsigned char, short),
	emit32(unsigned char, char *),
	emitreal(unsigned char, float),
    patch8(int loc, unsigned char val),
    patch16(int loc, short pval),  
	apply(char *, struct object *, struct value *),
	inter_sscanf(void),
	caught_apply (char *, struct object *, struct value *),
	update_load_av(void),
    update_current_time(),
	perror (const char *),
	caller(void),
	previous_object(void),
	set_living_name(struct object *, char *),
	remove_interactive (struct object *),
	remove_object_hash(struct object *),
    add_action (Shared *, Shared *, int),
	print_local_commands(void),
	ipc_remove(void),
	remove_living_name(struct object *),
	show_info_about (char *, char *, struct interactive *),
	set_snoop (struct object *, struct object *),
	remove_all_players(void), start_new_file(FILE *),
	startshutdowngame(void),
	load_ob_from_swap (struct object *), dump_malloc_data(void),
	dump_all_objects(int),
	debug_message_value(struct value *),
	grep_file (char *, char*, char *),
	clear_assign(struct value *, struct value *),
	assign_value(struct value *, struct value *),
	Push(Val *),
	Pop(Val *),
	Catch(void *),
	execute(void),
	wipe(int),
	clear_stack(void),
	init_stats(void),
	init_strings(void),
	install_optable(void),
	init_Otable(void),
	init_stack_space(void),
	install_oc(void),
    reset_timer(),
    dump_process_data(),
    dump_status_data(),
	free_value (struct value *);


struct object 
	*find_living_object(Shared *, int),
	*lookup_object_hash (Shared *),
	*enter_object_hash (struct object *)
    ;

struct value  
	*alloc_stack_value(),
	*implode_string (struct vector *, Shared *),
	*char_grab_file(Shared *, int, int),
    *copy_value(struct value *),
	*explode_string(Shared *, Shared *),
	*clone_object(Shared *, Shared *),
	*get_one_expr (struct lnode **, char *),
	*allocate_array (int),
	*make_object (struct object *),
	*make_number (int),
	*make_space (int),
	*make_real (float),
	*make_Cobject (struct object *),
	*make_Cnumber (int),
	*make_Creal (float),
	*make_Cstring ( char *),
	*contents (struct value *),
	*concatenate (struct value *, struct value *),
 	*users(void),
	*ob_clone_object(Class *, Shared *),
	*this_player(void),
	*input_to(char *, int),
	*this_object(void),
	*object_present(struct value *, struct object *),
	*call_other(struct value *, char *, struct value *),
	*environment(struct value *),
	*query_snoop(struct object *),
	*call_local_function(char *, struct value *),
	*query_load_av(void),
    *list_files (Shared *),                                                   
    *lregexp(Shared *, struct value *);                                       


struct keyword * lookup_predef(char *);

float getreal(struct value *);

#ifdef GRAPHICS
struct image * load_vga(char *, FILE *)
	;

int 	next_event(void);
#endif

#if 0
/*
 * We don't fix leaks, we use a garbage collector - mike.
 * NB: the GC package has an awesome leak detector anyway; supersedes leak.c
 */

#ifdef MALLOC_GCmalloc	/* set by makefile */

/* #include "GC/gc.h" */

#define malloc(s)	GC_malloc(s)
#define xalloc(s)	GC_malloc(s)
#define realloc(p, s)	GC_realloc(p, s)
#define xrealloc(p, s)	GC_realloc(p, s)
#define calloc(m,n) GC_malloc((m)*(n)) /* gc malloc initialises it */
#if 1
#define free(p)		GC_free(p)
#else
#define free(p)		1	/* no frees - mud crashes less, but you'll never find the bugs! */
#endif

#endif

#endif

/*
	(old)	Leak fixing stuff
*/

#ifdef FIND_LEAKS

#include <sys/types.h>

extern int	leak_logging;
extern void	leak_dump(void);
extern void	leak_clear(void);

extern void	*leak_malloc(size_t, const char *, int);
extern void	*leak_realloc(void *, size_t, const char *, int);
extern void	leak_free(void *, const char *, int);
extern void	*leak_calloc(size_t, size_t, const char *, int);

#define malloc(s)	leak_malloc(s, __FILE__, __LINE__)
/* #define xalloc(s)	leak_malloc(s, __FILE__, __LINE__) */
#define realloc(p, s)	leak_realloc(p, s, __FILE__, __LINE__)
#define free(p)		leak_free(p, __FILE__, __LINE__)
#define calloc(s, t)	leak_calloc(s, t, __FILE__, __LINE__)

#endif

