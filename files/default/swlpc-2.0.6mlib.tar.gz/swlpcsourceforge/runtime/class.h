
//
// Support for Classes
//
// Author: Geoff Wong, 2001.
//

#ifndef _CLASS_H
#define _CLASS_H

#include "object.h"

void init_class_table();

int class_ele_hash(void * ele);
int class_key_hash(void * key);
int class_match(void * ele, void * key);

void add_class_ref(Class * code, const char * from)
        ;

Class 
    * find_class(Shared * name),
    * get_empty_class()
        ;

void 
    rename_class(Class * code),
    free_class(Class * code, const char * from)
        ;

int
    add_class(Class * code),
    remove_class(Class * code)
        ;

#endif

