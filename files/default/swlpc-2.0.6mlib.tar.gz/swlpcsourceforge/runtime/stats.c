#ifndef __WIN32__
#define RUSAGE
#endif

#include <time.h>
#include <sys/types.h>
#include <sys/time.h>
#ifndef __WIN32__
#ifdef RUSAGE
#include <sys/resource.h>
#endif
#endif
#include <errno.h>
#include <ctype.h>
#include "proto.h"
#include "lexer.h"
#ifdef GO32
#include "y_tab.h"
#else
#include "y.tab.h"
#endif
#include "opcodes.h"
#include "security.h"
#include "hash.h"
#include "lpc.h"
#include "comm.h"

time_t start_time;
struct timeval el_time;
int el_secs;
int cpusecs;

void init_stats() 
{
    start_time = time((long *)0);
}

void setup_el_time() 
{
    long x = time((long *)0);
    el_time.tv_sec = x - start_time;
    if (el_time.tv_sec < 1) el_time.tv_sec = 1;
    el_time.tv_usec = 0;
    el_secs = el_time.tv_sec;
}


static char tbuf[200];

char * showsex(struct timeval *t)
{
    int as = t->tv_sec;
    sprintf(tbuf, "%2d:%02d:%02.2f",
	as/3600, (as%3600)/60, (as%60)+(((float)t->tv_usec)/1000000));
    return tbuf;
}

void showusex(int x)
{
    char buff[100];
    char * f;
    int i;
    sprintf(buff, "%d (%d/CPUsec, ", x, x / cpusecs);
    if (x / el_secs > 1) {
	f = "sec";
	i = x / el_secs;
	}
    else
	if ((x * 60) / el_secs > 1) {
	    f = "min";
	    i = (x * 60) / el_secs;
	    }
	else {
	    f = "hr";
	    i = (x * 3600) / el_secs;
	    }
    sprintf(buff + strlen(buff), "%d/%s)", i, f);
    add_message(buff);
}

#ifdef RUSAGE

void dump_rusage(struct rusage * wot)
{
    char buff[200];
    cpusecs = wot->ru_utime.tv_sec + wot->ru_stime.tv_sec;
    if (cpusecs < 1) cpusecs = 1;
    sprintf(buff, "CPU: %su + ", showsex(&wot->ru_utime));
    sprintf(buff + strlen(buff), "%ss;  Max RSS: %ldk\n",
		showsex(&wot->ru_stime), wot->ru_maxrss );
    add_message(buff);
    sprintf(buff, "Avg data: %ldk, Avg stack: %ldk, Full Swap: %ld\n",
	wot->ru_idrss / el_secs, wot->ru_isrss / el_secs, wot->ru_nswap);
    add_message(buff);
    add_message("Blocks read: ");
    showusex(wot->ru_inblock);
    add_message(" written: ");
    showusex(wot->ru_oublock);
    add_message("\nI/O-using page faults: ");
    showusex(wot->ru_majflt);
    add_message("\nIPC messages in: ");
    showusex(wot->ru_msgrcv);
    add_message("; out: ");
    showusex(wot->ru_msgsnd);
    add_message("\n");
}
#endif

void dump_process_data() 
{
    setup_el_time();
    add_message("Main process: up %s\n", showsex(&el_time));
#ifdef RUSAGE
    { struct rusage me, child;
    getrusage(RUSAGE_SELF, &me);
    dump_rusage(&me);
    add_message("SubProcs:\n");
    getrusage(RUSAGE_CHILDREN, &child);
    dump_rusage(&child);
    }
#else
    add_message("No resource usage stats available\n");
#endif
}

void dump_status_data() 
{
#if 0
			tot_alloc_object,
			max_num_values, 
            num_value_allocs, 
            num_value_frees,
			tot_string_space,
			bytes_distinct_strings,
			overhead_bytes
            ;
#endif
	int             total = 0;

#ifdef ARRAY_STATS
	add_message("Array num:   %6d size: %10d\n", num_arrays,
			(total += total_array_size));
#endif
#if 0
	add_message("Values:      %5d %6d\n", tot_alloc_value,
		    tot_alloc_value * sizeof(struct value));
	add_message("Temp values: max: %d creates:%d frees:%d\n",
		 max_num_values, num_value_allocs, num_value_frees);
#endif
	total += show_otable_status();
    add_message("%s", add_string_status());
	total += string_space_used();
#if 0
	total += tot_alloc_value * sizeof(struct value);
#endif
	total += show_ihash_table_status();
	total += print_call_out_usage();
	total += show_prog_status();
#if 0
	total += show_stack_status();
#endif
	add_message("Total bytes:   %d\n", total);
}


/* "type" is one of the following:
 * 0 - all objects
 */

extern Obj ** obj_table;

void dump_all_objects(int type)
{
    Obj            * ob;
    FILE           * d;
    extern int     num_distinct_strings;
    int x;

    d = fopen("OBJ_DUMP", "w");
    if (!d) 
    {
        add_message("Couldn't open dump file.\n");
        return;
    }
    add_message("Dumping data to 'OBJ_DUMP'... ");
    for (x=0; x<OTABLE_SIZE; x++)
    {
        ob = obj_table[x];

        while (ob)
        {
            if (!ob->name)
                fprintf(d, "<NULL> (0x%x)  ", (unsigned int) ob);
            else
                fprintf(d, "%s (0x%x)  ", ob->name->str, (unsigned int) ob);
            if (ob->code->inherit) 
            {
                int _i;
                for (_i = 0; ob->code->inherit[_i]; _i++) 
                {
                if (ob->code->inherit[_i]->name)
                    fprintf(d, "Inherit %s (0x%x) ", ob->code->inherit[_i]->name->str, (unsigned int) ob->code->inherit[_i]);
                else
                    fprintf(d, "Inherit <NULL> (0x%x) ", (unsigned int) ob->code->inherit[_i]);
                }
            }

            if (ob->super) 
            {
                if (ob->super->name)
                    fprintf(d, "Super %s (0x%x)\n", ob->super->name->str, (unsigned int) ob->super);
                else
                    fprintf(d, "Super <NULL> (0x%x)\n", (unsigned int) ob->super);
            } 
            else
                fprintf(d, "\n");
            fprintf(d, "Suid level %d; su name %s\n", ob->level, (ob->su_name ?
                           ob->su_name->str : "<none>"));
            fprintf(d, "Ref %2d Enbl_cmd %d Clnd %d Inhtd %d \n\thp %x need Rst %d \n",
                ob->ref, ob->enable_commands, ob->cloned, ob->code->inherited,
                0, 0 /* (current_time - ob->not_touched) */);
            ob = ob->next_hash;
        }
    }

    fprintf(d, "Num arrays = %d\n",  num_arrays);
    fprintf(d, "Num strings = %d\n",  num_distinct_strings);

    dump_all_callouts(d);
    fclose(d);
    add_message("DONE\n");
}

