/*
** $Id: shared.c,v 1.5 2003/01/31 04:15:32 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/shared.c,v $
** $Revision: 1.5 $
** $Date: 2003/01/31 04:15:32 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
**
** Built-in shared Object support functions
** Enables other C code to be included in a "clean" fashion
** NOTE: loading/destroying shared objects probably should be
**      restricted to god objects
**
*/
#ifdef __WIN32__
#include <ltdl.h>
#define dlopen(A,B) lt_dlopen(A)
#define dlsym(A,B) lt_dlsym(A,B)
#define dlclose(A) lt_dlclose(A)
#define dlerror() lt_dlerror()
#else
#include <dlfcn.h>
#endif
#include "stack.h"
#include "stack_alloc.h"
#include "lpc.h"

/* A FreeBSD hackism */
#ifndef RTLD_GLOBAL
#define RTLD_GLOBAL   0x100
#endif
#ifndef RTLD_NOW
#define RTLD_NOW   0x00002
#endif

Val * Callvlist(void * func, int args, Val ** a);

void LOAD_SHARED_OBJECT()
{
    Val arg1;
    void * handle;
    char * error;

    Pop(&arg1);
    type_check(&arg1, T_STRING, "load_shared_object", 1);

    handle = dlopen (arg1.u.string->str, RTLD_NOW | RTLD_GLOBAL);

    if (!handle)
    {
        error = dlerror();
        efun_error("load_shared_object: (%s) failed: %s.\n", arg1.u.string->str,
            error);
        return;
    }

    /* handle returned as a number */
    /* casting to int is ugly - need another void * value handle */

    Push(make_number((int)handle));
}

void UNLOAD_SHARED_OBJECT()
{
    void * handle;
    char * error;
    Val arg1;

    /* get the shared object handle */
    Pop(&arg1);
    type_check(&arg1, T_NUMBER, "ext_c_call", 2);

    handle = (void *) arg1.u.number;

    if (handle != NULL)
        dlclose(handle);

    if ((error = dlerror()) != NULL)
    {
        efun_error("unload_shared_object: %s\n", error);
        return;
    }

    Push(Const(0));
}

void EXT_C_CALL()
{
    int  have_args = 0, orig_args;
    Val  arg, arg1, arg2;
    Val ** val_list;
    void * func, * handle;
    char * error;

    have_args = Popc();  /* pop the control stack */
    have_args -= 2;  /* obj, func ( args ) */
    orig_args = have_args;
    if (have_args < 0)
    {
        efun_error("Not enough args to ext_c_call().\n");
        return;
    }
    if (have_args)
    {
        val_list = (Val **) malloc((have_args + 1) * sizeof(Val *));
        val_list[have_args] = 0;

        while (have_args--)
        {
            Pop(&arg2);
            val_list[have_args] = alloc_stack_value();
            assign_value(val_list[have_args], &arg2);
        }
    }
    else
        val_list = NULL;

    /* get the function to be called */
    Pop(&arg);
    type_check(&arg, T_STRING, "ext_c_call", 1);

    /* get the shared object handle */
    Pop(&arg1);
    type_check(&arg1, T_NUMBER, "ext_c_call", 2);

    handle = (void *) arg1.u.number;
    func = dlsym(handle, arg.u.string->str);

    if ((error = dlerror()) != NULL)
    {
        efun_error("ext_c_call: can't find %s(%s)\n", arg.u.string->str, error);
        return;
    }
    
    Push(Callvlist(func, orig_args, val_list));

    /* clean up allocated space */
    free(val_list);
}

Val * Callvlist(void * func, int args, Val ** a)
{
    Val * ret = NULL;
	Val * (*func0)(), 
        * (*func1)(Val *), 
        * (*func2)(Val *,Val *),
		* (*func3)(Val *,Val *,Val *), 
        * (*func4)(Val *,Val *,Val *,Val *),
		* (*func5)(Val *,Val *,Val *,Val *,Val *), 
        * (*func6)(Val *,Val *,Val *,Val *,Val *,Val *),
		* (*func7)(Val *,Val *,Val *,Val *,Val *,Val *,Val *), 
        * (*func8)(Val *,Val *,Val *,Val *,Val *,Val *,Val *,Val *);

	switch(args)
	{
		case 0:
			func0 = func;
			ret = func0();
			break;
		case 1:
			func1 = func;
			ret = func1(a[0]);
			break; 
        case 2:
			func2 = func;
			ret = func2(a[0], a[1]);
			break;
		case 3:
			func3 = func;
			ret = func3(a[0], a[1], a[2]);
			break;
		case 4:
			func4 = func;
			ret = func4(a[0], a[1], a[2], a[3]);
			break;
		case 5:
			func5 = func;
			ret = func5(a[0], a[1], a[2], a[3], a[4]);
			break;
		case 6:
			func6 = func;
			ret = func6(a[0], a[1], a[2], a[3], a[4], a[5]);
			break;
		case 7:
			func7 = func;
			ret = func7(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
			break;
		case 8:
			func8 = func;
			ret = func8(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
			break;
		default:
			efun_error("Too many parameters (%d) to ext_c_call.\n", args);
			break;
	}
	return ret;
}

