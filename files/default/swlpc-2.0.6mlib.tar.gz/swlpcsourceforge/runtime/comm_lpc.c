
/*
** $Id: comm_lpc.c,v 1.1.1.1 2001/09/11 04:12:26 dredd Exp $
**
** $Source: /cvsroot/swlpc/swlpc/runtime/comm_lpc.c,v $
** $Revision: 1.1.1.1 $
** $Date: 2001/09/11 04:12:26 $
** $State: Exp $
**
** Author: Geoff Wong
** Copyright(C) 1993-1999
** geoff@serc.rmit.edu.au
**
** See the file "Copying" distributed with this file.
**
** comm_lpc: stdin/stdout comms module.
*/

#include <stdio.h>
#include "stack.h"

void add_message(const char *fmt, ...)
{
    static char mess_buff[10000];
    Val *o;
    va_list args;

    va_start(args, fmt);
    vsprintf(mess_buff, fmt, args);
    va_end(args);

    printf("%s", mess_buff);
    fflush(stdout);
}

/* stub hack for fatal() */
void ipc_remove()
{
}

