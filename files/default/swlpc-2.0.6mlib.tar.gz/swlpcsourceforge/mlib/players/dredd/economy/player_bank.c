/*
 *	Player Owned Bank -- Dredd 1992 Shattered World.
 *
 *  Player banks should `advance' cash from the central
 *  bank to meet its needs. It can loan cash to
 *  give it a pool of money to play with..
 *  Deposits give it more..
 */

inherit "players/dredd/economy/central_bank";
inherit "room/room";	/* hmm? */

const HOUSING = "players/llati/real/state";
#define FILE_NAME file_name(this_object())

int 	credit_limit; 	/* banks maximum debt */

set_credit(int x) 	
{ 
	set_needs_update();
	credit_limit = x; 
}

query_credit() 		
{ 
    return credit_limit; 
}

query_cash() 
{ 
	return query_account("#bank");
}

