restore_me()
{
	restore_object(SAVE_FILE);
	if (!purchase) purchase = allocate(MAX_GOODS);
	if (!sell) sell = allocate(MAX_GOODS);
	if (!goods) goods = allocate(MAX_GOODS);
	if (!sale_goods) sale_goods = ({ });
	if (!numbers) numbers =  ({ });
	if (!match) match = ({ });
	if (!de_value) de_value = 100;
}

int add_money(int x) {
	money = money + x; 
	if (x) save_me();
	return money;
}

int query_money() { return money; }

remove_owner(string name)
{
int x;
string own;
	x = index(owners, name);
	if (x < 0) return;
	if (!owners || !sizeof(owners)) return;
	own = owners[0];
	owners = owners[..x-1]+owners[x+1..];
	if (x == 0) { /* hmm - name is being changed! */
		save_me();
	}
}

add_owner(string name)
{
	if (!owners) owners = ({ name });
	else owners = owners + ({ name });
}

/* urk hack */
set_owner(string name)
{
	if (owners) owners[0] = ({ name });
	else owners = ({ name });
}

/* returns the first owner if !who */
int query_owner((int|object) who)
{
int i;
	if (!owners || !pointerp(owners)) return;
	if (!who) return owners;
	for (i = 0; i < sizeof(owners); i++)
	{
		if (owners[i] == who->query_real_name()) return 1;
	}
}

