#define FILE 0
#define OWNER 1
#define KEY_CODE 2
#define BROCHURE 3
#define CAPITAL_COST 4
#define TIMESTAMP 5

/*
file is the room filename
owner is a string
key is the key code
brochure is a short desc of the house
capital is the base value of the house
timestamp is the last time it was entered (stocked for pubs)
*/
