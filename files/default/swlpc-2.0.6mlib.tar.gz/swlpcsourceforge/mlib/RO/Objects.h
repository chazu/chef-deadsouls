/*
 * Standard names for inheritable or cloneable objects.
 */

/* less err messages */

#ifndef	STDOBJS_H
#define	STDOBJS_H

/*
 * Basic Objects - Inheritable
 */
#define BASE_OBJ		"RO/base_object"
#define	STD_OBJ			"std/object"
#define	MONSTER			"obj/monster"
#define	WEAPON			"obj/weapon"
#define	ARMOUR			"obj/armour"


/*
 * Standard souls - Inheritable
 */
#define	BASE_SOUL		"obj/souls/base_soul"
#define BASE_RACE_SOUL		"obj/souls/races/race_soul"


/* 
 * Standard souls - Cloneable
 */
#define	ROUTER_SOUL		"std/map/track"
#define	MARKER_SOUL		"players/gandalf/Tiny/marker"


/* 
 * Basic Objects - Inheritable
 */
#define WET_OBJ			"obj/wet"


/*
 * Some other stuff.
 */
#define	NEW_PLAYER		"RO/new_player"

/* Do Not put anything below this line */
#endif
