/* Type definitions for the data file parser */

#define STRING 1
#define INT 2
#define REAL 4
#define VAR_ARGS 8       /* Dont know the number of elements in the array */
