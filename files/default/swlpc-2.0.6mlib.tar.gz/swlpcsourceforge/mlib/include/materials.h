/*
 * Materials definitions files, for most of the inanimate objects
 * you find in the game.  Weapons, armour and "standard" objects can all
 * be made out of any of these.  They have different characteristics
 * and resistances to things - CLOTH/WOOD/LEATHER are succeptible to burning,
 * IRON/STEEL/TEMPERED/BRONZE are succeptible to acid, BONE/TOOTH/STONE are
 * variants of the same thing, with different strengths and brittleness,
 * etc.
 */

#define	MAT_NUMBER	13

#define MAT_IRON	0
#define MAT_STEEL	1
#define MAT_TEMPERED	2
#define MAT_WOOD	3
#define MAT_LEATHER	4
#define MAT_BONE	5
#define MAT_TOOTH	6
#define MAT_STONE	7
#define	MAT_PAPER	8
#define	MAT_GLASS	9
#define MAT_CLOTH	10
#define MAT_BRONZE	11
#define MAT_FLESH   12
#define MAT_SILVER  13

