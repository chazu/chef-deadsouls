
#define MAX_GOODS 30
#define MAX_SALE_GOODS 24	/* different sale items; may have 10 daggers */
#define MAX_PRICE 100000
#define SAVE_FILE file_name(this_object())
#define CONTAINER "std/object"
#define BARREL "players/dredd/economy/barrel"

#define PARSE "lib/handle_parse"
#define DESCRIBE "lib/describe"
#define SAY "lib/say"
#define PRESENT "lib/present2"

