
#define VOTE_PROCESSOR "players/dredd/law/vote"
#define RULE_BOOK "players/dredd/law/rules_book"
#define RULES_SERVER "players/dredd/law/rules_book"

#define BRIEF 0
#define INFULL 1

#define RULE_NUM 0
#define RULE_TEXT 1
#define CATEGORY 2
#define PROPOSED 3
#define CHANGED_DATE 4
#define AMENDED_BY 5
#define SIZEOFINFULL 6
