#define HWF_1H 1
#define HWF_2H 2
#define HWF_hand 4
#define HWF_throw 8
#define HWF_cut 16
#define HWF_smash 32
#define HWF_hit 64
#define HWF_thrust 128
#define HWF_Hafted 256

