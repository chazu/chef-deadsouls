/* types */
#define WIN_INPUT 0
#define WIN_OUTPUT 1
#define WIN_MIXED 2

/* positions */
#define WIN_TOP 0
#define WIN_UP 1
#define WIN_BOTTOM 2
#define WIN_DOWN 3
#define WIN_FREE 4

/* data stored in ioprocess */

#define WINDAT_TYPE 0
#define WINDAT_POSITION 1
#define WINDAT_HEIGHT 2
#define WINDAT_TOP_LINE 3
#define WINDAT_BOTTOM_LINE 4
#define WINDAT_PREV_WIN 5
#define WINDAT_NEXT_WIN 6
#define WINDAT_CURR_COL 7
#define WINDAT_SIZE 8
