/* Used by both std/protection and std/damage, so kept in the one header
 * file.
 */

#define TYPE            0
#define AMT             1
#define LOC             2
#define PERC            3
#define REJUV           4
#define CALLBACK_OBJ    5
#define CALLBACK_FUN    6
#define USED            7

