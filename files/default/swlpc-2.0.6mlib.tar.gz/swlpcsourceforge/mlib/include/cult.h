#define LEADER 5
#define HIGH_PRIEST 4
#define PRIEST 3
#define INITIATE 2
#define ACOLYTE 1
#define LAY_MEMBER 0

#define CULT_POWER_SERV "guilds/cult/power_server"
#define CULT_SOUL "guilds/cult/master_soul"
#define CULT_SERV "guilds/cult/mast"

/* A heirachy array is defined in /guilds/cult/heirachy.h
  It isnt here because it would create alot of copies of
  that array for no real reason. */
