
#define MAX_GOODS 30
#define MAX_SALE_GOODS 24	/* different sale items; may have 10 daggers */
#define MAX_PRICE 100000
#define SAVE_FILE file_name(this_object())
#define CONTAINER "std/object"
#define BARREL "players/dredd/economy/barrel"

#define PARSE "players/dredd/lib/parse"
#define DESCRIBE "players/dredd/lib/describe"
#define SAY "players/dredd/lib/say"
#define PRESENT "players/dredd/lib/present"

