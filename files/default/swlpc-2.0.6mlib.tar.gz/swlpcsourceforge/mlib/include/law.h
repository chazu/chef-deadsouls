#define LAW_SERV "obj/law/S/law"
#define NEW_CITIZEN_SERV "obj/law/S/new_citizen"
#define NEW_LAW "obj/law/S/new_law"
#define CITIZEN_SERV "obj/law/S/citizen"
#define LAW_BOARD "obj/bulletin/board_serv/law_discussion"
#define JUDGEMENT "obj/law/S/judgement"

#define BRIEF 0
#define INFULL 1

#define IMMUTABLE 1
#define MUTABLE 2
#define COMMON 3

