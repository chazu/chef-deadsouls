#define BBOARD "obj/bulletin/bboard"
#define BBOARD_CLASS "obj/bulletin/board_class"
#define RBOARD_SERV  "RO/remote/rboard"  /* Server for remote comm. */
#define BOARD_SERV "obj/bulletin/board_serv"
#define BBOARD_NOTE_READER "obj/bulletin/notes_reader"
