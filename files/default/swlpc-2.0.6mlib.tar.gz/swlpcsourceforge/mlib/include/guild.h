/* these #defines are bit values for the flag in the 'join' function.
*	NO_COMMON bit means that the person will not be added to
*	the common guild file.
*	REJOIN means that one player can be put in the list of members
*	more than once (useful for the common guild file, since people
*	can be members of more than one guild)
*/

#define NO_COMMON 1
#define REJOIN 2

