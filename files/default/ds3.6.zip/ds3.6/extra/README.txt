Extras directory

- restore_cfg If you screw up your mudos.cfg file, you can use this to
  get it back.

- I added a creremote/ dir with stuff you'll need to take advantage
  of Dead Souls RCP support. However, the stuff in this dir is not
  Dead Souls stuff, so it is not supported by me.
 
- crat/ has some scripts I use, if you understand them, great, if
  not, don't worry. They're not for you.

- wolfpaw/ has some includes and stuff that are necessary to
  run in one of the servers provided by Wolfpaw. If you're not
  a customer of theirs, disregard that stuff.
