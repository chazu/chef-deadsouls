#include <lib.h>
inherit LIB_BOARD;

void create(){
    ::create();
}

void init(){
    ::init();
}

