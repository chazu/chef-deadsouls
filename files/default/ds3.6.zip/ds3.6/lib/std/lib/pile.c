#include <lib.h>

inherit LIB_PILE;

void create(){
    ::create();
}

void init(){
    ::init();
}
