#include <lib.h>

inherit LIB_ROOM;

void create(){
    ::create();
}

void init(){
    ::init();
}
