#include <lib.h>

inherit LIB_FURNACE;

void create() {
    furnace::create();
}
void init(){
    ::init();
}
