#include <lib.h>

inherit LIB_SENTIENT;

void create(){
    sentient::create();
}

void init(){
    sentient::init();
}
