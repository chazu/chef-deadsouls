#include <lib.h>
#include <objects.h>

inherit OBJ_QUEST;

void create(){
    ::create();
}

void init(){
    ::init();
}
