/*    /domains/campus/adm/access.c
 *    From the Dead Souls Object Library
 *    the access object for the campus domain
 *    created by Descartes of Borg 960302
 */

#include <lib.h>

inherit LIB_ACCESS;
