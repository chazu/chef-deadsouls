inherit "/domains/default/weap/grenade";


void init(){
    ::init();
}
