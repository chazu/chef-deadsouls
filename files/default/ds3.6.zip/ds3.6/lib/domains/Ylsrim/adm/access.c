/*    /domains/Ylsrim/adm/access.c
 *    From the Dead Souls Mud Library
 *    the access object for the Ylsrim domain
 *    created by Descartes of Borg 960302
 */

#include <lib.h>

inherit LIB_ACCESS;
