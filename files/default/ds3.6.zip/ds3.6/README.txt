		      The Dead Souls 2 Mud Library
		         Released December 2005

GENERAL FAQ: http://dead-souls.net/ds-faq.html

ADMIN FAQ: http://dead-souls.net/ds-admin-faq.html

CREATOR FAQ: http://dead-souls.net/ds-creator-faq.html

INSTALL FAQ: http://dead-souls.net/ds-inst-faq.html

ED TUTORIAL: http://dead-souls.net/editor.html

CREATION SYSTEM (aka OLC, aka QCS) : http://dead-souls.net/example.html

	This software is provided as-is. Getting it running
and getting it working is on you, not me. make sure you go
through the install FAQ. There's a version archived here in 
the ./www subdirectory.

	Some years ago, Descartes @ Nightmare chose to retire his
Nightmare mudlib from distribution. Yet some folks felt
that it was a fine lib, and many were sorry to see it go.

	This mudlib is based on that old warhorse. It is entirely
free from those NM IV licensing problems. It is in a state
as bug-free as I could make it, with my limited resources
and faculties. I make it available so that a new generation of
mudders can experience the joy of creating with LPC in a way
that is easy to set up, intuitive to modify, and simple to maintain.

	Please review /doc/old/README for more historical background.

	Have fun!

-Cratylus @ Dead Souls
This document last updated: 28 Jan 2008
