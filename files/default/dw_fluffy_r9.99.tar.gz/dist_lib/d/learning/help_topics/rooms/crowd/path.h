#include <learning.h>

#define CROWD "/d/learning/help_topics/rooms/crowd/"
