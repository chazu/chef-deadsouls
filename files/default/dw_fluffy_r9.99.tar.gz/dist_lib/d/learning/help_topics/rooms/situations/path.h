#include <learning.h>

#define SIT "/d/learning/help_topics/rooms/situations/"
