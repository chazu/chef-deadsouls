#include <learning.h>
#define PATH HELP +"rooms/terrains/"
#define MAIN PATH +"main"
