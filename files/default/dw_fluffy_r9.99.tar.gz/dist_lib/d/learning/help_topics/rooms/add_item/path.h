#include <learning.h>
#define PATH HELP +"rooms/add_item/"
#define MAIN PATH +"main"
