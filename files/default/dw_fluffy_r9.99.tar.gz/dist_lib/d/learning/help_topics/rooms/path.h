#include <learning.h>
#define PATH HELP + "rooms/"
