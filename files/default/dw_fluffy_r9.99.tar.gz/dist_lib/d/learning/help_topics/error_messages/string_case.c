void bing() {
    switch ("hi") {
    case "bing".."bar":
    }
}
