int x += 1;

/* You can only use = to initialise a variable while defining it
 */
