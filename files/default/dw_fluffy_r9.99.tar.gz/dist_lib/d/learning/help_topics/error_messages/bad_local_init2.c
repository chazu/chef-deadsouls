void bing() {
    int x = "hi";
}
