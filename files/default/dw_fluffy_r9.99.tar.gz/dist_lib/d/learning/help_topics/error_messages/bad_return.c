void bing() {
    return 1;
}
