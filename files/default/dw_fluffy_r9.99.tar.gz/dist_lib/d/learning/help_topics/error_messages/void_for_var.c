void bing() {
    for (void x = 1; ; ) ;
}
