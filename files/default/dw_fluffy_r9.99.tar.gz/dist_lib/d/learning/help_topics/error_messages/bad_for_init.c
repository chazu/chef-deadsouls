void bing() {
    for (int x += 1; ; ) ;
}
    
