void bing() {
    void x;
}
