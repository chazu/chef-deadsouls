class bing {
}

class bing {
}
