class bing x;
