void bing() {
    new(class bing);
}
