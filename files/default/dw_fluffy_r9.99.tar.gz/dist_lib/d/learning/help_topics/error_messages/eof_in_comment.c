/* Comments have to stop as well as start
