void bing() {
    (: $1000 :);
}
