void bing() {
    int x;
    (: x + 1 :);
}
