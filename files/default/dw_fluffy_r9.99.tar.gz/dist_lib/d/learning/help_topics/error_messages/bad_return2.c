int bing() {
    return "hi";
}
