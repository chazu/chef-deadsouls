void bing(int x) {
}

void bar() {
    bing( ({ })...);
}
