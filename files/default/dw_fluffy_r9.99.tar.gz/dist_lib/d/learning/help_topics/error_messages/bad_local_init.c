void bing() {
    int x += 1;
}
