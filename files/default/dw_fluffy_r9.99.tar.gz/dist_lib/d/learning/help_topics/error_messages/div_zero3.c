int bing() {
    return 1/0.0;
}
