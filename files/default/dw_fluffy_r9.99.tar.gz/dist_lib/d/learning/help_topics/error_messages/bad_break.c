void bing() {
    break;
}

/* break belongs in case statements of switch, and in for,
 * foreach and while loops, not by itself
 */
