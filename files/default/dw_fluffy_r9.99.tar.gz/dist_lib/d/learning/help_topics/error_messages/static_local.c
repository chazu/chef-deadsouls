void main() {
    nosave int x = 5;
}
