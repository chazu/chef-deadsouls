class bing {
    void x;
}
