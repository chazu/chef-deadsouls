class bing {
    int x;
}

void bing() {
    bing y;
    y->z;
}
