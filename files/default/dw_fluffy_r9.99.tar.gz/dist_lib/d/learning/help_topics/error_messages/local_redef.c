void bing(int x) {
    int x;
}
