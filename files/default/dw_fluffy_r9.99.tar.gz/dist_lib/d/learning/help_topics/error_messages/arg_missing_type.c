void bing(int) {
}

/* This is a function with a type but no argument
 */
