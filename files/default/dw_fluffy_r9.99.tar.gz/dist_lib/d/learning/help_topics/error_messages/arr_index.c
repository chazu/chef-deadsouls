void bing() {
    ({ })[1];
}

/* This is a constant array that are indexed outside the bounds
 */
