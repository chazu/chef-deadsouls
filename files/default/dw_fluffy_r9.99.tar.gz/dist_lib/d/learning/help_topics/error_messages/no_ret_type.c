#pragma strict_types

bing() {
}
