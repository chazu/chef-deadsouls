void bing() {
}

void bing() {
}
