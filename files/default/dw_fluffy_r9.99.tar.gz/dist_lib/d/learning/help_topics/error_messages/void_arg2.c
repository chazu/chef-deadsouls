void bing(void);
