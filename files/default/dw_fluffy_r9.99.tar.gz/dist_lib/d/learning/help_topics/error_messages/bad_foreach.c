void bing() {
    foreach (x in ({})) ;
}
/* x needs to be declared before it can be used
 */

