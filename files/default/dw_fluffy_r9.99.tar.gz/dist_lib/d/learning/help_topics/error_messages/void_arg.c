void bing(void x) {
}
