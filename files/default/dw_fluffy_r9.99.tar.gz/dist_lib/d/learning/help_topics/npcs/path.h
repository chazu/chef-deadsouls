#include <learning.h>
#define PATH HELP + "npcs/"
