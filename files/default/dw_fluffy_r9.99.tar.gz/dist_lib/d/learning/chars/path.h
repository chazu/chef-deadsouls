#include <learning.h>
#define TERRAIN_TUTORIAL HELP +"rooms/terrains/"
