#define PATH "/d/learning/examples/npcs/"
