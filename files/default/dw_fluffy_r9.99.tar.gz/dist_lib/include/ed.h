#ifndef __SYS__ED
#define __SYS__ED

#define LOG_FILE "/save/board/LOG"
#define TEMP_DIR "/tmp/"
#define TMP_FILE TEMP_DIR+"board."+(string)this_player()->query_name()+".tmp"
#define ED_HELP_FILE "/doc/concepts/edit_help"
#define PRESTOS_ED "/global/magic"

#endif /* __SYS__ED */
