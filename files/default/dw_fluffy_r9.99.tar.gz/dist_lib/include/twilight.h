#define NEVER 2
#define DAY   1
#define NIGHT 0
#define WEATHER_HANDLER         "/obj/handlers/weather.c"
#define CHANGING_OUTSIDE_OBJECT "/std/room/twilight.c"  
