#ifndef __SYS__PUB
#define __SYS__PUB

#define SOFTDRINK "softdrink"
#define ALCOHOL   "alcohol"
#define FOOD      "food"

#define DR_TYPE   0
#define DR_COST   1
#define DR_HEAL   2
#define DR_VOLUME 3
#define DR_INTOX  4
#define DR_DRMESS 5
#define DR_OTHMES 6
#define DR_OTHMESS 6


#endif /* __SYS__PUB */
