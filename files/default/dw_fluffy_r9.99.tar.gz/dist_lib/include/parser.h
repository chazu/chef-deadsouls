#ifndef _PARSER_H
#define _PARSER_H

#include <tokenise.h>

#define PARSER "/global/parser"
#define TOKENISER "/obj/handlers/tokeniser"

#endif
