#define UNIVERSITY            "/d/guilds/wizards/Ankh-Morpork/"

#define ANCIENT_ASSEMBLY      UNIVERSITY +"ancient_assembly/"
#define NEW_HALL              UNIVERSITY +"new_hall/"
#define TURNWISE_COURT        UNIVERSITY +"turnwise_court/"
#define WIDDERSHINS_COURT     UNIVERSITY +"widdershins_court/"
