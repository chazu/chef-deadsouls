#ifndef __SYS__SURFACE
#define __SYS__SURFACE

#define SURFACE_MODULE "/std/basic/surface"
#define SURFACE_SHADOW "/std/shadows/misc/surface"

#endif /* __SYS__SURFACE */
