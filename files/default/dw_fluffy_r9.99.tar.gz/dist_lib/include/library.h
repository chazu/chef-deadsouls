#ifndef __SYS__LIBRARY
#define __SYS__LIBRARY

#define LIBRARY "/obj/handlers/library"

#endif /* __SYS__LIBRARY */
