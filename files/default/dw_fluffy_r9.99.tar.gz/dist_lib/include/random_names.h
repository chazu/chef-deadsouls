#ifndef __RANDOM_NAMES_H
#define __RANDOM_NAMES_H

#define RANDOM_NAME_GENERATOR "/obj/handlers/random_names"
#define RANDOM_NAME_SAVE_FILE "/save/random_names/random_names"
#define RANDOM_NAME_DATA_DIR  "/save/random_names/data/"

#endif
