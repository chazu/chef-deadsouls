/**
 * The shop engrave include.
 */
#ifndef __SYS_SHOP_ENGRAVE
/** @ignore yes */
#define __SYS_SHOP_ENGRAVE

/**
 * The property to check to see if the item is engraveable.
 */
#define ENGRAVE_PROP "engraveable"

#endif
