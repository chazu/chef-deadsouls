#ifndef __SYS__DRINKS
#define __SYS__DRINKS

#define D_SIZEOF 3
#define D_ALCOHOL 0
#define D_FOOD 1
#define D_DRINK 2

#endif /* __SYS__DRINKS */
