#ifndef __SYS__MONSTER
#define __SYS__MONSTER

#define RACE_OB "/std/race"
#define MONSTER_HAND "/obj/handlers/monster_handler"

#endif /* __SYS__MONSTER */
