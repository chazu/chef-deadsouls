// Include file for the fighters guilds

#define GUILD_OB "/std/guilds/fighter"

#define FIGHTER "/d/guilds/fighters/"

#define FIGHTERCHARS FIGHTER+"chars/"
#define FIGHTERITEMS FIGHTER+"items/"
