#ifndef __SYS__MAIL_TRACK
#define __SYS__MAIL_TRACK

class mailing_list {
  string *members;
  string *controllers;
  string creator;
}

#define MAIL_ROOM "/d/admin/room/mail_room"

#endif /* __SYS__MAIL_TRACK */
