#define MAP "/obj/handlers/map"
#define MAP_HANDLER "/obj/handlers/map"
