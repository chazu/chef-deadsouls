#ifndef __ROUTE_H
#define __ROUTE_H
/*
 * The route handler defines, all you need to know is where it is :)
 */

#define ROUTE_HANDLER "/obj/handlers/route_handler"

#endif
