#ifndef __SYS_SECURITY_H
#define __SYS_SECURITY_H

#define SECURITY "/secure/security"
#define ACCESS "/std/basic/security"

#endif /* __SYS_SECURITY_H */
