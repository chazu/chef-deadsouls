/**
 * An include file for development work for priests.
*/


#define EFFECTS "/d/playtesters/effects/faith"
#define SHADOWS "/d/playtesters/shadows/faith"
#define ITEMS "/d/playtesters/items/faith"
#define RITUALS "/d/playtesters/rituals"
#define ROOMS "/d/playtesters/rooms"
#define INHERITS RITUALS "/inherits"
