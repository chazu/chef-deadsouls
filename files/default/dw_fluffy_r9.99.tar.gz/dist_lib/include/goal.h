#ifndef __SYS__GOAL
#define __SYS__GOAL

#define EVENT_HANDLED 5
#define EVENT_NOT_HANDLED 6
#define EVENT_PARTIALLY_HANDLED 7
#define EVENT_USED 8
#define SET_GOAL_ARG 9
#define GOAL_ACHIEVED 10

#endif /* __SYS__GOAL */
