/**
 * This file contains all that is needed by the login object.
 * @author Pinkfish
 */
#include <login_handler.h>

/**
 * This is the location of the login object.
 * @see /secure/login
 */
#define LOGIN_OB "/secure/login"

