#define RUN 1
#define FIGHT 2
#define STAND 3
