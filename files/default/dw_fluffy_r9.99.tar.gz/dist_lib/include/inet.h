#ifndef __SYS__INET
#define __SYS__INET

#define INETD "/net/inetd"
#define NAMESERVER "/net/nameserver"
#include "comms.h"
#define CLONE_DEMON
#define INTERCREATORD "/net/daemon/out_intercreator"

#endif /* __SYS__INET */
