#ifndef __SYS__BOUNTY
#define __SYS__BOUNTY

/*
   Bounty stuff
*/

#define BOUNTY "/obj/handlers/bounty"

#endif /* __SYS__BOUNTY */
