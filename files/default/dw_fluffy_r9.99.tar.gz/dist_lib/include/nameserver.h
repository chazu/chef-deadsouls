#ifndef __SYS__NAMESERVER
#define __SYS__NAMESERVER

#define NAME_D "/net/nameserver"
#define INET_D "/net/inetd"

#endif /* __SYS__NAMESERVER */
