#ifndef __SYS__TERRAIN
#define __SYS__TERRAIN

#define TERRAIN_MAP "/obj/handlers/terrain_handler"
#define TERRAIN_LOG "/obj/handlers/terrain_things/logroom"

#define RESTORE_PATH "/save/terrains/"

#endif /* __SYS__TERRAIN */
