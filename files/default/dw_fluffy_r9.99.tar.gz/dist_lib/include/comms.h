#ifndef __SYS__COMMS
#define __SYS__COMMS

#define COMM_ROOM "/d/guilds/wizards/Ankh-Morpork/old/comm_room"

#endif /* __SYS__COMMS */
