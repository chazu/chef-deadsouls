class teach_skill  {
   string skill;
   int teach;
   int learn;
}
