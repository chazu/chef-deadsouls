/**
 * This is stuff specific for the friends command.
 * @author Pinkfish
 * @started Thu May 30 15:21:09 PDT 2002
 */
#ifndef __CMDS_FRIENDS_H__
/** @ignore yes */
#define __CMDS_FRIENDS_H__

/** The location of the friends command. */
#define FRIENDS_CMD "/cmds/player/friend_s"

#endif
