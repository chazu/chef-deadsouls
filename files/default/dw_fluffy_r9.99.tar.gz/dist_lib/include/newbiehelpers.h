/**
 *  Newbiehelpers include file
 *  @author Wyvyrn
 *  @stared 10/03/2003
 */


#ifndef __NEWBIEHELPERS_H
#define __NEWBIEHELPERS_H

/* Handler define */
 
#define NEWBIEHELPERS_HANDLER            "/obj/handlers/newbiehelpers"

#endif
