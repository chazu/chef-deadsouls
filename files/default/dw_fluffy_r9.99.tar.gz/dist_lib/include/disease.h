#define EFFECTS "/std/effects/"
#define SHADOWS "/std/shadows/"
#define BASIC_DISEASE EFFECTS "disease/basic_disease"
#define SIMPLE_DISEASE EFFECTS "disease/simple_disease"
#define BASIC_CURE EFFECTS "healing/basic_cure"
#define SIMPLE_CURE EFFECTS "healing/simple_cure"
#define DISEASE_HANDLER "/obj/handlers/disease"
#define CURE_SCALE ({ 2, 3, 3, 3 })
#define DISEASE_SCALE ({ 2, 3, 3, 3 })
