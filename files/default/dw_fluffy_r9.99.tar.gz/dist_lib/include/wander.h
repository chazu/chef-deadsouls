#ifndef __SYS__WANDER
#define __SYS__WANDER

#define WANDER_HANDLER "/obj/handlers/wander_handler"

#endif /* __SYS__WANDER */
