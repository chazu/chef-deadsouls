#ifndef __SYS__FINGER
#define __SYS__FINGER

#define CREATE (name != "domos" && name != "shru")

#endif /* __SYS__FINGER */
