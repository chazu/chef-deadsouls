#ifndef __SYS__MINERAL
#define __SYS__MINERAL

#define PEBBLE 5
#define STONE 20
#define ROCK 1000
#define MINERAL "/obj/mineral"

#endif /* __SYS__MINERAL */
