#ifndef __SYS__SHOP
#define __SYS__SHOP

#define PAY_RATES ({ 100, 90, \
                     200, 80, \
                     400, 70, \
                     800, 60, \
                     1600, 50, \
                     3200, 40, \
                     6400, 30, \
                     12800, 20, \
                     10 })
#define MAX_AMOUNT 50000
#define MAX_INVENTORY 50
#define MAX_OBS 8

#endif /* __SYS__SHOP */
