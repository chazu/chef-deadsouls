#define assert(x) if(!(x)) error("assertion failed: " +#x)
