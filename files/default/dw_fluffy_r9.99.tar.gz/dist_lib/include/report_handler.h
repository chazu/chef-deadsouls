#define SAVEPATH  "/save/cases/"
#define RECENT    (SAVEPATH+"recent.o")
#define NEWCASES  (SAVEPATH+"new.o")
#define NO_RECENT 20

#define NAME      0
#define CHARS     1
#define CREATOR   2
#define TIME      3
#define CATEGORY  4
#define REPORT    5
#define HIGHLORD  6
#define DECISION  7

