#define MERCHANT "/d/guilds/merchants"

#define STALL MERCHANT+"/stalls/"
#define SHOPS MERCHANT+"/shops/"
#define MERCHANT_GUILD MERCHANT+"/guild/"

#define MERCHANT_CHARS MERCHANT+"/chars/"
#define MERCHANT_ITEMS MERCHANT+"/items/"
#define MERCHANT_SAVE MERCHANT+"/save/"
#define MERCHANT_STD MERCHANT+"/std/"

