#ifndef __SYS__QUEST_HANDLER
#define __SYS__QUEST_HANDLER

#define QUEST_HANDLER "/obj/handlers/quest_handler"

#endif /* __SYS__QUEST_HANDLER */
