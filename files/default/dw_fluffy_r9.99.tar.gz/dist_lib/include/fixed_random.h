#ifndef __FIXED_RANDOM_H
#define __FIXED_RANDOM_H

#define RANDOM_OBJ "/obj/handlers/random_num"

#endif
