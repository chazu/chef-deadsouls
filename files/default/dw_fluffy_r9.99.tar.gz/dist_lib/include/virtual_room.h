#ifndef __SYS__VIRTUAL_ROOM
#define __SYS__VIRTUAL_ROOM

#include <virtual.h>

#define FLAG 0
#define DELAY 1
#define CLONE 2
#define MESS 3
#define REMOVABLE 0
#define FIXED 1
#define UNIQUE 2
#endif /* __SYS__VIRTUAL_ROOM */
