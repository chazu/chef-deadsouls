#ifndef __SYS__MISSION
#define __SYS__MISSION

#define NOT_SUITABLE 4
#define TOO_HIGH 3
#define JUST_RIGHT 2
#define TOO_LOW 1


#endif /* __SYS__MISSION */
