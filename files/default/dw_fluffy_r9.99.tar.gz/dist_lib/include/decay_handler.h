#define DECAY_TIME 15
// time between do_decay calls in the decayer

#define DECAY_HANDLER "/obj/handlers/decay_handler"
