#ifndef __SYS__TERM
#define __SYS__TERM

#define TERM_HANDLER "/obj/handlers/term"

#endif /* __SYS__TERM */
