#define GOOD_FIGHTER "/std/effects/npc/good_fighter"

//  bits: 000uuudd (uuu = use, dd = defend)
#define USE_UNARMED 16
#define USE_BLUNT 12
#define USE_SHARP 8
#define USE_PIERCE 4
#define USE_BALANCED 0
#define USE_mask 28

#define DEFEND_DODGE 2
#define DEFEND_PARRY 1
#define DEFEND_BALANCED 0
#define DEFEND_mask 3
