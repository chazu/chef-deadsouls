#ifndef __SYS__RACE
#define __SYS__RACE

#define R_OBJECT 0
#define STD_RACE "/std/race/standard"

#endif /* __SYS__RACE */
