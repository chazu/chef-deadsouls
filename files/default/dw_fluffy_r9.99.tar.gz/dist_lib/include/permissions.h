/** 
 *  File Permissions
 *
 */
 
#define READ_MASK 1
#define WRITE_MASK 2
#define GRANT_MASK 4
#define LOCK_MASK 8

 