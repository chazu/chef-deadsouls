#ifndef __SYS__SPELLS
#define __SYS__SPELLS

#define SP_OBJECT 1
#define SP_FUNC 2
#define SP_PARAM 3
#define S_OBJECT 0
#define S_FUNC 1
#define SP_NO_RNDS 0

#endif /* __SYS__SPELLS */
