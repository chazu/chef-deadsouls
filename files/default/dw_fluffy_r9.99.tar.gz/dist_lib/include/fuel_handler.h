#define FUEL_TIME 15 /* time between calls of consume_fuel */
#define FUEL_HANDLER "/obj/handlers/fuel_handler"
