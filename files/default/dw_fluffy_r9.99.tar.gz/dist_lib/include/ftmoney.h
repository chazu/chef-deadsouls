#ifndef __SYS__FTMONEY
#define __SYS__FTMONEY

#define MONEY_OBJECT "/obj/money"
#define MONEY_HAND "/obj/handlers/money_handler"
#define MONEY_ALIAS "SomeMoneyForMe"

#endif /* __SYS__FTMONEY */
