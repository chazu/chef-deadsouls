#ifndef __SYS__PARSE_COMMAND
#define __SYS__PARSE_COMMAND

#define P_THING 0
#define P_STR 1
#define P_CUR_NUM 2
#define P_MAX_NUM 3
#define P_TOP 4
#define P_BOT 5

#endif /* __SYS__PARSE_COMMAND */
