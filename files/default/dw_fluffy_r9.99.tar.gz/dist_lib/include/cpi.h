#define PRICE_INDEX "/obj/handlers/cpi_handler"
#define DEFAULT_MARKET "Ankh-Morpork"
