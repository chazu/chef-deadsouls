#ifndef __SYS__FORMS
#define __SYS__FORMS

#define FLG_NEW_LINE 1
#define FLG_TEXT_ONLY 2
#define FLG_TEXT_INVIS 4
/* this one implies text only as well.... */
#define FLG_TEXT_CENTER 10

#endif /* __SYS__FORMS */
