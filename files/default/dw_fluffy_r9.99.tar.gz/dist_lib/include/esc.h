#ifndef __SYS__ESC
#define __SYS__ESC


#define esc ""

#endif /* __SYS__ESC */
