#ifndef __LS_H
#define __LS_H

#define MASK_L 1
#define MASK_C 2
#define MASK_F 4
#define MASK_A 8
#define MASK_D 16
#define MASK_O 32
#define MASK_T 64

#define LS_COMMAND_NICKNAME_PROPERTY "expand ls nicknames"

#endif /* __LS_H */
