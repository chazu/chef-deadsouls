#undef CLASSROOMS
#undef PRIESTCHARS

#define PRIESTTSG    "/d/am/small_gods/temple"
#define PRIESTAM     "/d/guilds/priests/Ankh-Morpork/"
#define PRIESTKLK     "/d/guilds/priests/Khot-lip-khin/"
#define PRIESTDJEL   "/d/guilds/priests/Djelibeybi/"
#define PRIESTOC    "/d/guilds/priests/Ohulan-Cutash/"

#define CLASSROOMS   "/d/guilds/priests/Ankh-Morpork/classrooms/"
#define TSG          "/d/am/priest/templeofsg/"

#define PRIESTCHARS  "/d/guilds/priests/chars/"
#define PRIESTINHERITS "/d/guilds/priests/inherits/"
#define PRIESTITEMS  "/d/guilds/priests/items/"
#define PRIESTUTILS  "/d/guilds/priests/utils/"

#define PRIESTSAVE   "/d/guilds/priests/save/"

#define PRAYERS     "/obj/rituals/"
#define BASIC       "/obj/rituals/basic"
#define HEALING     "/obj/rituals/basic_healing"
